#!/usr/bin/env python3
"""
GeeTest v4 滑块验证码破解器 — 完整独立版
========================================

使用方法:
    pip install cloakbrowser[geoip] opencv-python-headless numpy
    python geetest_solver.py

原理:
    1. CloakBrowser (headless Chromium) 打开 GeeTest v4 demo 页面
    2. 下载背景图 + slice 拼图块图
    3. 用 Canny 边缘 + 模板匹配 定位缺口位置
    4. 用 Playwright mouse API + 缓动轨迹模拟人类拖拽
    5. 等待 GeeTest 服务端验证

关键发现:
    - Playwright mouse API 有效（不需要 JS PointerEvent）
    - geetest_btn (80x50) 是拖拽按钮，不是整个 slider bar
    - 模板匹配比暗区检测更准确
    - gap_x 取模板匹配的 max_loc[0]（左边缘），不要加 slice 宽度的一半
    - 拖拽距离 = gap_x * (bg_page_width / bg_pixel_width)
"""
import sys, os, time, urllib.request, random
import numpy as np
import cv2


def launch_browser(headless=True):
    """启动 CloakBrowser"""
    from cloakbrowser import launch
    print("🚀 启动 CloakBrowser...")
    browser = launch(headless=headless, humanize=False)
    return browser


def detect_gap(bg_img, slice_img=None):
    """
    检测缺口位置（背景图像素坐标）
    
    Args:
        bg_img: BGR 背景图 (numpy array)
        slice_img: RGBA slice 拼图块图 (numpy array)，可选
    
    Returns:
        gap_x: 缺口左边缘在背景图中的 x 像素位置
        method: 使用的检测方法名称
    """
    h_img, w_img = bg_img.shape[:2]
    
    # 方法1: 模板匹配（最准确，需要 slice 图）
    if slice_img is not None:
        try:
            slice_gray = cv2.cvtColor(slice_img[:,:,:3], cv2.COLOR_BGR2GRAY)
            bg_gray = cv2.cvtColor(bg_img, cv2.COLOR_BGR2GRAY)
            slice_edge = cv2.Canny(slice_gray, 100, 200)
            bg_edge = cv2.Canny(bg_gray, 100, 200)
            result = cv2.matchTemplate(bg_edge, slice_edge, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, max_loc = cv2.minMaxLoc(result)
            if max_val > 0.15:
                print(f"  🎯 模板匹配: val={max_val:.3f}, loc=({max_loc[0]},{max_loc[1]})")
                return max_loc[0], "template"
        except Exception as e:
            print(f"  ⚠️ 模板匹配失败: {e}")
    
    # 方法2: 暗区检测
    gray = cv2.cvtColor(bg_img, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    mean_val = np.mean(blur)
    dark_mask = ((blur < mean_val - 15).astype(np.uint8)) * 255
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (20, 20))
    dark_mask = cv2.morphologyEx(dark_mask, cv2.MORPH_CLOSE, kernel)
    dark_mask = cv2.morphologyEx(dark_mask, cv2.MORPH_OPEN, kernel)
    
    contours, _ = cv2.findContours(dark_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    candidates = []
    for c in contours:
        x, y, cw, ch = cv2.boundingRect(c)
        if not (25 < cw < 120 and 25 < ch < 120): continue
        if x < w_img * 0.15: continue
        ratio = cw / max(ch, 1)
        if not 0.5 < ratio < 2.0: continue
        candidates.append((x + cw//2, y + ch//2, cw, ch))
    
    if candidates:
        candidates.sort(key=lambda t: abs(t[1] - h_img/2))
        gap_x = candidates[0][0]
        print(f"  🎯 暗区检测: x={gap_x}px, candidates={len(candidates)}")
        return gap_x, "dark"
    
    # 方法3: Canny 边缘检测 fallback
    from slide_captcha.scripts.gap_detect import detect_gap_edge
    gap_x = detect_gap_edge(bg_img, min_area=200, max_area=15000)
    print(f"  🎯 边缘检测: x={gap_x}px")
    return gap_x, "edge"


def generate_trajectory(distance, steps=35):
    """
    生成类人拖拽轨迹 — 改进版 v2
    
    特征：
    - 起步加速（慢→快）
    - 中段匀速微抖
    - 末段减速+微量过冲回拉
    - y轴正弦噪声（比纯随机更像人手）
    - 步间间隔递增（开始快，结尾慢）
    - 释放前短暂停顿
    
    Args:
        distance: 拖拽距离（像素）
        steps: 轨迹步数
    
    Returns:
        list of (dx, dy, dt): 增量序列
    """
    import math
    
    # 精确终点 + 类人特征
    overshoot_ratio = random.uniform(0.02, 0.04)  # 过冲幅度 2-4%
    
    increments = []
    prev_x = 0.0
    target_x = float(distance)
    overshoot_x = target_x * (1 + overshoot_ratio)
    
    for i in range(steps + 1):
        t = i / steps
        
        # 三段式缓动
        if t < 0.35:
            # 加速段：二次缓入 (0 → 70% of target)
            progress = 0.70 * (t / 0.35) ** 2
        elif t < 0.75:
            # 中段：线性推进 (70% → 过冲点)
            mid_t = (t - 0.35) / 0.40
            progress = 0.70 + (overshoot_ratio + 0.30) * mid_t
        elif t < 0.90:
            # 过冲回拉段
            pull_t = (t - 0.75) / 0.15
            progress = 1.0 + overshoot_ratio * (1 - pull_t)
        else:
            # 微调段：在目标附近小幅振荡
            fin_t = (t - 0.90) / 0.10
            progress = 1.0 + (1 - fin_t) * overshoot_ratio * 0.3 * math.sin(fin_t * math.pi)
        
        x_pos = target_x * progress
        
        # y 轴：正弦波 + 小随机噪声（模拟手腕摆动）
        y_noise = 1.2 * math.sin(t * math.pi * random.uniform(2.5, 4.0)) + random.uniform(-0.5, 0.5)
        
        dx = x_pos - prev_x
        dy = y_noise
        prev_x = x_pos
        
        # 间隔：开始快（30ms），结尾慢（60ms），释放前停顿
        if i < steps * 0.4:
            dt = random.uniform(0.025, 0.040)
        elif i < steps * 0.75:
            dt = random.uniform(0.035, 0.055)
        else:
            dt = random.uniform(0.050, 0.080)
        
        increments.append((dx, dy, dt))
    
    # 末尾：释放前短暂停顿（0.1-0.3秒）
    increments.append((0, 0, random.uniform(0.1, 0.25)))
    
    return increments


def solve_geetest(url='https://gt4.geetest.com/demov4/slide-float-en.html', headless=True):
    """
    完整的 GeeTest v4 滑块验证码破解流程
    
    Args:
        url: GeeTest v4 demo 页面 URL
        headless: 是否无头模式
    
    Returns:
        True: 验证成功
        False: 验证失败
        None: 不确定
    """
    browser = launch_browser(headless=headless)
    page = browser.new_page()
    
    try:
        # 1. 打开页面
        print("📱 打开页面...")
        page.goto(url, timeout=30000)
        time.sleep(3)
        
        # 2. 点击触发滑块弹窗
        print("🖱️ 触发滑块弹窗...")
        page.locator('[class*="geetest_btn_click"]').first.click(force=True)
        time.sleep(4)
        
        # 3. 收集 DOM 信息
        print("📋 收集页面元素...")
        info = page.evaluate("""() => {
            const r = {};
            for (const el of document.querySelectorAll('*')) {
                const s = window.getComputedStyle(el);
                const bg = s.backgroundImage;
                if (!bg || bg === 'none') continue;
                if (bg.includes('/bg/') && !bg.includes('/slice/')) {
                    const m = bg.match(/url\\("([^"]+)"\\)/);
                    if (m) r.bgUrl = m[1];
                }
                if (bg.includes('/slice/')) {
                    const m = bg.match(/url\\("([^"]+)"\\)/);
                    if (m) r.sliceUrl = m[1];
                }
            }
            const bgEl = document.querySelector('[class*="geetest_bg"]');
            const btn = document.querySelector('[class*="geetest_slider"] [class*="geetest_btn"]');
            if (bgEl) { const b = bgEl.getBoundingClientRect(); r.bgBox = {x:b.x, y:b.y, w:b.width, h:b.height}; }
            if (btn) { const b = btn.getBoundingClientRect(); r.btnBox = {x:b.x, y:b.y, w:b.width, h:b.height}; }
            return r;
        }""")
        
        if not info.get('bgUrl') or not info.get('btnBox'):
            print("❌ 缺少关键元素（背景图或滑块按钮）")
            return False
        
        print(f"  bgBox: {info['bgBox']}")
        print(f"  btnBox: {info['btnBox']}")
        print(f"  bgUrl: {info['bgUrl'][:60]}...")
        print(f"  sliceUrl: {info.get('sliceUrl', 'N/A')[:60]}...")
        
        # 4. 下载图片
        print("📥 下载图片...")
        bg_url = info['bgUrl']
        if bg_url.startswith('//'): bg_url = 'https:' + bg_url
        urllib.request.urlretrieve(bg_url, '/tmp/geetest_bg.png')
        pic_bg = cv2.imread('/tmp/geetest_bg.png')
        print(f"  背景图: {pic_bg.shape}")
        
        slice_img = None
        if info.get('sliceUrl'):
            slice_url = info['sliceUrl']
            if slice_url.startswith('//'): slice_url = 'https:' + slice_url
            try:
                urllib.request.urlretrieve(slice_url, '/tmp/geetest_slice.png')
                slice_img = cv2.imread('/tmp/geetest_slice.png', cv2.IMREAD_UNCHANGED)
                print(f"  Slice图: {slice_img.shape}")
            except Exception as e:
                print(f"  ⚠️ Slice下载失败: {e}")
        
        # 5. 检测缺口
        print("🔍 检测缺口位置...")
        gap_x, method = detect_gap(pic_bg, slice_img)
        print(f"  缺口位置: x={gap_x}px (方法: {method})")
        
        # 6. 计算拖拽距离
        bg_box = info['bgBox']
        scale = bg_box['w'] / pic_bg.shape[1]
        drag_distance = gap_x * scale
        print(f"  拖拽距离: {drag_distance:.1f}px (scale={scale:.3f})")
        
        # 7. 生成类人轨迹并拖拽
        print("🖱️ 执行拖拽...")
        btn_box = info['btnBox']
        start_x = btn_box['x'] + btn_box['w'] / 2
        start_y = btn_box['y'] + btn_box['h'] / 2
        
        increments = generate_trajectory(drag_distance)
        print(f"  轨迹步数: {len(increments)}, 起点=({start_x:.0f},{start_y:.0f})")
        
        page.mouse.move(start_x, start_y)
        time.sleep(0.1)
        page.mouse.down()
        time.sleep(0.2)
        
        cur_x, cur_y = start_x, start_y
        for dx, dy, dt in increments:
            cur_x += dx
            cur_y += dy
            page.mouse.move(cur_x, cur_y)
            if dt > 0:
                time.sleep(dt)
        
        time.sleep(0.15)
        page.mouse.up()
        print("  ✅ 拖拽完成")
        
        # 8. 检查拖拽效果
        time.sleep(0.5)
        drag_check = page.evaluate("""() => {
            const slice = document.querySelector('[class*="geetest_slice"]');
            const btn = document.querySelector('[class*="geetest_slider"] [class*="geetest_btn"]');
            return {
                sliceT: slice?.style.transform || '',
                btnT: btn?.style.transform || ''
            };
        }""")
        print(f"  拖拽后: {drag_check}")
        page.screenshot(path='/tmp/geetest_dragged.png')
        
        # 9. 等待验证结果
        print("⏳ 等待验证结果...")
        result = None
        for attempt in range(12):
            time.sleep(1.5)
            check = page.evaluate("""() => {
                for (const el of document.querySelectorAll('*')) {
                    const cls = String(el.className || '');
                    if (cls.includes('geetest_success')) return {verified: true};
                    if (cls.includes('geetest_fail')) return {verified: false};
                }
                const tip = document.querySelector('[class*="geetest_tip"]');
                const tipText = tip ? tip.textContent?.trim() : '';
                if (/success/i.test(tipText)) return {verified: true, tipText};
                if (/fail|error|retry|重试/i.test(tipText)) return {verified: false, tipText};
                // "Verifying" 超过 10s 视为失败
                if (/verifying/i.test(tipText)) return {verified: 'verifying', tipText};
                return {verified: null, tipText};
            }""")
            print(f"  检查 #{attempt+1}: {check}")
            if check.get('verified') is True:
                result = True
                break
            elif check.get('verified') is False:
                result = False
                break
            elif check.get('verified') == 'verifying' and attempt >= 6:
                # Verifying 超过 9s，可能服务端超时了
                print("  ⚠️ Verifying 超时，视为失败")
                result = False
                break
        
        page.screenshot(path='/tmp/geetest_result.png')
        
        if result == True:
            print("🎉 验证成功！")
        elif result == False:
            print("❌ 验证失败")
        else:
            print("⚠️ 验证结果未确认（超时）")
        
        return result
        
    except Exception as e:
        print(f"❌ 错误: {e}")
        import traceback; traceback.print_exc()
        try: page.screenshot(path='/tmp/geetest_error.png')
        except: pass
        return False
    finally:
        browser.close()
        print("🔚 完成")


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='GeeTest v4 滑块验证码破解器')
    parser.add_argument('--url', default='https://gt4.geetest.com/demov4/slide-float-en.html', help='GeeTest v4 demo URL')
    parser.add_argument('--no-headless', action='store_true', help='显示浏览器窗口')
    args = parser.parse_args()
    
    result = solve_geetest(url=args.url, headless=not args.no_headless)
    sys.exit(0 if result else 1)
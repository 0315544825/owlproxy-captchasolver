# coding=utf-8
"""
Driver: CloakBrowser 后端 (推荐用于反检测滑块)
=================================================

基于 CloakBrowser (Chromium C++ 源码级反检测) + Playwright API，
内置 humanize 行为模拟，适合中等风控站点。

对于强风控（GeeTest v4 / 防水墙），CloakBrowser 的 C++ 指纹补丁
已经解决了浏览器指纹层面的检测，配合 humanize=True 的类人行为模拟，
比纯 Playwright + Selenium 方案稳定得多。

依赖：
  pip install cloakbrowser[geoip] opencv-python numpy

公共接口：
  solve_slide(browser_or_page, bg_sel, knob_sel, *, ...) -> bool
"""

import time
import base64
import sys
import os

import numpy as np
import cv2

_here = os.path.dirname(os.path.abspath(__file__))
_scripts = os.path.dirname(_here)
_project = os.path.dirname(_scripts)
for p in [_here, _scripts, _project]:
    if p not in sys.path:
        sys.path.insert(0, p)

from trajectory import human_drag_trajectory
from gap_detect import detect_gap_dual, detect_gap_edge


def _canvas_to_ndarray(page, selector: str) -> np.ndarray:
    """从 canvas/img 元素获取图像数据，转为 OpenCV ndarray (BGR)。"""
    js = f"""
    (() => {{
        const el = document.querySelector({repr(selector)});
        if (!el) return null;
        if (el.tagName === 'CANVAS') {{
            return el.toDataURL('image/png');
        }}
        if (el.tagName === 'IMG') {{
            const c = document.createElement('canvas');
            c.width = el.naturalWidth || el.width;
            c.height = el.naturalHeight || el.height;
            c.getContext('2d').drawImage(el, 0, 0);
            return c.toDataURL('image/png');
        }}
        return null;
    }})()
    """
    data_url = page.evaluate(js)
    if data_url is None:
        raise RuntimeError(f"Element not found or not canvas/img: {selector}")
    _, b64 = data_url.split(',', 1)
    raw = base64.b64decode(b64)
    return cv2.imdecode(np.frombuffer(raw, np.uint8), cv2.IMREAD_COLOR)


def _page_screenshot_element(page, selector: str) -> np.ndarray:
    """截图整个页面，裁出目标元素区域。"""
    # 获取元素位置
    rect = page.evaluate(f"""
    (() => {{
        const el = document.querySelector({repr(selector)});
        if (!el) return null;
        const r = el.getBoundingClientRect();
        const dpr = window.devicePixelRatio || 1;
        return {{
            x: r.x * dpr, y: r.y * dpr,
            w: r.width * dpr, h: r.height * dpr
        }};
    }})()
    """)
    if rect is None:
        raise RuntimeError(f"Element not found: {selector}")

    # 截图
    screenshot_bytes = page.screenshot(type='png')
    full_img = cv2.imdecode(np.frombuffer(screenshot_bytes, np.uint8), cv2.IMREAD_COLOR)

    x, y, w, h = int(rect['x']), int(rect['y']), int(rect['w']), int(rect['h'])
    return full_img[y:y+h, x:x+w]


def solve_slide(
    browser_or_page,
    bg_sel: str,
    knob_sel: str,
    *,
    full_bg_sel: str = None,
    mode: str = 'dual',
    knob_grab_x: int = 10,
    knob_grab_y: int = 10,
    seed: int = None,
    max_retries: int = 3,
    success_sel: str = None,
) -> bool:
    """解 CloakBrowser 页面上的滑块。

    Args:
        browser_or_page: CloakBrowser 的 browser 对象或 page 对象
        bg_sel: 带缺口阴影的背景元素选择器
        knob_sel: 滑块把手元素选择器
        full_bg_sel: (仅 mode='dual') 完整原图元素选择器
        mode: 'dual' (双图差分) | 'edge' (单图Canny)
        knob_grab_x: 握点相对滑块左边界的 x 偏移
        knob_grab_y: 握点相对滑块上边界的 y 偏移
        seed: 轨迹随机种子（生产必须 None）
        max_retries: 最大重试次数（失败后重新截图识别）
        success_sel: 成功判定元素选择器（如 '.geetest_success_radar_tip'）

    Returns:
        bool: 是否成功通过验证
    """
    # 获取 page 对象
    if hasattr(browser_or_page, 'new_page'):
        page = browser_or_page.new_page()
        own_page = True
    else:
        page = browser_or_page
        own_page = False

    try:
        for attempt in range(max_retries):
            try:
                # 1. 识别缺口 x
                if mode == 'dual':
                    if full_bg_sel and full_bg_sel != bg_sel:
                        # GeeTest v4: fullbg 默认 display:none，需先显示再截
                        if 'geetest_canvas_fullbg' in full_bg_sel:
                            page.evaluate("document.querySelector('.geetest_canvas_fullbg').style.display='block'")

                        pic_full = _canvas_to_ndarray(page, full_bg_sel)

                        if 'geetest_canvas_fullbg' in full_bg_sel:
                            page.evaluate("document.querySelector('.geetest_canvas_fullbg').style.display='none'")

                        pic_bg = _canvas_to_ndarray(page, bg_sel)
                        gap_x = detect_gap_dual(pic_full, pic_bg)
                    else:
                        # 按下前/按下后方案
                        pic_before = _canvas_to_ndarray(page, bg_sel)
                        page.hover(knob_sel)
                        time.sleep(0.3)
                        pic_after = _canvas_to_ndarray(page, bg_sel)
                        gap_x = detect_gap_dual(pic_before, pic_after)
                else:
                    pic_bg = _canvas_to_ndarray(page, bg_sel)
                    gap_x = detect_gap_edge(pic_bg)

                # 2. 计算拖拽距离
                distance = gap_x - knob_grab_x
                if distance <= 0:
                    print(f"[attempt {attempt+1}] distance={distance} <= 0, gap_x={gap_x}, retrying...")
                    continue

                # 3. 生成类人轨迹
                trace = human_drag_trajectory(
                    distance=distance,
                    start_x=knob_grab_x,
                    start_y=knob_grab_y,
                    seed=seed
                )

                # 4. 执行拖拽（使用 Playwright mouse API — CloakBrowser 的 humanize 会自动添加类人行为）
                # 先获取 knob 位置
                knob_box = page.evaluate(f"""
                (() => {{
                    const el = document.querySelector({repr(knob_sel)});
                    if (!el) return null;
                    const r = el.getBoundingClientRect();
                    return {{ x: r.x, y: r.y, w: r.width, h: r.height }};
                }})()
                """)

                if knob_box is None:
                    print(f"[attempt {attempt+1}] knob not found: {knob_sel}")
                    continue

                start_x = knob_box['x'] + knob_grab_x
                start_y = knob_box['y'] + knob_grab_y

                # 使用 Playwright 鼠标 API
                page.mouse.move(start_x, start_y)
                time.sleep(0.1 + (0.05 * (attempt % 3)))  # 微小随机延迟

                page.mouse.down()
                time.sleep(0.2)

                for dx, dy, dt in trace:
                    start_x += dx
                    start_y += dy
                    page.mouse.move(start_x, start_y)
                    if dt > 0:
                        time.sleep(min(dt, 0.3))

                time.sleep(0.2)
                page.mouse.up()

                # 5. 等待验证结果
                time.sleep(1.0)

                if success_sel:
                    success_el = page.query_selector(success_sel)
                    if success_el and success_el.is_visible():
                        print(f"✅ 滑块验证成功 (attempt {attempt+1})")
                        return True
                    else:
                        print(f"[attempt {attempt+1}] success element not visible, retrying...")
                else:
                    # 无判定选择器时，假设成功
                    print(f"✅ 滑块操作完成 (attempt {attempt+1})")
                    return True

            except Exception as e:
                print(f"[attempt {attempt+1}] Error: {e}")
                if attempt < max_retries - 1:
                    time.sleep(1.0)
                    continue
                raise

        print(f"❌ 滑块验证失败 (after {max_retries} attempts)")
        return False

    finally:
        if own_page:
            page.close()


def launch_stealth_browser(proxy=None, geoip=True, headless=False):
    """启动带反检测配置的 CloakBrowser 实例。

    Args:
        proxy: 代理地址，如 "socks5://user:pass@host:port"
        geoip: 是否自动匹配代理 IP 的时区和语言
        headless: 是否无头模式

    Returns:
        browser 对象
    """
    from cloakbrowser import launch

    kwargs = {
        'headless': headless,
        'humanize': True,  # CloakBrowser 内置类人行为
    }

    if proxy:
        kwargs['proxy'] = proxy
        if geoip:
            kwargs['geoip'] = True

    return launch(**kwargs)


if __name__ == '__main__':
    print("CloakBrowser slide captcha driver loaded.")
    print("Usage:")
    print("  from scripts.drivers.cloak_driver import solve_slide, launch_stealth_browser")
    print("  browser = launch_stealth_browser()")
    print("  page = browser.new_page()")
    print("  page.goto('https://target-site.com')")
    print("  solve_slide(page, '.geetest_canvas_bg', '.geetest_btn',")
    print("             full_bg_sel='.geetest_canvas_fullbg',")
    print("             success_sel='.geetest_success_radar_tip')")
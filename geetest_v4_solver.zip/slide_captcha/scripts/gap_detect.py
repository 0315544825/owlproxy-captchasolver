# coding=utf-8
"""
滑块缺口偏移检测 (Pure Function, CV-based)
=============================================

两种工作模式：
1. dual_image 模式 (pic_before + pic_after) — 有完整原图对照
2. edge 模式 (only bg) — 只有带缺口图

返回值统一为：缺口相对于图像左边缘的 x 像素偏移。
调用方需自行减去滑块初始中心 x 才得到"应拖拽的距离"。
"""

import numpy as np
import cv2


def detect_gap_dual(pic_before: np.ndarray, pic_after: np.ndarray, debug: bool = False) -> int:
    """双图差分法定位缺口中心 x。

    Args:
        pic_before, pic_after: BGR 或 BGRA np.ndarray，尺寸必须一致。
        debug: True 时同时返回中间可视化图。

    Returns:
        int: 缺口中心像素 x（相对图像左边缘）。
             若 debug=True，返回 (x, vis_img)。
    """
    assert pic_before.shape == pic_after.shape, \
        f"shape mismatch: {pic_before.shape} vs {pic_after.shape}"

    # 归一化为 BGR
    if pic_before.shape[2] == 4:
        pic_before = cv2.cvtColor(pic_before, cv2.COLOR_BGRA2BGR)
        pic_after = cv2.cvtColor(pic_after, cv2.COLOR_BGRA2BGR)

    h, w = pic_before.shape[:2]

    # 1. 灰度差分 + 去低频噪声
    g0 = cv2.cvtColor(pic_before, cv2.COLOR_BGR2GRAY).astype(np.int16)
    g1 = cv2.cvtColor(pic_after, cv2.COLOR_BGR2GRAY).astype(np.int16)
    diff = np.abs(g0 - g1).astype(np.uint8)
    diff = cv2.GaussianBlur(diff, (5, 5), 0)

    # 2. 按列累加差分强度 → x 轴能量曲线
    col_energy = diff.sum(axis=0).astype(np.float32)

    # 3. 屏蔽左侧（滑块初始位置区，默认 15% 宽）干扰
    mask_left = int(w * 0.15)
    col_energy[:mask_left] = 0

    # 4. 平滑 + 取峰
    kernel = np.ones(11, dtype=np.float32) / 11
    smoothed = np.convolve(col_energy, kernel, mode='same')
    gap_x = int(smoothed.argmax())

    if debug:
        vis = cv2.cvtColor(diff, cv2.COLOR_GRAY2BGR)
        cv2.line(vis, (gap_x, 0), (gap_x, h), (0, 0, 255), 2)
        return gap_x, vis

    return gap_x


def detect_gap_edge(bg: np.ndarray, min_area: int = 400, max_area: int = 8000, debug: bool = False):
    """单图边缘法：Canny + 轮廓，找最像缺口的区域。

    Args:
        bg: BGR np.ndarray。
        min_area / max_area: 缺口面积范围（像素²），过滤文字/其它干扰。

    Returns:
        int: 缺口中心像素 x（未找到时抛 ValueError）。
    """
    if bg.shape[2] == 4:
        bg = cv2.cvtColor(bg, cv2.COLOR_BGRA2BGR)

    gray = cv2.cvtColor(bg, cv2.COLOR_BGR2GRAY)
    gray = cv2.GaussianBlur(gray, (3, 3), 0)
    edges = cv2.Canny(gray, 80, 200)

    # 闭操作让缺口轮廓封闭
    edges = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))

    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    h, w = bg.shape[:2]
    mask_left = int(w * 0.15)

    candidates = []
    for c in contours:
        x, y, cw, ch = cv2.boundingRect(c)
        if x < mask_left:
            continue
        area = cw * ch
        if not (min_area <= area <= max_area):
            continue
        # 长宽比约 0.7~1.4，过滤长条文字
        ratio = cw / max(ch, 1)
        if not 0.6 <= ratio <= 1.6:
            continue
        candidates.append((x + cw // 2, y + ch // 2, cw, ch, area))

    if not candidates:
        raise ValueError("no gap-like contour found; try adjusting min/max_area")

    # 取 y 接近图像中心 & 面积适中
    cy_ref = h / 2
    candidates.sort(key=lambda t: abs(t[1] - cy_ref) + abs(t[4] - 2500) * 0.01)
    best = candidates[0]

    if debug:
        vis = bg.copy()
        cv2.circle(vis, (best[0], best[1]), max(best[2], best[3]) // 2, (0, 0, 255), 2)
        return best[0], vis

    return best[0]


def decode_image(data) -> np.ndarray:
    """兼容多种输入：bytes / base64 str / 文件路径 / 已是 ndarray。"""
    if isinstance(data, np.ndarray):
        return data
    if isinstance(data, (bytes, bytearray)):
        return cv2.imdecode(np.frombuffer(data, dtype=np.uint8), cv2.IMREAD_UNCHANGED)
    if isinstance(data, str):
        if data.startswith('data:image'):
            data = data.split(',', 1)[1]
        if len(data) > 256 and ' ' not in data and '\n' not in data:
            import base64
            raw = base64.b64decode(data)
            return cv2.imdecode(np.frombuffer(raw, dtype=np.uint8), cv2.IMREAD_UNCHANGED)
        return cv2.imread(data, cv2.IMREAD_UNCHANGED)
    raise TypeError(f"unsupported image input: {type(data)}")


if __name__ == '__main__':
    # 自检
    rng = np.random.default_rng(0)
    bg = rng.integers(100, 200, size=(160, 360, 3), dtype=np.uint8)
    before = bg.copy()
    cv2.rectangle(before, (240, 60), (280, 100), (30, 30, 30), -1)
    after = before.copy()
    cv2.rectangle(after, (0, 60), (40, 100), (200, 200, 200), -1)
    cv2.rectangle(after, (240, 60), (280, 100), (60, 60, 60), -1)

    x_dual = detect_gap_dual(before, after)
    x_edge = detect_gap_edge(before)
    print(f"dual={x_dual} edge={x_edge} (expected≈260)")
    assert 240 <= x_dual <= 280, f"dual 模式偏差过大: {x_dual}"
    assert 240 <= x_edge <= 280, f"edge 模式偏差过大: {x_edge}"
    print("OK gap_detect 自检通过")
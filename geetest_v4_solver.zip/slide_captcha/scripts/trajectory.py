# coding=utf-8
"""
人手轨迹生成器 (Pure Function)
=================================

输入：要滑动的水平距离 distance（像素）
输出：[(dx, dy, dt), ...] 增量序列；调用方按需 sleep(dt) 后位移 (dx, dy)

物理模型核心：
- 二阶动力学：a = (target - now) * (|target - now|^k) * trig_jitter + noise
- 临近目标时按距离阶梯式增大阻尼系数 nnf，模拟人在末端"减速锁定"
- y 方向幅度远小于 x，并叠加 sin(y)/cos(x) 让轨迹非线性可微
- 起点添加随机超出（"过冲" overshoot）再回拉，破坏机器人式直线特征

注意：返回纯增量，与坐标系无关。
"""

import math
import random
import numpy as np


def human_drag_trajectory(
    distance,
    start_x=10,
    start_y=10,
    seed=None,
):
    """生成仿真人手拖拽轨迹增量序列。

    Args:
        distance: 水平方向需要滑动的目标像素距离（>0 向右，<0 向左）。
        start_x, start_y: 在握住的滑块上落点的偏移（让 mousedown 不在中心，更像人）。
        seed: 复现用随机种子。None=每次不同。

    Returns:
        list of (dx, dy, dt)：相对前一步的位移增量与等待秒数。
        最后一帧已是"落点"，调用方完成 release 即可。
    """
    if seed is not None:
        random.seed(seed)
        np.random.seed(seed)

    nowx, nowy = float(start_x), float(start_y)
    objx = nowx + distance
    objy = nowy + random.randint(-100, 100)

    # 初始速度：朝目标方向给一个反向冲量，制造"先回拉再加速"的人手特征
    v = np.array([random.randint(10, 120), random.randint(-50, 50) - 0.5]) * -4.0
    a = np.array([0.0, 0.0])

    # 末端阻尼阶梯：越接近目标阻尼越大
    nnf = random.random() * 0.15 + 0.2
    nnfs = [
        (random.randint(80, 120), random.random() * 0.3502 + 0.04),
        (random.randint(40, 60), random.random() * 0.31 + 0.10),
        (random.randint(20, 40), random.random() * 0.10 + 0.10),
        (random.randint(6, 20), random.random() * 0.315 + 0.10),
        (random.randint(4, 7), random.random() * 0.315 + 0.20),
    ]

    # 噪声目标点
    sp = 70
    ox, oy = objx + random.randint(-sp, sp), objy + random.randint(-sp, sp)
    tp = random.random() * 0.06 + 0.08
    texp = random.random() * 0.6 + 1.0

    trace = []
    tm = 0
    steps = random.randint(10, 15)

    for ii in range(steps):
        t = random.randint(20, 40) * 1e-2 * tp
        wait = max(0.0, t * (texp - ii / 1700))

        # 噪声目标周期性回到真目标
        ovx = (objx - ox) * random.randint(100, 500)
        ovy = (objy - oy) * random.randint(20, 40)
        ox += ovx * t
        oy += ovy * t
        if random.random() < 0.8:
            ox, oy = objx, objy

        # 加速度
        a[0] = ((ox - nowx) * (max(abs(ox - nowx), 100) ** 1.1)) * (1 + math.sin(nowy)) + random.randint(-10, 100)
        a[1] = ((oy - nowy) * (max(abs(oy - nowy), 50) ** 0.5)) * (2 + random.randint(2, 13) * math.cos(nowx)) + random.randint(-50, 60)
        a = a.clip(-3500, 3500)

        v += a * t

        # 末端阻尼
        for z, nf in nnfs:
            if abs(objx - nowx) < z:
                nnf = nf
        v -= v * nnf

        prevx, prevy = nowx, nowy
        nowx += v[0] * t
        nowy += v[1] * t
        trace.append((nowx - prevx, nowy - prevy, wait))

        # 命中提前退出
        if abs(nowx - objx) < 1:
            tm += 1
            if tm > 4:
                break

    # 末帧：精确落点 + 0.2s 停顿
    last_dx = objx - nowx
    trace.append((last_dx, 0.0, 0.2))

    return trace


def total_path(trace):
    """工具函数：累加 trace，便于调试 / 可视化。"""
    x = y = 0.0
    pts = [(0.0, 0.0)]
    for dx, dy, _ in trace:
        x += dx
        y += dy
        pts.append((x, y))
    return pts


if __name__ == '__main__':
    # 自检
    a = human_drag_trajectory(180, seed=42)
    b = human_drag_trajectory(180, seed=42)
    c = human_drag_trajectory(180, seed=99)
    assert a == b, "seed 复现失败"
    assert a != c, "seed 隔离失败"
    pts = total_path(a)
    assert abs(pts[-1][0] - 180) < 1.5, f"X 落点偏差过大: {pts[-1]}"
    print(f"OK steps={len(a)} 末点={pts[-1]} 总耗时={sum(x[2] for x in a):.2f}s")
#!/usr/bin/env python3
"""Quick script: login to Outlook web to activate mailbox, then test IMAP/SMTP"""
import os, sys, time, json, imaplib, smtplib, base64, requests
os.environ['DISPLAY'] = ':99'

EMAIL = 'zaguloyd86676@outlook.com'
PASSWORD = 'a^!k7U&8kxLiMx'
CLIENT_ID = '9e5f94bc-e8a4-4e73-b8be-63364c29d753'

FIREFOX = '/home/node/.cache/ruyipage/browsers/firefox-151.0a1-151-ruyi-linux-x86_64/firefox/firefox'

sys.path.insert(0, '/tmp/outlook_register')
from ruyipage import FirefoxPage, FirefoxOptions
from controllers.ruyipage_controller import RuyiPageController
import tempfile

ctrl = RuyiPageController()
profile = tempfile.mkdtemp(prefix='ruyi-activate-')
opts = FirefoxOptions()
opts.set_user_dir(profile)
opts.close_on_exit(True)
opts.set_browser_path(FIREFOX)
page = FirefoxPage(opts)

try:
    page.set_viewport(1024, 768)
except:
    pass

def wfa(p, locators, timeout=8):
    end = time.time() + timeout
    while time.time() < end:
        for loc in locators:
            try:
                el = p.ele(loc, timeout=0.3)
                if el:
                    return el
            except:
                pass
        p.wait(0.3)
    return False

try:
    print("[1] Logging in to Outlook Web...", flush=True)
    page.get('https://login.live.com/', wait='interactive', timeout=20)
    page.wait(3)

    # Email
    li = wfa(page, ['css:[name="loginfmt"]', 'css:#i0116'], timeout=10)
    if li:
        print(f"  Entering email: {EMAIL}", flush=True)
        try:
            li.input(EMAIL, clear=True)
        except:
            pass
        page.wait(0.5)
        nxt = wfa(page, ['css:#idSIButton9'], timeout=5)
        if nxt:
            try:
                nxt.click()
            except:
                pass
        page.wait(4)

    # Password
    pi = wfa(page, ['css:[name="passwd"]', 'css:#i0118'], timeout=10)
    if pi:
        print("  Entering password...", flush=True)
        try:
            pi.input(PASSWORD, clear=True)
        except:
            pass
        page.wait(0.5)
        si = wfa(page, ['css:#idSIButton9'], timeout=5)
        if si:
            try:
                si.click()
            except:
                pass
        page.wait(5)

    # Stay signed in
    for _ in range(3):
        cb = wfa(page, ['css:#idSIButton9'], timeout=5)
        if cb:
            try:
                cb.click()
            except:
                pass
            page.wait(3)
        else:
            break

    cur = page.url or ''
    print(f"  After login: {cur[:80]}", flush=True)

    # Navigate to mail
    print("[2] Opening Outlook Mail...", flush=True)
    page.get('https://outlook.live.com/mail/0/', wait='interactive', timeout=20)
    page.wait(8)

    cur = page.url or ''
    print(f"  Mail URL: {cur[:80]}", flush=True)
    
    # Check if mailbox UI loaded
    mailbox_keywords = ['收件箱', 'Inbox', '新邮件', 'New mail', '重点', 'Focused']
    pt = page.run_js('return document.body?document.body.innerText.substring(0,800):""', as_expr=False)
    found = [k for k in mailbox_keywords if k in pt]
    print(f"  Mailbox keywords found: {found}", flush=True)
    
    if not found:
        print(f"  Page preview: {pt[:300]}", flush=True)
    else:
        print("  ✅ Mailbox loaded!", flush=True)

    # Wait extra time for backend provisioning
    print("[3] Waiting 15s for backend provisioning...", flush=True)
    page.wait(15)

finally:
    try:
        page.quit(timeout=5, force=True)
    except:
        pass

# Now test IMAP/SMTP
print("\n[4] Testing IMAP/SMTP...", flush=True)

# Read and refresh token
with open('/tmp/outlook_register/Results/v4_token.txt') as f:
    for line in f:
        parts = line.strip().split('----')
        if len(parts) == 4 and parts[0] == EMAIL:
            rt = parts[3]
            break
    else:
        print("No token found!"); exit()

r = requests.post('https://login.microsoftonline.com/consumers/oauth2/v2.0/token', data={
    'client_id': CLIENT_ID, 'grant_type': 'refresh_token', 'refresh_token': rt,
    'scope': 'offline_access https://outlook.office.com/IMAP.AccessAsUser.All https://outlook.office.com/SMTP.Send'
}, headers={'Content-Type': 'application/x-www-form-urlencoded'}, timeout=15)

tokens = r.json()
if 'access_token' not in tokens:
    print(f"Token refresh failed: {json.dumps(tokens)[:200]}")
    exit()

at = tokens['access_token']
print(f"  Token refreshed OK ({len(at)} chars)", flush=True)

# IMAP
try:
    mail = imaplib.IMAP4_SSL('outlook.office365.com', 993, timeout=15)
    auth = f'user={EMAIL}\x01auth=Bearer {at}\x01\x01'
    mail.authenticate('XOAUTH2', lambda x: auth.encode())
    mail.select('INBOX')
    typ, data = mail.search(None, 'ALL')
    count = len(data[0].split()) if data[0] else 0
    print(f"  ✅ IMAP OK! {count} messages", flush=True)
    mail.logout()
except Exception as e:
    print(f"  ❌ IMAP: {e}", flush=True)

# SMTP
try:
    server = smtplib.SMTP('smtp-mail.outlook.com', 587, timeout=15)
    server.ehlo()
    server.starttls()
    server.ehlo()
    auth_b64 = base64.b64encode(f'user={EMAIL}\x01auth=Bearer {at}\x01\x01'.encode()).decode()
    code, resp = server.docmd('AUTH', 'XOAUTH2 ' + auth_b64)
    if code == 235:
        print(f"  ✅ SMTP OK!", flush=True)
    else:
        print(f"  ❌ SMTP: code={code}", flush=True)
    server.docmd('QUIT')
except Exception as e:
    print(f"  ❌ SMTP: {e}", flush=True)
#!/usr/bin/env python3
import os, sys, time
os.environ['DISPLAY'] = ':99'
FIREFOX = '/home/node/.cache/ruyipage/browsers/firefox-151.0a1-151-ruyi-linux-x86_64/firefox/firefox'
from ruyipage import FirefoxPage, FirefoxOptions
import tempfile, random, string

def wait_for_any(page, locators, timeout=5):
    end_time = time.time() + timeout
    while time.time() < end_time:
        for loc in locators:
            try:
                el = page.ele(loc, timeout=0.2)
                if el: return el
            except: pass
        page.wait(0.3)
    return False

def click_btn(page):
    btn = wait_for_any(page, ['css:[data-testid="primaryButton"]', 'css:button[type="submit"]', 'css:button.fui-Button'], timeout=5)
    if btn:
        try: page.actions.move_to(btn, duration=random.randint(80,180)).click().perform()
        except: btn.click()
    return bool(btn)

profile = tempfile.mkdtemp(prefix='ruyi-capdebug2-')
opts = FirefoxOptions()
opts.set_user_dir(profile)
opts.close_on_exit(True)
opts.set_browser_path(FIREFOX)
opts.set_pref('intl.accept_languages', 'zh-CN,zh,en-US,en')
opts.set_human_algorithm('windmouse')
from faker import Faker
fake = Faker()

print('Starting...', flush=True)
page = FirefoxPage(opts)
try: page.set_viewport(1024, 768)
except: pass

try:
    email_local = 'cdeb' + str(random.randint(10000,99999))
    password = 'Ca\$2026debug!Xz'
    year = str(random.randint(1970, 2000))
    month = str(random.randint(1,12))
    day = str(random.randint(1,28))
    lastname = fake.last_name()
    firstname = fake.first_name()

    page.get('https://outlook.live.com/mail/0/?prompt=create_account&mkt=ZH-CN', wait='complete', timeout=30)
    page.wait(8)

    # Consent
    c = wait_for_any(page, ["xpath://button[contains(normalize-space(.), '同意并继续')]"], timeout=5)
    if c:
        try: c.click()
        except: pass
        page.wait(2)

    # Email
    ei = wait_for_any(page, ['css:input[name="MemberName"]', 'css:[aria-label="新建电子邮件"]'], timeout=10)
    if ei:
        try: ei.click()
        except: pass
        ei.input(email_local, clear=True)
        page.wait(0.5)
        click_btn(page)
        page.wait(2)

    # Password
    pi = wait_for_any(page, ['css:input[type="password"]'], timeout=10)
    if pi:
        try: pi.click()
        except: pass
        pi.input(password, clear=True)
        page.wait(0.5)
        click_btn(page)
        page.wait(3)

    # Birthday merged page
    # Country
    cb = wait_for_any(page, ['css:#countryDropdownId'], timeout=10)
    if cb:
        try: cb.click()
        except: pass
        page.wait(1)
        us = wait_for_any(page, ["xpath://*[@role='option'][contains(.,'United States')]"], timeout=5)
        if us:
            try: us.click()
            except: pass
        page.wait(1)

    # Month
    mb = None
    try: mb = page.ele('css:#BirthMonthDropdown', timeout=5)
    except: pass
    if mb:
        try: mb.click()
        except: pass
        page.wait(0.8)
        ms = wait_for_any(page, [f"xpath://*[@role='option'][normalize-space(.)='{month}月']"], timeout=3)
        if ms:
            try: ms.click()
            except: pass
        page.wait(0.5)

    # Day
    db = None
    try: db = page.ele('css:#BirthDayDropdown', timeout=5)
    except: pass
    if db:
        try: db.click()
        except: pass
        page.wait(0.8)
        ds = wait_for_any(page, [f"xpath://*[@role='option'][normalize-space(.)='{day}日']", f"xpath://*[@role='option'][normalize-space(.)='{int(day)}日']"], timeout=3)
        if ds:
            try: ds.click()
            except: pass
        page.wait(0.5)

    # Year
    try:
        yi = page.ele('css:input[name=BirthYear]', timeout=5)
        if yi:
            yi.click()
            page.wait(0.2)
            yi.input(year, clear=True)
    except: pass
    page.run_js(f"var y=document.querySelector('input[name=BirthYear]');if(y){{y.value='{year}';y.dispatchEvent(new Event('input',{{bubbles:true}}));y.dispatchEvent(new Event('change',{{bubbles:true}}));}}", as_expr=False)
    page.wait(1)
    click_btn(page)
    page.wait(5)

    # Name
    ln = wait_for_any(page, ['css:#lastNameInput', 'css:input[name="LastName"]'], timeout=10)
    fn = wait_for_any(page, ['css:#firstNameInput', 'css:input[name="FirstName"]'], timeout=10)
    if ln:
        try: ln.click()
        except: pass
        ln.input(lastname, clear=True)
    if fn: fn.input(firstname, clear=True)
    page.wait(1)
    click_btn(page)
    page.wait(5)

    # Check for CAPTCHA
    pt = page.run_js("return document.body?document.body.innerText.substring(0,400):''", as_expr=False)
    print(f'Page text after name: {pt[:200]}', flush=True)

    if '机器人' in pt or '长按' in pt or 'CAPTCHA' in pt.upper() or 'press' in pt.lower():
        print('CAPTCHA PAGE!', flush=True)
        page.screenshot(path='/tmp/outlook_register/Results/captcha_page_v2.png')
        
        # Dump ALL elements with their full attributes
        dom = page.run_js('''
            var all = document.querySelectorAll("*");
            var result = [];
            for (var el of all) {
                var attrs = {};
                for (var i = 0; i < el.attributes.length; i++) {
                    attrs[el.attributes[i].name] = el.attributes[i].value.substring(0, 80);
                }
                var style = window.getComputedStyle(el);
                if (style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0") {
                    var rect = el.getBoundingClientRect();
                    if (rect.width > 0 && rect.height > 0 && rect.top < 800) {
                        result.push({
                            tag: el.tagName,
                            id: el.id || "",
                            className: (el.className || "").substring(0, 80),
                            text: el.textContent.trim().substring(0, 40),
                            role: el.getAttribute("role") || "",
                            ariaLabel: el.getAttribute("aria-label") || "",
                            tabindex: el.getAttribute("tabindex") || "",
                            type: el.type || "",
                            width: Math.round(rect.width),
                            height: Math.round(rect.height),
                            top: Math.round(rect.top),
                            left: Math.round(rect.left),
                            attrs: JSON.stringify(attrs).substring(0, 200)
                        });
                    }
                }
            }
            return JSON.stringify(result, null, 2);
        ''', as_expr=False)
        print('VISIBLE ELEMENTS:', flush=True)
        print(dom[:5000], flush=True)
    else:
        print(f'No CAPTCHA. URL: {page.url}', flush=True)

except Exception as e:
    print(f'Error: {e}', flush=True)
    import traceback
    traceback.print_exc()
finally:
    try: page.quit(timeout=5, force=True)
    except: pass

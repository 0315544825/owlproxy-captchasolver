#!/usr/bin/env python3
"""Get to CAPTCHA page, navigate into iframe, solve hold button"""
import os, sys, time
os.environ['DISPLAY'] = ':99'
FIREFOX = '/home/node/.cache/ruyipage/browsers/firefox-151.0a1-151-ruyi-linux-x86_64/firefox/firefox'
from ruyipage import FirefoxPage, FirefoxOptions
import tempfile, random, string

def wfa(page, locs, t=5):
    end_time = time.time() + t
    while time.time() < end_time:
        for loc in locs:
            try:
                el = page.ele(loc, timeout=0.2)
                if el: return el
            except: pass
        page.wait(0.3)
    return False

def cbtn(page):
    b = wfa(page, ['css:[data-testid="primaryButton"]', 'css:button[type="submit"]'], t=5)
    if b:
        try: b.click()
        except: pass

def do_register(page, email_local, password, year, month, day, lastname, firstname):
    """Do the full registration up to CAPTCHA or success"""
    page.get('https://outlook.live.com/mail/0/?prompt=create_account&mkt=ZH-CN', wait='complete', timeout=30)
    page.wait(8)
    
    c = wfa(page, ["xpath://button[contains(normalize-space(.), '同意并继续')]"], t=5)
    if c:
        try: c.click()
        except: pass
        page.wait(2)
    
    ei = wfa(page, ['css:input[name="MemberName"]', 'css:[aria-label="新建电子邮件"]'], t=10)
    if not ei: return False
    try: ei.click()
    except: pass
    ei.input(email_local, clear=True)
    page.wait(0.5)
    cbtn(page)
    page.wait(2)

    pi = wfa(page, ['css:input[type="password"]'], t=10)
    if not pi: return False
    try: pi.click()
    except: pass
    pi.input(password, clear=True)
    page.wait(0.5)
    cbtn(page)
    page.wait(3)

    # Country
    cb = wfa(page, ['css:#countryDropdownId'], t=10)
    if cb:
        try: cb.click()
        except: pass
        page.wait(1)
        us = wfa(page, ["xpath://*[@role='option'][contains(.,'United States')]"], t=5)
        if us:
            try: us.click()
            except: pass
        page.wait(1)

    # Month
    try:
        mb = page.ele('css:#BirthMonthDropdown', timeout=5)
        if mb:
            mb.click()
            page.wait(0.8)
            ms = wfa(page, [f"xpath://*[@role='option'][normalize-space(.)='{month}月']"], t=3)
            if ms:
                try: ms.click()
                except: pass
            page.wait(0.5)
    except: pass

    # Day
    try:
        db = page.ele('css:#BirthDayDropdown', timeout=5)
        if db:
            db.click()
            page.wait(0.8)
            ds = wfa(page, [f"xpath://*[@role='option'][normalize-space(.)='{day}日']", f"xpath://*[@role='option'][normalize-space(.)='{int(day)}日']"], t=3)
            if ds:
                try: ds.click()
                except: pass
            page.wait(0.5)
    except: pass

    # Year
    try:
        yi = page.ele('css:input[name=BirthYear]', timeout=5)
        if yi:
            yi.click()
            page.wait(0.2)
            yi.input(year, clear=True)
    except: pass
    page.run_js(f"var y=document.querySelector('input[name=BirthYear]');if(y){{y.value='{year}';y.dispatchEvent(new Event('input',{{bubbles:true}}));}}", as_expr=False)
    page.wait(1)
    cbtn(page)
    page.wait(5)

    # Name
    ln = wfa(page, ['css:#lastNameInput'], t=10)
    fn = wfa(page, ['css:#firstNameInput'], t=10)
    if ln:
        try: ln.click()
        except: pass
        ln.input(lastname, clear=True)
    if fn:
        fn.input(firstname, clear=True)
    page.wait(1)
    cbtn(page)
    page.wait(5)

    return True


def main():
    profile = tempfile.mkdtemp(prefix='ruyi-hold-')
    opts = FirefoxOptions()
    opts.set_user_dir(profile)
    opts.close_on_exit(True)
    opts.set_browser_path(FIREFOX)
    opts.set_pref('intl.accept_languages', 'zh-CN,zh,en-US,en')
    opts.set_human_algorithm('windmouse')
    from faker import Faker
    fake = Faker()

    email_local = 'xhold' + str(random.randint(10000,99999))
    password = 'H0ld\$2026Xyz!'
    year = str(random.randint(1970, 2000))
    month = str(random.randint(1,12))
    day = str(random.randint(1,28))
    lastname = fake.last_name()
    firstname = fake.first_name()

    print(f'Registering: {email_local}@outlook.com', flush=True)
    page = FirefoxPage(opts)
    try: page.set_viewport(1024, 768)
    except: pass

    try:
        do_register(page, email_local, password, year, month, day, lastname, firstname)

        pt = page.run_js("return document.body?document.body.innerText.substring(0,300):''", as_expr=False)
        print(f'Page after reg: {pt[:150]}', flush=True)

        if '机器人' not in pt and '长按' not in pt:
            print('No CAPTCHA! Might have passed.', flush=True)
            return

        print('CAPTCHA! Getting iframe src...', flush=True)
        iframe_src = page.run_js("var i=document.querySelector('iframe');return i?i.src:'none';", as_expr=False)
        print(f'iframe URL: {iframe_src[:150]}', flush=True)

        if iframe_src and iframe_src != 'none':
            # Navigate directly to the captcha iframe page
            print('Navigating to captcha page directly...', flush=True)
            page.get(iframe_src, wait='complete', timeout=15)
            page.wait(3)

            # Dump ALL interactive elements
            cap_dom = page.run_js('''
                var els = document.querySelectorAll("*");
                var r = [];
                for (var el of els) {
                    var rect = el.getBoundingClientRect();
                    if (rect.width > 5 && rect.height > 5) {
                        r.push({
                            tag: el.tagName, id: el.id || "",
                            cls: String(el.className).substring(0, 40),
                            role: el.getAttribute("role") || "",
                            aria: el.getAttribute("aria-label") || "",
                            text: el.textContent.trim().substring(0, 30),
                            w: Math.round(rect.width), h: Math.round(rect.height),
                            t: Math.round(rect.top), l: Math.round(rect.left)
                        });
                    }
                }
                return JSON.stringify(r.slice(0, 50), null, 2);
            ''', as_expr=False)
            print(f'CAPTCHA IFRAME DOM:\n{cap_dom[:5000]}', flush=True)

            # Take screenshot
            page.screenshot(path='/tmp/outlook_register/Results/captcha_inside.png')

            # Try to find and press-hold the button
            btn = wfa(page, [
                'css:button', 'css:[role="button"]',
                'css:.px-captcha-btn', 'css:[data-testid]',
            ], t=5)
            if btn:
                print(f'Found button! text={btn.text[:30]} aria={btn.attr("aria-label","")}', flush=True)
                try:
                    # Try long press via actions
                    page.actions.move_to(btn, duration=200)
                    page.wait(0.3)
                    # mousedown -> wait -> mouseup
                    page.run_js('''
                        var btn = document.querySelector('button') || document.querySelector('[role=button]');
                        if(btn) {
                            btn.dispatchEvent(new MouseEvent('mousedown', {bubbles:true, cancelable:true}));
                        }
                    ''', as_expr=False)
                    page.wait(3)
                    page.run_js('''
                        var btn = document.querySelector('button') || document.querySelector('[role=button]');
                        if(btn) {
                            btn.dispatchEvent(new MouseEvent('mouseup', {bubbles:true, cancelable:true}));
                        }
                    ''', as_expr=False)
                    page.wait(5)
                except Exception as e:
                    print(f'Hold error: {e}', flush=True)
            else:
                print('No button found in iframe page', flush=True)
                # Try clicking any clickable area
                page.run_js('''
                    var els = document.querySelectorAll("div, button, span");
                    for (var el of els) {
                        if (el.offsetWidth > 50 && el.offsetHeight > 20 && el.offsetHeight < 60) {
                            el.dispatchEvent(new MouseEvent('mousedown', {bubbles:true}));
                            break;
                        }
                    }
                ''', as_expr=False)
                page.wait(3)
                page.run_js('''
                    var els = document.querySelectorAll("div, button, span");
                    for (var el of els) {
                        if (el.offsetWidth > 50 && el.offsetHeight > 20 && el.offsetHeight < 60) {
                            el.dispatchEvent(new MouseEvent('mouseup', {bubbles:true}));
                            break;
                        }
                    }
                ''', as_expr=False)
                page.wait(5)

            page.screenshot(path='/tmp/outlook_register/Results/captcha_after_attempt.png')
            final_text = page.run_js("return document.body?document.body.innerText.substring(0,200):''", as_expr=False)
            print(f'Final page: {final_text[:200]}', flush=True)

    except Exception as e:
        print(f'ERR: {e}', flush=True)
        import traceback
        traceback.print_exc()
    finally:
        try: page.quit(timeout=3, force=True)
        except: pass

if __name__ == '__main__':
    main()
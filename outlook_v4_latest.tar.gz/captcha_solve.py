#!/usr/bin/env python3
"""Get to CAPTCHA page and solve it by accessing the iframe"""
import os, sys, time
os.environ['DISPLAY'] = ':99'
FIREFOX = '/home/node/.cache/ruyipage/browsers/firefox-151.0a1-151-ruyi-linux-x86_64/firefox/firefox'
from ruyipage import FirefoxPage, FirefoxOptions
import tempfile, random, string

def wfa(page, locs, t=5):
    e = time.time() + t
    while time.time() < e:
        for l in locs:
            try:
                el = page.ele(l, timeout=0.2)
                if el: return el
            except: pass
        page.wait(0.3)
    return False

def cbtn(page):
    b = wfa(page, ['css:[data-testid="primaryButton"]', 'css:button[type="submit"]', 'css:button.fui-Button'], t=5)
    if b:
        try: b.click()
        except: pass
    return bool(b)

profile = tempfile.mkdtemp(prefix='ruyi-csolve-')
opts = FirefoxOptions()
opts.set_user_dir(profile)
opts.close_on_exit(True)
opts.set_browser_path(FIREFOX)
opts.set_pref('intl.accept_languages', 'zh-CN,zh,en-US,en')
opts.set_human_algorithm('windmouse')
from faker import Faker
fake = Faker()

print('Starting...', flush=True)
page = FirefoxPage(opts)
try: page.set_viewport(1024, 768)
except: pass

try:
    email_local = 'xfast' + str(random.randint(10000,99999))
    password = 'Xa\$2026!qWer'
    year = str(random.randint(1970, 2000))
    month = str(random.randint(1,12))
    day = str(random.randint(1,28))
    full_email = f'{email_local}@outlook.com'

    page.get('https://outlook.live.com/mail/0/?prompt=create_account&mkt=ZH-CN', wait='complete', timeout=30)
    page.wait(8)
    c = wfa(page, ["xpath://button[contains(normalize-space(.), '同意并继续')]"], t=5)
    if c:
        try: c.click()
        except: pass
        page.wait(2)
    ei = wfa(page, ['css:input[name="MemberName"]', 'css:[aria-label="新建电子邮件"]'], t=10)
    if ei:
        try: ei.click()
        except: pass
        ei.input(email_local, clear=True)
        page.wait(0.5)
        cbtn(page)
        page.wait(2)
    pi = wfa(page, ['css:input[type="password"]'], t=10)
    if pi:
        try: pi.click()
        except: pass
        pi.input(password, clear=True)
        page.wait(0.5)
        cbtn(page)
        page.wait(3)
    cb = wfa(page, ['css:#countryDropdownId'], t=10)
    if cb:
        try: cb.click()
        except: pass
        page.wait(1)
        us = wfa(page, ["xpath://*[@role='option'][contains(.,'United States')]"], t=5)
        if us:
            try: us.click()
            except: pass
        page.wait(1)
    try:
        mb = page.ele('css:#BirthMonthDropdown', timeout=5)
        if mb:
            mb.click()
            page.wait(0.8)
            ms = wfa(page, [f"xpath://*[@role='option'][normalize-space(.)='{month}月']"], t=3)
            if ms:
                try: ms.click()
                except: pass
            page.wait(0.5)
    except: pass
    try:
        db = page.ele('css:#BirthDayDropdown', timeout=5)
        if db:
            db.click()
            page.wait(0.8)
            ds = wfa(page, [f"xpath://*[@role='option'][normalize-space(.)='{day}日']", f"xpath://*[@role='option'][normalize-space(.)='{int(day)}日']"], t=3)
            if ds:
                try: ds.click()
                except: pass
            page.wait(0.5)
    except: pass
    try:
        yi = page.ele('css:input[name=BirthYear]', timeout=5)
        if yi:
            yi.click()
            page.wait(0.2)
            yi.input(year, clear=True)
    except: pass
    page.run_js(f"var y=document.querySelector('input[name=BirthYear]');if(y){{y.value='{year}';y.dispatchEvent(new Event('input',{{bubbles:true}}));}}", as_expr=False)
    page.wait(1)
    cbtn(page)
    page.wait(5)
    ln = wfa(page, ['css:#lastNameInput'], t=10)
    fn = wfa(page, ['css:#firstNameInput'], t=10)
    if ln:
        try: ln.click()
        except: pass
        ln.input(fake.last_name(), clear=True)
    if fn: fn.input(fake.first_name(), clear=True)
    page.wait(1)
    cbtn(page)
    page.wait(5)

    pt = page.run_js("return document.body?document.body.innerText.substring(0,300):''", as_expr=False)
    if '机器人' in pt or '长按' in pt:
        print('CAPTCHA REACHED! Accessing iframe...', flush=True)
        
        # Get iframe src
        iframe_src = page.run_js("""
            var iframe = document.querySelector('iframe');
            return iframe ? (iframe.src || iframe.getAttribute('src') || 'no-src') : 'no-iframe';
        """, as_expr=False)
        print(f'iframe src: {iframe_src[:200]}', flush=True)

        # Dump iframe contents via JS (cross-origin might block this)
        iframe_content = page.run_js("""
            try {
                var iframe = document.querySelector('iframe');
                if (iframe && iframe.contentDocument) {
                    var els = iframe.contentDocument.querySelectorAll('*');
                    var result = [];
                    for (var el of els) {
                        var r = el.getBoundingClientRect();
                        if (r.width > 5 && r.height > 5) {
                            result.push({
                                tag: el.tagName,
                                id: el.id || '',
                                cls: String(el.className).substring(0, 50),
                                role: el.getAttribute('role') || '',
                                aria: el.getAttribute('aria-label') || '',
                                text: el.textContent.trim().substring(0, 20),
                                w: Math.round(r.width),
                                h: Math.round(r.height)
                            });
                        }
                    }
                    return JSON.stringify(result, null, 2);
                }
                return 'CROSS-ORIGIN: cannot access iframe content';
            } catch(e) {
                return 'ERROR: ' + e.message;
            }
        """, as_expr=False)
        print(f'iframe content: {iframe_content[:3000]}', flush=True)
        
        # Try using ruyipage to switch into the iframe
        try:
            iframes = page.eles('css:iframe')
            print(f'Found {len(iframes)} iframes', flush=True)
            for i, iframe in enumerate(iframes):
                print(f'iframe[{i}]: src={iframe.attr("src","")[:100]} id={iframe.attr("id","")}', flush=True)
        except Exception as e:
            print(f'iframe list error: {e}', flush=True)

        # Try coordinate-based click at the button position
        # From DOM dump: iframe at top=495, left=332, w=360, h=90
        # The button should be inside, roughly centered
        btn_x = 332 + 180  # center of iframe
        btn_y = 495 + 45   # center of iframe
        print(f'Trying coordinate click at ({btn_x}, {btn_y})...', flush=True)
        
        # Try click and hold at that position
        try:
            page.actions.move_to(btn_x, btn_y).click_and_hold().perform()
            page.wait(4)
            page.actions.release().perform()
            page.wait(5)
            print('Click-and-hold done!', flush=True)
        except Exception as e:
            print(f'Action error: {e}', flush=True)
            # Fallback: try clicking the iframe element directly
            try:
                iframe_el = page.ele('css:iframe', timeout=5)
                if iframe_el:
                    print('Found iframe element, trying click...', flush=True)
                    iframe_el.click()
                    page.wait(3)
            except: pass

        # Check result
        page.screenshot(path='/tmp/outlook_register/Results/captcha_after_hold.png')
        pt2 = page.run_js("return document.body?document.body.innerText.substring(0,300):''", as_expr=False)
        print(f'After hold page: {pt2[:200]}', flush=True)

        # Wait and check if we got past CAPTCHA
        for check in range(10):
            url = page.url or ''
            if 'outlook.live.com/mail' in url:
                print('PASSED CAPTCHA! URL has mail!', flush=True)
                break
            pt3 = page.run_js("return document.body?document.body.innerText.substring(0,200):''", as_expr=False)
            if '机器人' not in pt3 and '长按' not in pt3:
                print(f'CAPTCHA gone! Page: {pt3[:100]}', flush=True)
                break
            page.wait(3)

    else:
        print(f'No captcha: {pt[:100]}', flush=True)

except Exception as e:
    print(f'ERR: {e}', flush=True)
    import traceback
    traceback.print_exc()
finally:
    try: page.quit(timeout=3, force=True)
    except: pass

#!/usr/bin/env python3
"""
Outlook full flow: Register + OAuth2 token acquisition
Uses Thunderbird client ID + /consumers endpoint for personal accounts
"""
import os, sys, time, random, string, secrets, tempfile, json, base64, hashlib
from urllib.parse import parse_qs, quote
from datetime import datetime

os.environ['DISPLAY'] = ':99'
FIREFOX_PATH = '/home/node/.cache/ruyipage/browsers/firefox-151.0a1-151-ruyi-linux-x86_64/firefox/firefox'
RESULTS_DIR = '/tmp/outlook_register/Results'
os.makedirs(RESULTS_DIR, exist_ok=True)

CLIENT_ID = '08162f7c-0fd2-4200-a84a-f25a4db0b584'
CLIENT_SECRET = 'TxRBilcHdC6WGBee]fs?QR:SJ8nI[g82'
REDIRECT = 'https://login.microsoftonline.com/common/oauth2/nativeclient'
SCOPES = 'https://outlook.office.com/IMAP.AccessAsUser.All https://outlook.office.com/SMTP.Send offline_access'


def generate_strong_password(length=None):
    if length is None:
        length = random.randint(11, 15)
    chars = string.ascii_letters + string.digits + "!@#$%^&*"
    while True:
        password = "".join(secrets.choice(chars) for _ in range(length))
        if (any(c.islower() for c in password) and any(c.isupper() for c in password)
                and any(c.isdigit() for c in password) and any(c in "!@#$%^&*" for c in password)):
            return password


def random_email():
    letter_count = random.randint(6, 8)
    digit_count = random.randint(5, 6)
    letters = "".join(random.choice(string.ascii_lowercase) for _ in range(letter_count))
    digits = "".join(random.choice(string.digits) for _ in range(digit_count))
    return letters + digits


def create_page():
    profile = tempfile.mkdtemp(prefix='ruyi-full-')
    from ruyipage import FirefoxPage, FirefoxOptions
    opts = FirefoxOptions()
    opts.set_user_dir(profile)
    opts.close_on_exit(True)
    opts.set_browser_path(FIREFOX_PATH)
    opts.set_human_algorithm("windmouse")
    page = FirefoxPage(opts)
    try: page.set_viewport(1024, 768)
    except: pass
    try: page.window.set_window_size(1050, 800)
    except: pass
    return page, profile


def wait_for_any(page, locators, timeout=5):
    end_time = time.time() + timeout
    while time.time() < end_time:
        for locator in locators:
            try:
                element = page.ele(locator, timeout=0.3)
                if element:
                    return element
            except: pass
        page.wait(0.3)
    return False


def text_exists(page, text):
    try:
        return bool(page.run_js(
            f"return !!document.body && document.body.innerText.includes('{text}');",
            as_expr=False,
        ))
    except:
        return False


def click_primary_button(page, timeout=5):
    # Try various submit/next buttons
    for locator in [
        "css:button[type='submit']",
        "css:[data-testid='primaryButton']",
        "css:button.fui-Button",
    ]:
        button = wait_for_any(page, [locator], timeout=2)
        if button:
            try:
                page.actions.move_to(button, duration=random.randint(80, 180)).click().perform()
                return True
            except:
                try: button.click(); return True
                except: pass
    # Last resort: find button containing "Next"
    btns = page.eles('css:button')
    if btns:
        for btn in btns:
            txt = ''
            try: txt = btn.text or btn.innerText
            except: pass
            if 'next' in txt.lower() or '下一步' in txt:
                try:
                    page.actions.move_to(btn, duration=random.randint(80, 180)).click().perform()
                    return True
                except:
                    try: btn.click(); return True
                    except: pass
    return False


def outlook_register(page):
    """Register a new outlook.com account. Returns (email, password) or (None, None)."""
    from faker import Faker
    fake = Faker()
    email_local = random_email()
    password = generate_strong_password()
    lastname = fake.last_name()
    firstname = fake.first_name()
    year = str(random.randint(1960, 2005))
    month = str(random.randint(1, 12))
    day = str(random.randint(1, 28))
    full_email = f"{email_local}@outlook.com"

    print(f"\n╔══════════════════════════════════════╗")
    print(f"║  Registering: {full_email}")
    print(f"║  Password:    {password}")
    print(f"║  Name:        {firstname} {lastname}")
    print(f"╚══════════════════════════════════════╝")

    try:
        # Navigate to signup
        print("[1] Going to signup page...")
        page.get("https://outlook.live.com/mail/0/?prompt=create_account", wait="complete", timeout=30)
        page.wait(8)

        # Consent button (Chinese locale)
        consent = wait_for_any(page, [
            "xpath://button[contains(normalize-space(.), '同意并继续')]",
            "xpath://*[@role='button'][contains(normalize-space(.), '同意并继续')]",
        ], timeout=5)
        if consent:
            print("[2] Clicking consent...")
            try: page.actions.move_to(consent, duration=random.randint(80, 180)).click().perform()
            except: consent.click()
            page.wait(2)

        # Email input
        print("[3] Entering email...")
        email_input = wait_for_any(page, [
            "css:input[name='email']",
            "css:[aria-label='New email']",
            "css:input[name='MemberName']",
            "css:[aria-label='新建电子邮件']",
        ], timeout=10)
        if not email_input:
            try:
                preview = page.run_js("return document.body ? document.body.innerText.substring(0, 300) : '';", as_expr=False)
                print(f"  [!] No email input. Page: {preview[:200]}")
            except: pass
            return None, None

        try: page.actions.move_to(email_input, duration=random.randint(80, 180)).click().perform()
        except: email_input.click()
        page.wait(0.3)
        email_input.input(email_local, clear=True)
        page.wait(0.5)

        if not click_primary_button(page):
            print("  [!] Next button not found after email")
            return None, None
        page.wait(2)

        # Password
        print("[4] Entering password...")
        pwd_input = wait_for_any(page, [
            "css:input[type='password']",
            "css:input[name='passwd']",
            "css:[aria-label='Password']",
            "css:[aria-label='密码']",
        ], timeout=10)
        if not pwd_input:
            print("  [!] Password input not found")
            return None, None
        try: page.actions.move_to(pwd_input, duration=random.randint(80, 180)).click().perform()
        except: pwd_input.click()
        page.wait(0.3)
        pwd_input.input(password, clear=True)
        page.wait(0.5)

        if not click_primary_button(page):
            print("  [!] Next button not found after password")
            return None, None
        page.wait(2)

        # After email+password, may get "Add some details" page 
        # (Country + Birthday in one step)
        time.sleep(2)
        page_text = ''
        try:
            page_text = page.run_js("return document.body ? document.body.innerText.substring(0, 500) : '';", as_expr=False)
        except: pass
        
        if 'Add some details' in page_text or 'Country/Region' in page_text or 'Birth year' in page_text.lower() or '出生' in page_text:
            print("[5] Processing combined details page (Country + Birthday)...")
            
            # Country dropdown
            country_btn = wait_for_any(page, [
                "css:button[name='countryDropdownName']",
                "css:#countryDropdownId",
            ], timeout=10)
            if country_btn:
                try:
                    page.actions.move_to(country_btn, duration=random.randint(80, 180)).click().perform()
                except: country_btn.click()
                page.wait(1)
                # Select United States
                us_opt = wait_for_any(page, [
                    "xpath://*[@role='option'][contains(.,'United States')]",
                    "xpath://li[contains(.,'United States')]",
                ], timeout=5)
                if us_opt:
                    try: us_opt.click()
                    except: page.run_js("var opts = document.querySelectorAll('[role=option]'); for(var o of opts) { if(o.textContent.includes('United States')) { o.click(); break; } }", as_expr=False)
                page.wait(1)
            
            # Birth month dropdown
            month_btn = wait_for_any(page, [
                "css:button[name='BirthMonth']",
                "css:#BirthMonthDropdown",
            ], timeout=5)
            if month_btn:
                try: month_btn.click()
                except: pass
                page.wait(0.5)
                month_sel = wait_for_any(page, [
                    f"xpath://*[@role='option'][contains(.,'{month}')]",
                ], timeout=3)
                if month_sel:
                    try: month_sel.click()
                    except: pass
                page.wait(0.5)
            
            # Birth day dropdown
            day_btn = wait_for_any(page, [
                "css:button[name='BirthDay']",
                "css:#BirthDayDropdown",
            ], timeout=5)
            if day_btn:
                try: day_btn.click()
                except: pass
                page.wait(0.5)
                day_sel = wait_for_any(page, [
                    f"xpath://*[@role='option'][normalize-space(.)='{day}']",
                ], timeout=3)
                if day_sel:
                    try: day_sel.click()
                    except: pass
                page.wait(0.5)
            
            # Birth year input
            year_input = wait_for_any(page, [
                "css:input[name='BirthYear']",
                "css:input[type='number']",
                "css:[aria-label='Birth year']",
                "css:[aria-label='年']",
                "css:input[aria-label='Year']",
            ], timeout=10)
            if year_input:
                try:
                    year_input.click()
                    page.wait(0.2)
                    year_input.input(year, clear=True)
                    page.wait(0.3)
                    # Verify value was set
                    val = year_input.value or year_input.attr('value') or ''
                    if not val:
                        page.run_js(f"var yel = document.querySelector('input[name=BirthYear], input[type=number]'); if(yel) {{ yel.value = '{year}'; yel.dispatchEvent(new Event('input', {{bubbles:true}})); yel.dispatchEvent(new Event('change', {{bubbles:true}})); }}", as_expr=False)
                except:
                    page.run_js(f"var yel = document.querySelector('input[name=BirthYear], input[type=number]'); if(yel) {{ yel.value = '{year}'; yel.dispatchEvent(new Event('input', {{bubbles:true}})); yel.dispatchEvent(new Event('change', {{bubbles:true}})); }}", as_expr=False)
            else:
                # Debug screenshot if year input not found
                try: page.screenshot(path=os.path.join(RESULTS_DIR, "birthday_debug.png"))
                except: pass
            
            page.wait(1)
            
            # Click Next/Submit
            print("[5b] Clicking next on details page...")
            click_primary_button(page)
            page.wait(5)
        else:
            # Old flow with separate birthday step
            print("[5] Entering birthday (separate step)...")
            birth_year = wait_for_any(page, [
                "css:input[name='BirthYear']",
                "css:input[id*='BirthYear']",
                "css:[aria-label='Birth year']",
            ], timeout=10)
            if birth_year:
                birth_year.input(year, clear=True)
                page.wait(0.3)

                birth_month = wait_for_any(page, [
                    "css:[name='BirthMonth']",
                    "css:select[name='BirthMonth']",
                ], timeout=5)
                birth_day_el = wait_for_any(page, [
                    "css:[name='BirthDay']",
                    "css:select[name='BirthDay']",
                ], timeout=5)
                if birth_month:
                    try: birth_month.select.by_value(month)
                    except: pass
                if birth_day_el:
                    try: birth_day_el.select.by_value(day)
                    except: pass

                page.wait(0.5)
                click_primary_button(page)
                page.wait(3)

        # Name
        print("[6] Entering name...")
        last_name_input = wait_for_any(page, [
            "css:#lastNameInput",
            "css:input[name='LastName']",
            "css:[aria-label='Last name']",
            "css:[aria-label='姓']",
        ], timeout=10)
        first_name_input = wait_for_any(page, [
            "css:#firstNameInput",
            "css:input[name='FirstName']",
            "css:[aria-label='First name']",
            "css:[aria-label='名']",
        ], timeout=10)
        if last_name_input:
            try: page.actions.move_to(last_name_input, duration=random.randint(80, 180)).click().perform()
            except: last_name_input.click()
            page.wait(0.2)
            last_name_input.input(lastname, clear=True)
        page.wait(0.3)
        if first_name_input:
            first_name_input.input(firstname, clear=True)
        page.wait(1)

        if not click_primary_button(page):
            print("  [!] Next button not found after name")
            return None, None
        page.wait(5)

        # CAPTCHA check
        captcha_texts = ["证明你不是机器人", "长按该按钮", "可访问性挑战", "验证你不是机器人"]
        has_captcha = any(text_exists(page, t) for t in captcha_texts)

        if has_captcha:
            print("  [!] CAPTCHA detected - attempting to solve...")
            from controllers.ruyipage_controller import RuyiPageController
            ctrl = RuyiPageController.__new__(RuyiPageController)
            ctrl.page = page
            result = ctrl.solve_captcha(max_attempts=5)
            if result:
                print("  [+] CAPTCHA solved!")
                page.wait(5)
            else:
                print("  [!] CAPTCHA failed")
                try: page.screenshot(path=os.path.join(RESULTS_DIR, "captcha_stuck.png"))
                except: pass
                # Still return credentials - can try OAuth2 later
                return full_email, password

        # Check mailbox
        for wait_round in range(3):
            current_url = page.url or ""
            if "outlook.live.com/mail" in current_url and "prompt=create_account" not in current_url:
                print(f"\n✅ Registration SUCCESS: {full_email}")
                with open(os.path.join(RESULTS_DIR, "outlook_accounts.txt"), "a", encoding="utf-8") as f:
                    f.write(f"{full_email}: {password}\n")
                return full_email, password
            page.wait(5)

        # Final check
        try:
            preview = page.run_js("return document.body ? document.body.innerText.substring(0, 300) : '';", as_expr=False)
        except:
            preview = ""
        print(f"  [?] Final state: {preview[:200]}")
        return full_email, password

    except Exception as e:
        print(f"[!] Registration error: {e}")
        import traceback
        traceback.print_exc()
        return None, None


def get_oauth2_token(page, email, password):
    """Acquire OAuth2 tokens using authorization code flow with PKCE via /consumers endpoint."""
    print(f"\n[*] Starting OAuth2 for {email}")

    # PKCE
    code_verifier = ''.join(secrets.choice('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~') for _ in range(128))
    code_challenge = base64.urlsafe_b64encode(hashlib.sha256(code_verifier.encode()).digest()).decode().rstrip('=')

    # Use prompt=none to leverage existing browser session (just registered & logged in)
    # If that fails, fall back to consent
    auth_url = (
        'https://login.microsoftonline.com/common/oauth2/v2.0/authorize?'
        f'client_id={CLIENT_ID}&response_type=code&redirect_uri={quote(REDIRECT)}'
        f'&scope={quote(SCOPES)}&response_mode=query'
        f'&code_challenge={code_challenge}&code_challenge_method=S256'
        f'&login_hint={quote(email)}'
    )

    page.listen.start(REDIRECT)
    captured = None

    try:
        page.get(auth_url, wait="complete", timeout=30)
        page.wait(5)

        # Check if we got redirected directly (already logged in)
        current_url = page.url or ''
        if 'code=' in current_url:
            captured = current_url
        else:
            # May need to handle sign-in or consent
            # Check for login form
            login_input = wait_for_any(page, ["css:[name='loginfmt']", "css:#i0116"], timeout=5)
            if login_input:
                print("[*] Need to re-login...")
                try:
                    page.actions.move_to(login_input, duration=100).click().perform()
                    login_input.input(email, clear=True)
                except:
                    page.run_js(f'document.getElementById("i0116").value = "{email}"; document.getElementById("i0116").dispatchEvent(new Event("input", {{bubbles:true}}));', as_expr=False)
                page.wait(0.5)
                nxt = wait_for_any(page, ["css:#idSIButton9"], timeout=5)
                if nxt:
                    try: nxt.click()
                    except: page.run_js('document.getElementById("idSIButton9").click();', as_expr=False)
                page.wait(4)

                pwd_input = wait_for_any(page, ["css:#i0118", "css:[name='passwd']", "css:input[type='password']"], timeout=10)
                if pwd_input:
                    print("[*] Entering password...")
                    try:
                        page.actions.move_to(pwd_input, duration=100).click().perform()
                        pwd_input.input(password, clear=True)
                    except:
                        page.run_js(f'''document.getElementById("i0118").value = "{password}"; document.getElementById("i0118").dispatchEvent(new Event("input", {{bubbles:true}}));''', as_expr=False)
                    page.wait(0.5)
                    sgn = wait_for_any(page, ["css:#idSIButton9"], timeout=5)
                    if sgn:
                        try: sgn.click()
                        except: page.run_js('document.getElementById("idSIButton9").click();', as_expr=False)
                    page.wait(5)

            # Consent / Stay signed in
            for _ in range(5):
                btn = wait_for_any(page, ["css:[data-testid='appConsentPrimaryButton']", "css:#idSIButton9"], timeout=5)
                if btn:
                    try: btn.click()
                    except: page.run_js('document.getElementById("idSIButton9").click();', as_expr=False)
                    page.wait(3)
                else:
                    break

        # Wait for redirect with auth code
        if 'code=' not in (captured or ''):
            captured = None
            for i in range(60):
                pkt = page.listen.wait(timeout=1)
                if pkt and 'code=' in (pkt.url or ''):
                    captured = pkt.url
                    break
                cu = page.url or ''
                if 'code=' in cu:
                    captured = cu
                    break
                page.wait(1)

        if not captured or 'code=' not in captured:
            try:
                preview = page.run_js("return document.body ? document.body.innerText.substring(0, 300) : '';", as_expr=False)
            except:
                preview = ''
            print(f"[!] No auth code. Page: {preview[:200]}")
            return None, None, None

        auth_code = parse_qs(captured.split('?')[1])['code'][0]
        print(f"[+] Auth code obtained!")

        # Exchange for tokens
        import requests
        r = requests.post(
            'https://login.microsoftonline.com/common/oauth2/v2.0/token',
            data={
                'client_id': CLIENT_ID,
                'client_secret': CLIENT_SECRET,
                'code': auth_code,
                'redirect_uri': REDIRECT,
                'grant_type': 'authorization_code',
                'code_verifier': code_verifier,
                'scope': SCOPES,
            },
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            timeout=15
        )
        tokens = r.json()

        if 'refresh_token' in tokens:
            rt = tokens['refresh_token']
            at = tokens['access_token']
            expires = tokens.get('expires_in', 0)
            print(f"\n✅ OAUTH2 SUCCESS!")
            print(f"  Refresh Token: {rt[:60]}...")
            print(f"  Access Token:  {at[:60]}...")
            print(f"  Expires:       {expires}s")
            return rt, at, expires
        else:
            print(f"[!] Token exchange failed: {json.dumps(tokens)[:300]}")
            return None, None, None

    except Exception as e:
        print(f"[!] OAuth2 error: {e}")
        import traceback
        traceback.print_exc()
        return None, None, None
    finally:
        page.listen.stop()


def test_imap(email, access_token):
    """Test IMAP access with XOAUTH2."""
    import imaplib
    print(f"\n[*] Testing IMAP XOAUTH2 for {email}...")
    try:
        mail = imaplib.IMAP4_SSL('outlook.office365.com', 993)
        auth_string = f'user={email}\x01auth=Bearer {access_token}\x01\x01'
        mail.authenticate('XOAUTH2', lambda x: auth_string.encode())
        mail.select('INBOX')
        typ, data = mail.search(None, 'ALL')
        count = len(data[0].split()) if data[0] else 0
        print(f"  ✅ IMAP works! Inbox has {count} messages.")
        mail.logout()
        return True
    except Exception as e:
        print(f"  ❌ IMAP failed: {e}")
        return False


def test_smtp(email, access_token):
    """Test SMTP access with XOAUTH2."""
    import smtplib
    print(f"[*] Testing SMTP XOAUTH2 for {email}...")
    try:
        server = smtplib.SMTP('smtp-mail.outlook.com', 587)
        server.ehlo()
        server.starttls()
        server.ehlo()
        auth_string = f'user={email}\x01auth=Bearer {access_token}\x01\x01'
        server.docmd('AUTH', 'XOAUTH2 ' + base64.b64encode(auth_string.encode()).decode())
        code, msg = server.docmd('QUIT')
        print(f"  ✅ SMTP works!")
        return True
    except Exception as e:
        print(f"  ❌ SMTP failed: {e}")
        return False


def main():
    num = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    
    print(f"\n{'='*60}")
    print(f"  Outlook Full Flow: Register + OAuth2 + IMAP/SMTP Test")
    print(f"  Client ID: {CLIENT_ID}")
    print(f"  Endpoint:  /consumers (personal accounts)")
    print(f"  Scopes:    IMAP.AccessAsUser.All + SMTP.Send")
    print(f"  Count:     {num}")
    print(f"{'='*60}")

    results = []
    
    for i in range(num):
        print(f"\n{'='*60}")
        print(f"  Account {i+1}/{num}")
        print(f"{'='*60}")
        
        page, profile = create_page()
        
        try:
            # Step 1: Register
            email, password = outlook_register(page)
            if not email:
                print("[!] Registration failed, skipping...")
                continue

            # Step 2: OAuth2 (use SAME browser session - already logged in)
            refresh_token, access_token, expires = get_oauth2_token(page, email, password)
            
            result = {
                'email': email,
                'password': password,
                'refresh_token': refresh_token,
                'access_token': access_token,
                'expires_in': expires,
                'imap_ok': False,
                'smtp_ok': False,
            }
            
            if access_token:
                # Step 3: Test IMAP/SMTP
                result['imap_ok'] = test_imap(email, access_token)
                result['smtp_ok'] = test_smtp(email, access_token)
            
            results.append(result)
            
            # Save incrementally
            with open(os.path.join(RESULTS_DIR, "full_flow_results.json"), "w") as f:
                json.dump(results, f, indent=2, ensure_ascii=False)
            
            # Also save tokens file
            if refresh_token:
                with open(os.path.join(RESULTS_DIR, "outlook_oauth_tokens.json"), "a") as f:
                    f.write(json.dumps(result, ensure_ascii=False) + '\n')
        
        except Exception as e:
            print(f"[!] Exception: {e}")
            import traceback
            traceback.print_exc()
        
        finally:
            try: page.quit(timeout=5, force=True)
            except: pass
            try:
                import shutil
                shutil.rmtree(profile, ignore_errors=True)
            except: pass
        
        if i < num - 1:
            delay = random.uniform(3, 8)
            print(f"\n[*] Waiting {delay:.1f}s...")
            time.sleep(delay)

    # Summary
    print(f"\n{'='*60}")
    print(f"  RESULTS SUMMARY")
    print(f"{'='*60}")
    for r in results:
        imap_s = "✅" if r['imap_ok'] else "❌"
        smtp_s = "✅" if r['smtp_ok'] else "❌"
        token_s = "✅" if r['refresh_token'] else "❌"
        print(f"  {r['email']}")
        print(f"    Password:      {r['password']}")
        print(f"    OAuth2 Token:  {token_s}")
        print(f"    IMAP:          {imap_s}")
        print(f"    SMTP:          {smtp_s}")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
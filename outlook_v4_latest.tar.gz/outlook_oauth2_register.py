#!/usr/bin/env python3
"""
Outlook Registration + OAuth2 Token (Thunderbird Client)
One-click: register account + get refresh_token for IMAP/SMTP
"""
import os, sys, time, json, random, requests, base64, hashlib, secrets, string, tempfile
from datetime import datetime
from urllib.parse import parse_qs, quote

os.environ['DISPLAY'] = ':99'

FIREFOX_PATH = '/home/node/.cache/ruyipage/browsers/firefox-151.0a1-151-ruyi-linux-x86_64/firefox/firefox'
RESULTS_DIR = '/tmp/outlook_register/Results'
os.makedirs(RESULTS_DIR, exist_ok=True)

# Thunderbird OAuth2 - works with /common endpoint for personal accounts
CLIENT_ID = '08162f7c-0fd2-4200-a84a-f25a4db0b584'
CLIENT_SECRET = 'TxRBilcHdC6WGBee]fs?QR:SJ8nI[g82'
REDIRECT_URL = 'https://login.microsoftonline.com/common/oauth2/nativeclient'
SCOPES = 'https://outlook.office.com/IMAP.AccessAsUser.All https://outlook.office.com/SMTP.Send offline_access'


def generate_code_verifier(length=128):
    alphabet = string.ascii_letters + string.digits + "-._~"
    return "".join(secrets.choice(alphabet) for _ in range(length))


def generate_code_challenge(code_verifier):
    sha256_hash = hashlib.sha256(code_verifier.encode()).digest()
    return base64.urlsafe_b64encode(sha256_hash).decode().rstrip("=")


def random_email_local():
    letter_count = random.randint(6, 8)
    digit_count = random.randint(5, 6)
    letters = "".join(random.choice(string.ascii_lowercase) for _ in range(letter_count))
    digits = "".join(random.choice(string.digits) for _ in range(digit_count))
    return letters + digits


def generate_strong_password():
    while True:
        password = "".join(secrets.choice(string.ascii_letters + string.digits + "!@#$%^&*") for _ in range(random.randint(11, 15)))
        if (any(c.islower() for c in password) and any(c.isupper() for c in password)
                and any(c.isdigit() for c in password) and any(c in "!@#$%^&*" for c in password)):
            return password


def wait_for_any(page, locators, timeout=5):
    end_time = time.time() + timeout
    while time.time() < end_time:
        for locator in locators:
            try:
                element = page.ele(locator, timeout=0.2)
                if element:
                    return element
            except:
                pass
        page.wait(0.2)
    return False


def click_btn(page):
    btn = wait_for_any(page, ["css:[data-testid='primaryButton']", "css:button[type='submit']"], timeout=5)
    if btn:
        btn.click()
    return btn


def register_account(page, email_local, password, email_suffix="@outlook.com"):
    """Register Outlook account, handle CAPTCHA. Returns True on success."""
    from faker import Faker
    fake = Faker()
    full_email = f"{email_local}{email_suffix}"
    lastname = fake.last_name()
    firstname = fake.first_name()
    year = str(random.randint(1960, 2005))
    month = str(random.randint(1, 12))
    day = str(random.randint(1, 28))

    # Navigate
    page.get("https://outlook.live.com/mail/0/?prompt=create_account", wait="interactive", timeout=20)
    page.wait(3)

    # Consent
    consent = wait_for_any(page, ["xpath://button[contains(normalize-space(.), '同意并继续')]", "css:#nextButton"], timeout=5)
    if consent:
        try:
            page.actions.move_to(consent, duration=100).click().perform()
        except:
            consent.click()
        page.wait(2)

    # Email
    email_input = wait_for_any(page, ["css:[aria-label='新建电子邮件']", "css:input[name='MemberName']"], timeout=10)
    if not email_input:
        return False
    try:
        page.actions.move_to(email_input, duration=100).click().perform()
    except:
        email_input.click()
    page.wait(0.3)
    email_input.input(email_local, clear=True)
    page.wait(0.5)
    click_btn(page)
    page.wait(2)

    # Password
    pwd_input = wait_for_any(page, ["css:input[type='password']"], timeout=10)
    if not pwd_input:
        return False
    try:
        page.actions.move_to(pwd_input, duration=100).click().perform()
    except:
        pwd_input.click()
    page.wait(0.3)
    pwd_input.input(password, clear=True)
    page.wait(0.5)
    click_btn(page)
    page.wait(2)

    # Birthday
    by = wait_for_any(page, ["css:[name='BirthYear']"], timeout=10)
    if by: by.input(year, clear=True)
    bm = wait_for_any(page, ["css:[name='BirthMonth']"], timeout=5)
    bd = wait_for_any(page, ["css:[name='BirthDay']"], timeout=5)
    if bm:
        try: bm.select.by_value(month)
        except: pass
    if bd:
        try: bd.select.by_value(day)
        except: pass
    page.wait(0.5)
    click_btn(page)
    page.wait(3)

    # Name
    ln = wait_for_any(page, ["css:#lastNameInput"], timeout=10)
    fn = wait_for_any(page, ["css:#firstNameInput"], timeout=10)
    if ln:
        try: page.actions.move_to(ln, duration=100).click().perform()
        except: ln.click()
        page.wait(0.2)
        ln.input(lastname, clear=True)
    if fn: fn.input(firstname, clear=True)
    page.wait(1)
    click_btn(page)
    page.wait(5)

    # CAPTCHA
    for attempt in range(8):
        challenge_btn = wait_for_any(page, [
            "css:[aria-label='可访问性挑战']",
            "css:[aria-label='再次按下']",
            "css:[aria-label='长按验证']",
        ], timeout=3)
        if challenge_btn:
            try:
                page.actions.move_to(challenge_btn, duration=random.randint(100, 200)).click().perform()
            except:
                challenge_btn.click()
            page.wait(3)
        else:
            break

    # Wait for mailbox
    for _ in range(15):
        url = page.url or ""
        if "outlook.live.com/mail" in url and "prompt=create_account" not in url:
            return True
        page.wait(2)

    return False


def get_oauth2_token(page, full_email, password):
    """Get OAuth2 refresh_token via authorization code flow."""
    code_verifier = generate_code_verifier()
    code_challenge = generate_code_challenge(code_verifier)

    params = {
        "client_id": CLIENT_ID,
        "response_type": "code",
        "redirect_uri": REDIRECT_URL,
        "scope": SCOPES,
        "response_mode": "query",
        "prompt": "login",
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
        "login_hint": full_email,
    }

    authorize_url = (
        "https://login.microsoftonline.com/common/oauth2/v2.0/authorize?"
        + "&".join(f"{k}={quote(str(v))}" for k, v in params.items())
    )

    captured_url = None
    page.listen.start(REDIRECT_URL)

    try:
        page.get(authorize_url, wait="interactive", timeout=30)
        page.wait(2)

        # Login form
        login_input = wait_for_any(page, ["css:[name='loginfmt']"], timeout=10)
        if login_input:
            login_input.input(full_email, clear=True)
            next_btn = wait_for_any(page, ["css:#idSIButton9"], timeout=5)
            if next_btn: next_btn.click()
            page.wait(3)

            pwd_input = wait_for_any(page, ["css:[name='passwd']", "css:input[type='password']"], timeout=10)
            if pwd_input:
                pwd_input.input(password, clear=True)
                signin_btn = wait_for_any(page, ["css:#idSIButton9"], timeout=5)
                if signin_btn: signin_btn.click()
                page.wait(5)

        # Consent
        consent_btn = wait_for_any(page, [
            "css:[data-testid='appConsentPrimaryButton']",
            "xpath://button[contains(normalize-space(.), 'Accept')]",
            "xpath://button[contains(normalize-space(.), '同意')]",
            "xpath://button[contains(normalize-space(.), '允许')]",
        ], timeout=15)
        if consent_btn:
            consent_btn.click()
            page.wait(3)

        # Stay signed in
        stay_btn = wait_for_any(page, [
            "xpath://button[contains(normalize-space(.), '是')]",
            "xpath://button[contains(normalize-space(.), 'Yes')]",
            "css:#idSIButton9",
        ], timeout=5)
        if stay_btn:
            stay_btn.click()
            page.wait(2)

        # Wait for redirect
        for i in range(60):
            packet = page.listen.wait(timeout=1)
            if packet and "code=" in (packet.url or ""):
                captured_url = packet.url
                break
            current_url = page.url or ""
            if "code=" in current_url:
                captured_url = current_url
                break
            page.wait(1)

    finally:
        page.listen.stop()

    if not captured_url or "code=" not in captured_url:
        return None

    auth_code = parse_qs(captured_url.split("?")[1])["code"][0]

    # Exchange code for tokens
    response = requests.post(
        "https://login.microsoftonline.com/common/oauth2/v2.0/token",
        data={
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "code": auth_code,
            "redirect_uri": REDIRECT_URL,
            "grant_type": "authorization_code",
            "code_verifier": code_verifier,
            "scope": SCOPES,
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        timeout=15,
    )

    tokens = response.json()
    if "refresh_token" in tokens:
        return tokens
    return None


def main():
    num = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    suffix = sys.argv[2] if len(sys.argv) > 2 else "@outlook.com"
    from ruyipage import FirefoxPage, FirefoxOptions

    print(f"""
╔══════════════════════════════════════════════════════╗
║  Outlook Registration + OAuth2 Token                  ║
║  Client: Thunderbird                                  ║
║  Scopes: IMAP.AccessAsUser.All + SMTP.Send            ║
╚══════════════════════════════════════════════════════╝
""")

    results = []
    for i in range(num):
        print(f"\n--- Account {i+1}/{num} ---")
        email_local = random_email_local()
        password = generate_strong_password()
        full_email = f"{email_local}{suffix}"

        print(f"  Email:    {full_email}")
        print(f"  Password: {password}")

        profile = tempfile.mkdtemp(prefix='ruyi-reg-')
        opts = FirefoxOptions()
        opts.set_user_dir(profile)
        opts.close_on_exit(True)
        opts.set_browser_path(FIREFOX_PATH)
        opts.set_pref('intl.accept_languages', 'zh-CN,zh,en-US,en')
        opts.set_human_algorithm("windmouse")

        page = FirefoxPage(opts)
        try:
            page.set_viewport(800, 600)
        except:
            pass

        try:
            # Step 1: Register
            print("[1/2] Registering...")
            ok = register_account(page, email_local, password, suffix)
            if not ok:
                print("  [!] Registration failed")
                page.quit()
                continue

            print("  ✅ Registered")

            # Step 2: OAuth2
            print("[2/2] Getting OAuth2 token...")
            tokens = get_oauth2_token(page, full_email, password)

            if tokens:
                result = {
                    "email": full_email,
                    "password": password,
                    "client_id": CLIENT_ID,
                    "client_secret": CLIENT_SECRET,
                    "refresh_token": tokens["refresh_token"],
                    "access_token": tokens.get("access_token", ""),
                    "expires_in": tokens.get("expires_in", 0),
                    "scope": tokens.get("scope", ""),
                    "registered_at": datetime.now().isoformat(),
                }
                results.append(result)
                print(f"  ✅ Token: {tokens['refresh_token'][:40]}...")

                with open(os.path.join(RESULTS_DIR, "outlook_oauth_tokens.json"), "a") as f:
                    f.write(json.dumps(result, ensure_ascii=False) + "\n")
                with open(os.path.join(RESULTS_DIR, "outlook_token.txt"), "a", encoding="utf-8") as f:
                    f.write(f"{full_email}----{password}----{CLIENT_ID}----{tokens['refresh_token']}\n")
            else:
                print("  [!] OAuth2 failed, account still registered")

        except Exception as e:
            print(f"  [!] Error: {e}")
        finally:
            try:
                page.quit()
            except:
                pass

        if i < num - 1:
            delay = random.uniform(5, 10)
            print(f"\n  Waiting {delay:.1f}s...")
            time.sleep(delay)

    print(f"\n{'='*55}")
    print(f"  Results: {len(results)} with OAuth2 tokens")
    for r in results:
        print(f"  ✅ {r['email']} | token: {r['refresh_token'][:30]}...")
    print(f"{'='*55}")


if __name__ == "__main__":
    main()
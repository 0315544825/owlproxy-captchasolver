#!/usr/bin/env python3
"""
Outlook v3: Register + OAuth2 (Thunderbird) + IMAP/SMTP test
Based on outlook_oauth2_register.py (the one that actually worked)
+ merged birthday/country page handling from outlook_full_flow.py
"""
import os, sys, time, json, random, string, secrets, tempfile, base64, hashlib, imaplib, smtplib
from datetime import datetime
from urllib.parse import parse_qs, quote

os.environ['DISPLAY'] = ':99'

FIREFOX_PATH = '/home/node/.cache/ruyipage/browsers/firefox-151.0a1-151-ruyi-linux-x86_64/firefox/firefox'
RESULTS_DIR = '/tmp/outlook_register/Results'
os.makedirs(RESULTS_DIR, exist_ok=True)

# Thunderbird OAuth2 (proven working)
CLIENT_ID = '08162f7c-0fd2-4200-a84a-f25a4db0b584'
CLIENT_SECRET = 'TxRBilcHdC6WGBee]fs?QR:SJ8nI[g82'
REDIRECT_URL = 'https://login.microsoftonline.com/common/oauth2/nativeclient'
SCOPES = 'https://outlook.office.com/IMAP.AccessAsUser.All https://outlook.office.com/SMTP.Send offline_access'


def generate_code_verifier(length=128):
    alphabet = string.ascii_letters + string.digits + "-._~"
    return "".join(secrets.choice(alphabet) for _ in range(length))


def generate_code_challenge(code_verifier):
    sha256_hash = hashlib.sha256(code_verifier.encode()).digest()
    return base64.urlsafe_b64encode(sha256_hash).decode().rstrip("=")


def random_email_local():
    letter_count = random.randint(6, 8)
    digit_count = random.randint(5, 6)
    letters = "".join(random.choice(string.ascii_lowercase) for _ in range(letter_count))
    digits = "".join(random.choice(string.digits) for _ in range(digit_count))
    return letters + digits


def generate_strong_password():
    while True:
        password = "".join(secrets.choice(string.ascii_letters + string.digits + "!@#$%^&*") for _ in range(random.randint(11, 15)))
        if (any(c.islower() for c in password) and any(c.isupper() for c in password)
                and any(c.isdigit() for c in password) and any(c in "!@#$%^&*" for c in password)):
            return password


def wait_for_any(page, locators, timeout=5):
    end_time = time.time() + timeout
    while time.time() < end_time:
        for locator in locators:
            try:
                element = page.ele(locator, timeout=0.2)
                if element:
                    return element
            except:
                pass
        page.wait(0.2)
    return False


def click_btn(page):
    btn = wait_for_any(page, [
        "css:[data-testid='primaryButton']",
        "css:button[type='submit']",
        "css:button.fui-Button",
    ], timeout=5)
    if btn:
        try:
            page.actions.move_to(btn, duration=random.randint(80, 180)).click().perform()
        except:
            btn.click()
    return bool(btn)


def text_exists(page, text):
    try:
        return bool(page.run_js(
            f"return !!document.body && document.body.innerText.includes('{text}');",
            as_expr=False,
        ))
    except:
        return False


def create_page():
    from ruyipage import FirefoxPage, FirefoxOptions
    profile = tempfile.mkdtemp(prefix='ruyi-v3-')
    opts = FirefoxOptions()
    opts.set_user_dir(profile)
    opts.close_on_exit(True)
    opts.set_browser_path(FIREFOX_PATH)
    opts.set_pref('intl.accept_languages', 'zh-CN,zh,en-US,en')
    opts.set_human_algorithm("windmouse")
    page = FirefoxPage(opts)
    try: page.set_viewport(1024, 768)
    except: pass
    try: page.window.set_window_size(1050, 800)
    except: pass
    return page, profile


def register_account(page, email_local, password, email_suffix="@outlook.com"):
    """Register Outlook account with merged country+birthday page handling."""
    from faker import Faker
    fake = Faker()
    full_email = f"{email_local}{email_suffix}"
    lastname = fake.last_name()
    firstname = fake.first_name()
    year = str(random.randint(1960, 2005))
    month = str(random.randint(1, 12))
    day = str(random.randint(1, 28))

    print(f"\n╔══════════════════════════════════════╗")
    print(f"║  Registering: {full_email}")
    print(f"║  Password:    {password}")
    print(f"║  Name:        {firstname} {lastname}")
    print(f"║  Birthday:    {year}-{month}-{day}")
    print(f"╚══════════════════════════════════════╝")

    try:
        # Navigate to signup
        print("[1] Navigating to signup page...")
        page.get("https://outlook.live.com/mail/0/?prompt=create_account", wait="interactive", timeout=30)
        page.wait(8)

        # Consent button (Chinese locale)
        consent = wait_for_any(page, [
            "xpath://button[contains(normalize-space(.), '同意并继续')]",
            "xpath://*[@role='button'][contains(normalize-space(.), '同意并继续')]",
        ], timeout=5)
        if consent:
            print("[2] Clicking consent...")
            try: page.actions.move_to(consent, duration=random.randint(80, 180)).click().perform()
            except: consent.click()
            page.wait(2)

        # Email input
        print("[3] Entering email...")
        email_input = wait_for_any(page, [
            "css:input[name='email']",
            "css:[aria-label='New email']",
            "css:input[name='MemberName']",
            "css:[aria-label='新建电子邮件']",
        ], timeout=10)
        if not email_input:
            print("  [!] Email input not found")
            return False
        try: page.actions.move_to(email_input, duration=random.randint(80, 180)).click().perform()
        except: email_input.click()
        page.wait(0.3)
        email_input.input(email_local, clear=True)
        page.wait(0.5)
        click_btn(page)
        page.wait(2)

        # Password
        print("[4] Entering password...")
        pwd_input = wait_for_any(page, ["css:input[type='password']", "css:input[name='passwd']"], timeout=10)
        if not pwd_input:
            print("  [!] Password input not found")
            return False
        try: page.actions.move_to(pwd_input, duration=random.randint(80, 180)).click().perform()
        except: pwd_input.click()
        page.wait(0.3)
        pwd_input.input(password, clear=True)
        page.wait(0.5)
        click_btn(page)
        page.wait(3)

        # After email+password: check if it's merged "Add some details" or separate birthday
        time.sleep(2)
        page_text = ''
        try:
            page_text = page.run_js("return document.body ? document.body.innerText.substring(0, 500) : '';", as_expr=False)
        except: pass

        if 'Add some details' in page_text or 'Country/Region' in page_text or 'Birth year' in page_text.lower() or '出生' in page_text:
            print("[5] Processing merged details page (Country + Birthday)...")

            # Country dropdown
            country_btn = wait_for_any(page, [
                "css:button[name='countryDropdownName']",
                "css:#countryDropdownId",
            ], timeout=10)
            if country_btn:
                try: page.actions.move_to(country_btn, duration=random.randint(80, 180)).click().perform()
                except: country_btn.click()
                page.wait(1)
                us_opt = wait_for_any(page, [
                    "xpath://*[@role='option'][contains(.,'United States')]",
                    "xpath://li[contains(.,'United States')]",
                ], timeout=5)
                if us_opt:
                    try: us_opt.click()
                    except: page.run_js("var opts = document.querySelectorAll('[role=option]'); for(var o of opts) { if(o.textContent.includes('United States')) { o.click(); break; } }", as_expr=False)
                page.wait(1)

            # Birth month dropdown - Chinese: "6月", English: "June"
            month_names = ['', 'January', 'February', 'March', 'April', 'May', 'June',
                           'July', 'August', 'September', 'October', 'November', 'December']
            month_text = month_names[int(month)]
            try:
                month_btn = page.ele('css:#BirthMonthDropdown', timeout=5)
            except:
                month_btn = None
            if month_btn:
                try: month_btn.click()
                except: pass
                page.wait(0.8)
                month_sel = wait_for_any(page, [
                    f"xpath://*[@role='option'][normalize-space(.)='{month}月']",
                    f"xpath://*[@role='option'][contains(.,'{month_text}')]",
                ], timeout=5)
                if month_sel:
                    try: month_sel.click()
                    except: pass
                else:
                    page.run_js(f"var opts=document.querySelectorAll('[role=option]');for(var o of opts){{var t=o.textContent.trim();if(t==='{month}月'||t==='{month_text}'){{o.click();break;}}}}", as_expr=False)
                page.wait(0.5)

            # Birth day dropdown - Chinese: "15日", English: "15"
            print(f"[5a] Selecting birth day: {day}...")
            try:
                day_btn = page.ele('css:#BirthDayDropdown', timeout=5)
            except:
                day_btn = None
            if day_btn:
                try: day_btn.click()
                except: pass
                page.wait(0.8)
                day_sel = wait_for_any(page, [
                    f"xpath://*[@role='option'][normalize-space(.)='{day}日']",
                    f"xpath://*[@role='option'][normalize-space(.)='{int(day)}日']",
                    f"xpath://*[@role='option'][normalize-space(.)='{day}']",
                ], timeout=5)
                if day_sel:
                    try: day_sel.click()
                    except: pass
                else:
                    page.run_js(f"var opts=document.querySelectorAll('[role=option]');for(var o of opts){{var t=o.textContent.trim();if(t==='{day}日'||t==='{int(day)}日'||t==='{day}'){{o.click();break;}}}}", as_expr=False)
                page.wait(0.5)

            # Birth year input (type=number, name=BirthYear)
            print(f"[5a] Entering birth year: {year}...")
            try:
                year_input = page.ele('css:input[name=BirthYear]', timeout=5)
            except:
                year_input = None
            if year_input:
                try:
                    year_input.click()
                    page.wait(0.2)
                    year_input.input(year, clear=True)
                    page.wait(0.3)
                except:
                    pass
            # Always JS fallback to make sure year is set
            page.run_js(f"var y=document.querySelector('input[name=BirthYear]');if(y){{y.value='{year}';y.dispatchEvent(new Event('input',{{bubbles:true}}));y.dispatchEvent(new Event('change',{{bubbles:true}}));}}", as_expr=False)

            # Debug: screenshot + dump
            try: page.screenshot(path=os.path.join(RESULTS_DIR, "birthday_debug.png"))
            except: pass

            page.wait(1)
            print("[5b] Clicking next on details page...")
            click_btn(page)
            page.wait(5)
        else:
            # Old separate birthday step
            print("[5] Entering birthday (separate step)...")
            birth_year = wait_for_any(page, ["css:input[name='BirthYear']", "css:input[id*='BirthYear']"], timeout=10)
            if birth_year:
                birth_year.input(year, clear=True)
                page.wait(0.3)
                birth_month = wait_for_any(page, ["css:[name='BirthMonth']"], timeout=5)
                if birth_month:
                    try: birth_month.select.by_value(month)
                    except: pass
                birth_day_el = wait_for_any(page, ["css:[name='BirthDay']"], timeout=5)
                if birth_day_el:
                    try: birth_day_el.select.by_value(day)
                    except: pass
                page.wait(0.5)
                click_btn(page)
                page.wait(3)

        # Name
        print("[6] Entering name...")
        ln = wait_for_any(page, ["css:#lastNameInput", "css:input[name='LastName']", "css:[aria-label='Last name']", "css:[aria-label='姓']"], timeout=10)
        fn = wait_for_any(page, ["css:#firstNameInput", "css:input[name='FirstName']", "css:[aria-label='First name']", "css:[aria-label='名']"], timeout=10)
        if ln:
            try: page.actions.move_to(ln, duration=random.randint(80, 180)).click().perform()
            except: ln.click()
            page.wait(0.2)
            ln.input(lastname, clear=True)
        page.wait(0.3)
        if fn: fn.input(firstname, clear=True)
        page.wait(1)

        if not click_btn(page):
            print("  [!] Next button not found after name")
            return False
        page.wait(5)

        # CAPTCHA handling - "长按该按钮" = press and hold
        print("[7] Checking for CAPTCHA...")
        for attempt in range(15):
            # Check if we're past CAPTCHA already
            url = page.url or ""
            if "outlook.live.com/mail" in url and "prompt=create_account" not in url:
                break
            if "signup.live.com" not in url:
                break

            # Look for the press-and-hold button
            challenge_btn = wait_for_any(page, [
                "css:[aria-label='可访问性挑战']",
                "css:[aria-label='再次按下']",
                "css:[aria-label='长按验证']",
                "css:div[aria-label='长按该按钮']",
                "css:[aria-label*='长按']",
                "css:[aria-label*='press']",
                "css:[aria-label*='hold']",
                # Fuzzy match for the press-and-hold CAPTCHA widget
                "xpath://div[contains(@class,'fui-Flex')]//button[contains(@class,'fui-Button')]",
            ], timeout=5)

            if challenge_btn:
                print(f"  [CAPTCHA] Attempt {attempt+1}: Found challenge button, long-pressing...")
                try:
                    # Long press: mousedown -> wait -> mouseup
                    page.actions.move_to(challenge_btn, duration=random.randint(100, 200))
                    page.actions.click_and_hold().perform()
                    page.wait(random.uniform(3.0, 5.0))
                    page.actions.release().perform()
                    page.wait(3)
                except:
                    try:
                        # Alternative: use JS to simulate hold
                        challenge_btn.click()
                        page.wait(4)
                    except:
                        pass

                # Screenshot for debugging
                try: page.screenshot(path=os.path.join(RESULTS_DIR, f"captcha_attempt_{attempt}.png"))
                except: pass
            else:
                # Check current page state
                page_text = ''
                try:
                    page_text = page.run_js("return document.body ? document.body.innerText.substring(0, 500) : '';", as_expr=False)
                except: pass
                if '机器人' not in page_text and '长按' not in page_text and 'CAPTCHA' not in page_text.upper():
                    print(f"  [CAPTCHA] No CAPTCHA found, moving on...")
                    break
                print(f"  [CAPTCHA] Still on CAPTCHA page but no button found, waiting...")
                page.wait(5)

        # Check for mailbox
        for _ in range(20):
            url = page.url or ""
            if "outlook.live.com/mail" in url and "prompt=create_account" not in url:
                print(f"\n✅ Registration SUCCESS: {full_email}")
                return True
            page.wait(3)

        # Final check - maybe stuck on CAPTCHA or another page
        print(f"  [?] Final URL: {page.url}")
        try:
            preview = page.run_js("return document.body ? document.body.innerText.substring(0, 300) : '';", as_expr=False)
            print(f"  [?] Page: {preview[:200]}")
        except: pass
        try: page.screenshot(path=os.path.join(RESULTS_DIR, "reg_stuck.png"))
        except: pass
        return False

    except Exception as e:
        print(f"[!] Registration error: {e}")
        import traceback
        traceback.print_exc()
        return False


def get_oauth2_token(page, full_email, password):
    """Get OAuth2 refresh_token via authorization code flow (Thunderbird client)."""
    import requests

    code_verifier = generate_code_verifier()
    code_challenge = generate_code_challenge(code_verifier)

    params = {
        "client_id": CLIENT_ID,
        "response_type": "code",
        "redirect_uri": REDIRECT_URL,
        "scope": SCOPES,
        "response_mode": "query",
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
        "login_hint": full_email,
    }

    authorize_url = (
        "https://login.microsoftonline.com/common/oauth2/v2.0/authorize?"
        + "&".join(f"{k}={quote(str(v))}" for k, v in params.items())
    )

    print(f"\n[*] Starting OAuth2 for {full_email}")

    captured_url = None
    page.listen.start(REDIRECT_URL)

    try:
        page.get(authorize_url, wait="interactive", timeout=30)
        page.wait(5)

        # Check if already logged in (same browser session after registration)
        current_url = page.url or ''
        if 'code=' in current_url:
            captured_url = current_url
            print("[*] Already logged in - got redirect directly!")
        else:
            # May need to sign in again
            login_input = wait_for_any(page, ["css:[name='loginfmt']", "css:#i0116"], timeout=8)
            if login_input:
                print("[*] Need to re-login...")
                try: login_input.input(full_email, clear=True)
                except: page.run_js(f'document.getElementById("i0116").value = "{full_email}"; document.getElementById("i0116").dispatchEvent(new Event("input", {{bubbles:true}}));', as_expr=False)
                page.wait(0.5)
                next_btn = wait_for_any(page, ["css:#idSIButton9"], timeout=5)
                if next_btn:
                    try: next_btn.click()
                    except: page.run_js('document.getElementById("idSIButton9").click();', as_expr=False)
                page.wait(4)

                pwd_input = wait_for_any(page, ["css:[name='passwd']", "css:#i0118", "css:input[type='password']"], timeout=10)
                if pwd_input:
                    print("[*] Entering password...")
                    try: pwd_input.input(password, clear=True)
                    except: page.run_js(f'document.getElementById("i0118").value = "{password}"; document.getElementById("i0118").dispatchEvent(new Event("input", {{bubbles:true}}));', as_expr=False)
                    page.wait(0.5)
                    signin_btn = wait_for_any(page, ["css:#idSIButton9"], timeout=5)
                    if signin_btn:
                        try: signin_btn.click()
                        except: page.run_js('document.getElementById("idSIButton9").click();', as_expr=False)
                    page.wait(5)

            # Consent / Stay signed in
            for _ in range(5):
                consent_btn = wait_for_any(page, [
                    "css:[data-testid='appConsentPrimaryButton']",
                    "css:#idSIButton9",
                    "xpath://button[contains(normalize-space(.), '是')]",
                    "xpath://button[contains(normalize-space(.), 'Yes')]",
                    "xpath://button[contains(normalize-space(.), 'Accept')]",
                    "xpath://button[contains(normalize-space(.), '允许')]",
                ], timeout=5)
                if consent_btn:
                    try: consent_btn.click()
                    except: page.run_js('document.getElementById("idSIButton9").click();', as_expr=False)
                    page.wait(3)
                else:
                    break

        # Wait for redirect with auth code
        if not captured_url or 'code=' not in captured_url:
            for i in range(60):
                pkt = page.listen.wait(timeout=1)
                if pkt and 'code=' in (pkt.url or ''):
                    captured_url = pkt.url
                    break
                current_url = page.url or ''
                if 'code=' in current_url:
                    captured_url = current_url
                    break
                page.wait(1)

    finally:
        page.listen.stop()

    if not captured_url or 'code=' not in captured_url:
        try:
            preview = page.run_js("return document.body ? document.body.innerText.substring(0, 300) : '';", as_expr=False)
            print(f"[!] No auth code. Page: {preview[:200]}")
        except: pass
        return None

    auth_code = parse_qs(captured_url.split("?")[1])["code"][0]
    print(f"[+] Auth code obtained!")

    # Exchange code for tokens
    response = requests.post(
        "https://login.microsoftonline.com/common/oauth2/v2.0/token",
        data={
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "code": auth_code,
            "redirect_uri": REDIRECT_URL,
            "grant_type": "authorization_code",
            "code_verifier": code_verifier,
            "scope": SCOPES,
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        timeout=15,
    )

    tokens = response.json()
    if "refresh_token" in tokens:
        print(f"\n✅ OAUTH2 SUCCESS!")
        print(f"  Refresh Token: {tokens['refresh_token'][:60]}...")
        print(f"  Access Token:  {tokens['access_token'][:60]}...")
        return tokens
    else:
        print(f"[!] Token exchange failed: {json.dumps(tokens)[:300]}")
        return None


def test_imap(email, access_token):
    print(f"\n[*] Testing IMAP XOAUTH2 for {email}...")
    try:
        mail = imaplib.IMAP4_SSL('outlook.office365.com', 993)
        auth_string = f'user={email}\x01auth=Bearer {access_token}\x01\x01'
        mail.authenticate('XOAUTH2', lambda x: auth_string.encode())
        mail.select('INBOX')
        typ, data = mail.search(None, 'ALL')
        count = len(data[0].split()) if data[0] else 0
        print(f"  ✅ IMAP works! Inbox has {count} messages.")
        mail.logout()
        return True
    except Exception as e:
        print(f"  ❌ IMAP failed: {e}")
        return False


def test_smtp(email, access_token):
    print(f"[*] Testing SMTP XOAUTH2 for {email}...")
    try:
        server = smtplib.SMTP('smtp-mail.outlook.com', 587)
        server.ehlo()
        server.starttls()
        server.ehlo()
        auth_string = f'user={email}\x01auth=Bearer {access_token}\x01\x01'
        server.docmd('AUTH', 'XOAUTH2 ' + base64.b64encode(auth_string.encode()).decode())
        code, msg = server.docmd('QUIT')
        print(f"  ✅ SMTP works!")
        return True
    except Exception as e:
        print(f"  ❌ SMTP failed: {e}")
        return False


def main():
    import requests
    num = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    suffix = sys.argv[2] if len(sys.argv) > 2 else "@outlook.com"

    print(f"""
╔══════════════════════════════════════════════════════╗
║  Outlook v3: Register + OAuth2 + IMAP/SMTP           ║
║  Client: Thunderbird ({CLIENT_ID[:8]}...)                ║
║  Endpoint: /common                                    ║
║  Scopes: IMAP.AccessAsUser.All + SMTP.Send            ║
║  Count: {num}                                             ║
╚══════════════════════════════════════════════════════╝
""")

    results = []

    for i in range(num):
        print(f"\n{'='*60}")
        print(f"  Account {i+1}/{num}")
        print(f"{'='*60}")

        email_local = random_email_local()
        password = generate_strong_password()
        full_email = f"{email_local}{suffix}"

        page, profile = create_page()

        try:
            # Step 1: Register
            print("[1/3] Registering...")
            ok = register_account(page, email_local, password, suffix)
            if not ok:
                print("[!] Registration failed or incomplete")
                # Save attempt anyway
                with open(os.path.join(RESULTS_DIR, "v3_failed.txt"), "a") as f:
                    f.write(f"{full_email}:{password}\n")
                continue

            print("  ✅ Registered")

            # Step 2: OAuth2 (same browser session - already logged in)
            print("[2/3] Getting OAuth2 token...")
            tokens = get_oauth2_token(page, full_email, password)

            result = {
                "email": full_email,
                "password": password,
                "client_id": CLIENT_ID,
                "refresh_token": None,
                "access_token": None,
                "expires_in": 0,
                "imap_ok": False,
                "smtp_ok": False,
                "registered_at": datetime.now().isoformat(),
            }

            if tokens:
                result["refresh_token"] = tokens["refresh_token"]
                result["access_token"] = tokens.get("access_token", "")
                result["expires_in"] = tokens.get("expires_in", 0)

                # Step 3: Test IMAP/SMTP
                print("[3/3] Testing IMAP/SMTP...")
                result["imap_ok"] = test_imap(full_email, tokens.get("access_token", ""))
                result["smtp_ok"] = test_smtp(full_email, tokens.get("access_token", ""))

                # Save token
                with open(os.path.join(RESULTS_DIR, "v3_oauth_tokens.json"), "a") as f:
                    f.write(json.dumps(result, ensure_ascii=False) + "\n")
                with open(os.path.join(RESULTS_DIR, "v3_token.txt"), "a", encoding="utf-8") as f:
                    f.write(f"{full_email}----{password}----{CLIENT_ID}----{tokens['refresh_token']}\n")
            else:
                # Save account without token
                with open(os.path.join(RESULTS_DIR, "v3_unlogged.txt"), "a") as f:
                    f.write(f"{full_email}:{password}\n")

            results.append(result)

        except Exception as e:
            print(f"[!] Exception: {e}")
            import traceback
            traceback.print_exc()
        finally:
            try: page.quit(timeout=5, force=True)
            except: pass
            try:
                import shutil
                shutil.rmtree(profile, ignore_errors=True)
            except: pass

        if i < num - 1:
            delay = random.uniform(5, 10)
            print(f"\n[*] Waiting {delay:.1f}s...")
            time.sleep(delay)

    # Summary
    print(f"\n{'='*60}")
    print(f"  RESULTS SUMMARY")
    print(f"{'='*60}")
    for r in results:
        token_s = "✅" if r["refresh_token"] else "❌"
        imap_s = "✅" if r["imap_ok"] else "❌"
        smtp_s = "✅" if r["smtp_ok"] else "❌"
        print(f"  {r['email']}")
        print(f"    Password:      {r['password']}")
        print(f"    OAuth2 Token:  {token_s}")
        print(f"    IMAP:          {imap_s}")
        print(f"    SMTP:          {smtp_s}")
    print(f"{'='*60}")

    # Save summary
    with open(os.path.join(RESULTS_DIR, "v3_results.json"), "w") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    main()
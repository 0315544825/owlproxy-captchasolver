#!/usr/bin/env python3
"""
Outlook v4: Full register + OAuth2 using ruyipage_controller CAPTCHA solver
"""
import os, sys, time, json, random, string, secrets, tempfile, base64, hashlib, imaplib, smtplib
from datetime import datetime
from urllib.parse import parse_qs, quote

os.environ['DISPLAY'] = ':99'

FIREFOX_PATH = '/home/node/.cache/ruyipage/browsers/firefox-151.0a1-151-ruyi-linux-x86_64/firefox/firefox'
RESULTS_DIR = '/tmp/outlook_register/Results'
os.makedirs(RESULTS_DIR, exist_ok=True)
PROFILE_ROOT = '/tmp/outlook_register/Profiles'
os.makedirs(PROFILE_ROOT, exist_ok=True)

# Try config.json's client_id + /consumers endpoint (original config)
CLIENT_ID = '9e5f94bc-e8a4-4e73-b8be-63364c29d753'
CLIENT_SECRET = ''  # No client secret for this public client
REDIRECT_URL = 'https://login.microsoftonline.com/common/oauth2/nativeclient'
TENANT = 'consumers'  # use_consumers=true from config
SCOPES = 'offline_access https://outlook.office.com/IMAP.AccessAsUser.All https://outlook.office.com/SMTP.Send'

# Import the controller's captcha handler
sys.path.insert(0, '/tmp/outlook_register')
from controllers.ruyipage_controller import RuyiPageController


def generate_code_verifier(length=128):
    alphabet = string.ascii_letters + string.digits + "-._~"
    return "".join(secrets.choice(alphabet) for _ in range(length))


def generate_code_challenge(code_verifier):
    sha256_hash = hashlib.sha256(code_verifier.encode()).digest()
    return base64.urlsafe_b64encode(sha256_hash).decode().rstrip("=")


def random_email_local():
    letter_count = random.randint(6, 8)
    digit_count = random.randint(5, 6)
    letters = "".join(random.choice(string.ascii_lowercase) for _ in range(letter_count))
    digits = "".join(random.choice(string.digits) for _ in range(digit_count))
    return letters + digits


def generate_strong_password():
    while True:
        password = "".join(secrets.choice(string.ascii_letters + string.digits + "!@#$%^&*") for _ in range(random.randint(11, 15)))
        if (any(c.islower() for c in password) and any(c.isupper() for c in password)
                and any(c.isdigit() for c in password) and any(c in "!@#$%^&*" for c in password)):
            return password


def create_page(controller):
    """Launch browser via controller (handles profile, prefs, proxy)"""
    result = controller.launch_browser(proxy_config=None)
    if not result or result is False:
        return None, None
    page, resource = result
    return page, resource


def register_account(page, controller, email_local, password, email_suffix="@outlook.com"):
    """Register using controller's outlook_register (handles birthday + CAPTCHA)"""
    return controller.outlook_register(page, email_local, password)


def get_oauth2_token(page, full_email, password):
    """Get OAuth2 refresh_token via authorization code flow (Thunderbird client)."""
    import requests

    code_verifier = generate_code_verifier()
    code_challenge = generate_code_challenge(code_verifier)

    params = {
        "client_id": CLIENT_ID,
        "response_type": "code",
        "redirect_uri": REDIRECT_URL,
        "scope": SCOPES,
        "response_mode": "query",
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
        "login_hint": full_email,
    }

    authorize_url = (
        f"https://login.microsoftonline.com/{TENANT}/oauth2/v2.0/authorize?"
        + "&".join(f"{k}={quote(str(v))}" for k, v in params.items())
    )

    print(f"\n[*] Starting OAuth2 for {full_email}", flush=True)

    captured_url = None
    page.listen.start(REDIRECT_URL)

    try:
        page.get(authorize_url, wait="interactive", timeout=30)
        page.wait(5)

        current_url = page.url or ''
        if 'code=' in current_url:
            captured_url = current_url
            print("[*] Already logged in - got redirect directly!", flush=True)
        else:
            # May need to sign in again
            from controllers.ruyipage_controller import RuyiPageController
            ctrl = RuyiPageController()
            login_input = ctrl.wait_for_any(page, ["css:[name='loginfmt']", "css:#i0116"], timeout=8)
            if login_input:
                print("[*] Need to re-login...", flush=True)
                try: login_input.input(full_email, clear=True)
                except: page.run_js(f'document.getElementById("i0116").value = "{full_email}"; document.getElementById("i0116").dispatchEvent(new Event("input", {{bubbles:true}}));', as_expr=False)
                page.wait(0.5)
                next_btn = ctrl.wait_for_any(page, ["css:#idSIButton9"], timeout=5)
                if next_btn:
                    try: next_btn.click()
                    except: page.run_js('document.getElementById("idSIButton9").click();', as_expr=False)
                page.wait(4)

                pwd_input = ctrl.wait_for_any(page, ["css:[name='passwd']", "css:#i0118", "css:input[type='password']"], timeout=10)
                if pwd_input:
                    print("[*] Entering password...", flush=True)
                    try: pwd_input.input(password, clear=True)
                    except: page.run_js(f'document.getElementById("i0118").value = "{password}"; document.getElementById("i0118").dispatchEvent(new Event("input", {{bubbles:true}}));', as_expr=False)
                    page.wait(0.5)
                    signin_btn = ctrl.wait_for_any(page, ["css:#idSIButton9"], timeout=5)
                    if signin_btn:
                        try: signin_btn.click()
                        except: page.run_js('document.getElementById("idSIButton9").click();', as_expr=False)
                    page.wait(5)

            # Consent / Stay signed in
            for _ in range(5):
                consent_btn = ctrl.wait_for_any(page, [
                    "css:[data-testid='appConsentPrimaryButton']",
                    "css:#idSIButton9",
                    "xpath://button[contains(normalize-space(.), '是')]",
                    "xpath://button[contains(normalize-space(.), 'Yes')]",
                    "xpath://button[contains(normalize-space(.), 'Accept')]",
                    "xpath://button[contains(normalize-space(.), '允许')]",
                ], timeout=5)
                if consent_btn:
                    try: consent_btn.click()
                    except: page.run_js('document.getElementById("idSIButton9").click();', as_expr=False)
                    page.wait(3)
                else:
                    break

        # Wait for redirect with auth code
        if not captured_url or 'code=' not in captured_url:
            for i in range(60):
                pkt = page.listen.wait(timeout=1)
                if pkt and 'code=' in (pkt.url or ''):
                    captured_url = pkt.url
                    break
                current_url = page.url or ''
                if 'code=' in current_url:
                    captured_url = current_url
                    break
                page.wait(1)

    finally:
        page.listen.stop()

    if not captured_url or 'code=' not in captured_url:
        try:
            preview = page.run_js("return document.body ? document.body.innerText.substring(0, 300) : '';", as_expr=False)
            print(f"[!] No auth code. Page: {preview[:200]}", flush=True)
        except: pass
        return None

    auth_code = parse_qs(captured_url.split("?")[1])["code"][0]
    print(f"[+] Auth code obtained!", flush=True)

    response = requests.post(
        f"https://login.microsoftonline.com/{TENANT}/oauth2/v2.0/token",
        data={
            "client_id": CLIENT_ID,
            "code": auth_code,
            "redirect_uri": REDIRECT_URL,
            "grant_type": "authorization_code",
            "code_verifier": code_verifier,
            "scope": SCOPES,
        },
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        timeout=15,
    )

    tokens = response.json()
    if "refresh_token" in tokens:
        print(f"\n✅ OAUTH2 SUCCESS!", flush=True)
        print(f"  Refresh Token: {tokens['refresh_token'][:60]}...", flush=True)
        return tokens
    else:
        print(f"[!] Token exchange failed: {json.dumps(tokens)[:300]}", flush=True)
        return None


def test_imap(email, access_token):
    print(f"\n[*] Testing IMAP XOAUTH2 for {email}...", flush=True)
    try:
        mail = imaplib.IMAP4_SSL('outlook.office365.com', 993)
        auth_string = f'user={email}\x01auth=Bearer {access_token}\x01\x01'
        mail.authenticate('XOAUTH2', lambda x: auth_string.encode())
        mail.select('INBOX')
        typ, data = mail.search(None, 'ALL')
        count = len(data[0].split()) if data[0] else 0
        print(f"  ✅ IMAP works! Inbox has {count} messages.", flush=True)
        mail.logout()
        return True
    except Exception as e:
        print(f"  ❌ IMAP failed: {e}", flush=True)
        return False


def test_smtp(email, access_token):
    print(f"[*] Testing SMTP XOAUTH2 for {email}...", flush=True)
    try:
        server = smtplib.SMTP('smtp-mail.outlook.com', 587)
        server.ehlo()
        server.starttls()
        server.ehlo()
        auth_string = f'user={email}\x01auth=Bearer {access_token}\x01\x01'
        server.docmd('AUTH', 'XOAUTH2 ' + base64.b64encode(auth_string.encode()).decode())
        code, msg = server.docmd('QUIT')
        print(f"  ✅ SMTP works!", flush=True)
        return True
    except Exception as e:
        print(f"  ❌ SMTP failed: {e}", flush=True)
        return False


def main():
    num = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    suffix = sys.argv[2] if len(sys.argv) > 2 else "@outlook.com"

    print(f"""
╔══════════════════════════════════════════════════════╗
║  Outlook v4: Register + OAuth2 (Controller CAPTCHA) ║
║  Client: MS public ({CLIENT_ID[:8]}...)                   ║
║  Endpoint: /consumers                                 ║
║  CAPTCHA: ruyipage_controller                          ║
║  Count: {num}                                             ║
╚══════════════════════════════════════════════════════╝
""", flush=True)

    controller = RuyiPageController()
    results = []

    for i in range(num):
        print(f"\n{'='*60}", flush=True)
        print(f"  Account {i+1}/{num}", flush=True)
        print(f"{'='*60}", flush=True)

        email_local = random_email_local()
        password = generate_strong_password()
        full_email = f"{email_local}{suffix}"

        page, resource = create_page(controller)
        if not page:
            print("[!] Failed to launch browser", flush=True)
            continue

        try:
            # Step 1: Register (controller handles birthday + CAPTCHA)
            print("[1/3] Registering...", flush=True)
            ok = register_account(page, controller, email_local, password, suffix)
            if not ok:
                print("[!] Registration failed", flush=True)
                with open(os.path.join(RESULTS_DIR, "v4_failed.txt"), "a") as f:
                    f.write(f"{full_email}:{password}\n")
                continue

            print("  ✅ Registered", flush=True)

            # Step 2: OAuth2
            print("[2/3] Getting OAuth2 token...", flush=True)
            tokens = get_oauth2_token(page, full_email, password)

            result = {
                "email": full_email,
                "password": password,
                "client_id": CLIENT_ID,
                "refresh_token": None,
                "access_token": None,
                "expires_in": 0,
                "imap_ok": False,
                "smtp_ok": False,
                "registered_at": datetime.now().isoformat(),
            }

            if tokens:
                result["refresh_token"] = tokens["refresh_token"]
                result["access_token"] = tokens.get("access_token", "")
                result["expires_in"] = tokens.get("expires_in", 0)

                # Save token immediately BEFORE network tests, so SMTP/IMAP hangs don't lose it
                with open(os.path.join(RESULTS_DIR, "v4_oauth_tokens.json"), "a") as f:
                    f.write(json.dumps(result, ensure_ascii=False) + "\n")
                with open(os.path.join(RESULTS_DIR, "v4_token.txt"), "a", encoding="utf-8") as f:
                    f.write(f"{full_email}----{password}----{CLIENT_ID}----{tokens['refresh_token']}\n")

                # Optional tests can hang on fresh Microsoft accounts; skip by default unless --test is provided
                if "--test" in sys.argv:
                    print("[3/3] Testing IMAP/SMTP...", flush=True)
                    result["imap_ok"] = test_imap(full_email, tokens.get("access_token", ""))
                    result["smtp_ok"] = test_smtp(full_email, tokens.get("access_token", ""))
            else:
                with open(os.path.join(RESULTS_DIR, "v4_unlogged.txt"), "a") as f:
                    f.write(f"{full_email}:{password}\n")

            results.append(result)

        except Exception as e:
            print(f"[!] Exception: {e}", flush=True)
            import traceback
            traceback.print_exc()
        finally:
            controller.clean_up(page, type="done_browser")

        if i < num - 1:
            delay = random.uniform(5, 10)
            print(f"\n[*] Waiting {delay:.1f}s...", flush=True)
            time.sleep(delay)

    # Summary
    print(f"\n{'='*60}", flush=True)
    print(f"  RESULTS SUMMARY", flush=True)
    print(f"{'='*60}", flush=True)
    for r in results:
        token_s = "✅" if r["refresh_token"] else "❌"
        imap_s = "✅" if r["imap_ok"] else "❌"
        smtp_s = "✅" if r["smtp_ok"] else "❌"
        print(f"  {r['email']}", flush=True)
        print(f"    Password:      {r['password']}", flush=True)
        print(f"    OAuth2 Token:  {token_s}", flush=True)
        print(f"    IMAP:          {imap_s}", flush=True)
        print(f"    SMTP:          {smtp_s}", flush=True)
    print(f"{'='*60}", flush=True)

    with open(os.path.join(RESULTS_DIR, "v4_results.json"), "w") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    main()
#!/usr/bin/env python3
"""
Outlook registration runner - bypass proxy requirement, use direct connection.
"""
import os
import sys
import time
import random
import string
import secrets
import tempfile

os.environ['DISPLAY'] = ':99'

FIREFOX_PATH = '/home/node/.cache/ruyipage/browsers/firefox-151.0a1-151-ruyi-linux-x86_64/firefox/firefox'
RESULTS_DIR = '/tmp/outlook_register/Results'
os.makedirs(RESULTS_DIR, exist_ok=True)

from ruyipage import FirefoxPage, FirefoxOptions
from faker import Faker


def generate_strong_password(length=None):
    if length is None:
        length = random.randint(11, 15)
    chars = string.ascii_letters + string.digits + "!@#$%^&*"
    while True:
        password = "".join(secrets.choice(chars) for _ in range(length))
        if (any(c.islower() for c in password) and any(c.isupper() for c in password)
                and any(c.isdigit() for c in password) and any(c in "!@#$%^&*" for c in password)):
            return password


def random_email():
    letter_count = random.randint(6, 8)
    digit_count = random.randint(5, 6)
    letters = "".join(random.choice(string.ascii_lowercase) for _ in range(letter_count))
    digits = "".join(random.choice(string.digits) for _ in range(digit_count))
    return letters + digits


def create_page(proxy_config=None):
    profile = tempfile.mkdtemp(prefix='ruyi-outlook-')
    opts = FirefoxOptions()
    opts.set_user_dir(profile)
    opts.close_on_exit(True)
    opts.set_browser_path(FIREFOX_PATH)
    opts.set_pref('intl.accept_languages', 'zh-CN,zh,en-US,en')
    opts.set_human_algorithm("windmouse")
    
    if proxy_config:
        opts.set_proxy(proxy_config["requests_url"])
    
    page = FirefoxPage(opts)
    try:
        page.set_viewport(800, 600)
    except:
        pass
    try:
        page.window.set_window_size(820, 650)
    except:
        pass
    
    return page, profile


def text_exists(page, text):
    try:
        return bool(page.run_js(
            f"return !!document.body && document.body.innerText.includes('{text}');",
            as_expr=False,
        ))
    except:
        return False


def wait_for_any(page, locators, timeout=5):
    end_time = time.time() + timeout
    while time.time() < end_time:
        for locator in locators:
            try:
                element = page.ele(locator, timeout=0.2)
                if element:
                    return element
            except:
                pass
            page.wait(0.2)
    return False


def click_primary_button(page, timeout=5):
    button = wait_for_any(page, [
        "css:[data-testid='primaryButton']",
        "css:button[type='submit']",
        "xpath://button[@data-testid='primaryButton']",
    ], timeout=timeout)
    if not button:
        return False
    try:
        page.actions.move_to(button, duration=random.randint(80, 180)).click().perform()
    except:
        button.click()
    return True


def outlook_register(page, email_suffix="@outlook.com"):
    fake = Faker()
    email = random_email()
    password = generate_strong_password()
    lastname = fake.last_name()
    firstname = fake.first_name()
    year = str(random.randint(1960, 2005))
    month = str(random.randint(1, 12))
    day = str(random.randint(1, 28))
    full_email = f"{email}{email_suffix}"

    print(f"\n{'='*50}")
    print(f"  Registering: {full_email}")
    print(f"  Password: {password}")
    print(f"  Name: {firstname} {lastname}")
    print(f"  Birthday: {year}-{month}-{day}")
    print(f"{'='*50}")

    try:
        # Navigate to signup
        print("[1] Navigating to signup page...")
        page.get("https://outlook.live.com/mail/0/?prompt=create_account", wait="interactive", timeout=20)
        page.wait(3)
        
        print(f"  URL: {page.url}")
        print(f"  Title: {page.title}")
        
        # Check for consent button
        consent_locators = [
            "xpath://button[contains(normalize-space(.), '同意并继续')]",
            "xpath://*[@role='button'][contains(normalize-space(.), '同意并继续')]",
        ]
        consent = wait_for_any(page, consent_locators, timeout=5)
        if consent:
            print("[2] Clicking consent button...")
            try:
                page.actions.move_to(consent, duration=random.randint(80, 180)).click().perform()
            except:
                consent.click()
            page.wait(2)
        
        # Email input
        email_locators = [
            "css:[aria-label='新建电子邮件']",
            "css:input[aria-label='新建电子邮件']",
            "css:input[name='MemberName']",
        ]
        print("[3] Finding email input...")
        email_input = wait_for_any(page, email_locators, timeout=10)
        if not email_input:
            # Try preview for diagnosis
            preview = ""
            try:
                preview = page.run_js("return document.body ? document.body.innerText.substring(0, 300) : '';", as_expr=False)
            except:
                pass
            print(f"  [!] Email input not found. Preview: {preview[:200]}")
            return None, None
        
        print(f"[3] Typing email: {email}")
        try:
            page.actions.move_to(email_input, duration=random.randint(80, 180)).click().perform()
        except:
            email_input.click()
        page.wait(0.3)
        email_input.input(email, clear=True)
        page.wait(0.5)
        
        # Click next
        print("[4] Click next (email)...")
        if not click_primary_button(page, timeout=5):
            print("  [!] Next button not found after email")
            return None, None
        page.wait(2)
        
        # Password input
        print("[5] Finding password input...")
        password_input = wait_for_any(page, ["css:input[type='password']"], timeout=10)
        if not password_input:
            print("  [!] Password input not found")
            return None, None
        
        print(f"[5] Typing password")
        try:
            page.actions.move_to(password_input, duration=random.randint(80, 180)).click().perform()
        except:
            password_input.click()
        page.wait(0.3)
        password_input.input(password, clear=True)
        page.wait(0.5)
        
        # Click next (password)
        print("[6] Click next (password)...")
        if not click_primary_button(page, timeout=5):
            print("  [!] Next button not found after password")
            return None, None
        page.wait(2)
        
        # Birthday
        print("[7] Filling birthday...")
        birth_year = wait_for_any(page, ["css:[name='BirthYear']", "css:input[name='BirthYear']"], timeout=10)
        if not birth_year:
            print("  [!] Birth year input not found")
            return None, None
        birth_year.input(year, clear=True)
        page.wait(0.3)
        
        birth_month = wait_for_any(page, ["css:[name='BirthMonth']"], timeout=5)
        birth_day = wait_for_any(page, ["css:[name='BirthDay']"], timeout=5)
        
        if birth_month:
            try:
                birth_month.select.by_value(month)
            except:
                pass
        page.wait(0.3)
        
        if birth_day:
            try:
                birth_day.select.by_value(day)
            except:
                pass
        page.wait(0.5)
        
        # Click next (birthday)
        print("[8] Click next (birthday)...")
        if not click_primary_button(page, timeout=5):
            print("  [!] Next button not found after birthday")
            return None, None
        page.wait(3)
        
        # Name
        print("[9] Filling name...")
        last_name_input = wait_for_any(page, ["css:#lastNameInput"], timeout=10)
        first_name_input = wait_for_any(page, ["css:#firstNameInput"], timeout=10)
        
        if last_name_input:
            try:
                page.actions.move_to(last_name_input, duration=random.randint(80, 180)).click().perform()
            except:
                last_name_input.click()
            page.wait(0.2)
            last_name_input.input(lastname, clear=True)
        
        page.wait(0.3)
        
        if first_name_input:
            first_name_input.input(firstname, clear=True)
        
        page.wait(1)
        
        # Click next (name)
        print("[10] Click next (name)...")
        if not click_primary_button(page, timeout=5):
            print("  [!] Next button not found after name")
            return None, None
        
        page.wait(5)
        
        # Check for CAPTCHA
        print("[11] Checking for CAPTCHA/verification...")
        captcha_texts = ["证明你不是机器人", "长按该按钮", "可访问性挑战", "验证你不是机器人"]
        has_captcha = any(text_exists(page, text) for text in captcha_texts)
        
        if has_captcha:
            print("  [!] CAPTCHA detected! Cannot auto-solve in headless mode.")
            print("  Saving page state for manual intervention...")
            try:
                page.screenshot(path=os.path.join(RESULTS_DIR, "captcha_screenshot.png"))
                print("  Screenshot saved to Results/captcha_screenshot.png")
            except:
                pass
            
            # Get captcha page info
            try:
                preview = page.run_js("return document.body ? document.body.innerText.substring(0, 500) : '';", as_expr=False)
                print(f"  Page text: {preview[:300]}")
            except:
                pass
            
            return full_email, password  # Return credentials even though captcha stuck
        
        # Check if we're in mailbox
        current_url = page.url or ""
        if "outlook.live.com/mail" in current_url and "prompt=create_account" not in current_url:
            print(f"\n✅ SUCCESS: {full_email} / {password}")
            with open(os.path.join(RESULTS_DIR, "outlook_accounts.txt"), "a", encoding="utf-8") as f:
                f.write(f"{full_email}: {password}\n")
            return full_email, password
        
        # Wait more for mailbox
        page.wait(10)
        current_url = page.url or ""
        if "outlook.live.com/mail" in current_url:
            print(f"\n✅ SUCCESS: {full_email} / {password}")
            with open(os.path.join(RESULTS_DIR, "outlook_accounts.txt"), "a", encoding="utf-8") as f:
                f.write(f"{full_email}: {password}\n")
            return full_email, password
        
        print(f"  [?] Final URL: {current_url}")
        preview = ""
        try:
            preview = page.run_js("return document.body ? document.body.innerText.substring(0, 300) : '';", as_expr=False)
        except:
            pass
        print(f"  [?] Preview: {preview[:200]}")
        
        return full_email, password
        
    except Exception as e:
        print(f"[!] Error: {e}")
        import traceback
        traceback.print_exc()
        return None, None


def main():
    num = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    suffix = sys.argv[2] if len(sys.argv) > 2 else "@outlook.com"
    
    print(f"\n{'='*50}")
    print(f"  Outlook Registration Tool")
    print(f"  Count: {num} | Suffix: {suffix}")
    print(f"{'='*50}\n")
    
    results = []
    for i in range(num):
        print(f"\n--- Account {i+1}/{num} ---")
        page, profile = create_page()
        
        try:
            email, password = outlook_register(page, email_suffix=suffix)
            if email:
                results.append({"email": email, "password": password})
        except Exception as e:
            print(f"[!] Exception: {e}")
        finally:
            try:
                page.quit(timeout=5, force=True)
            except:
                pass
            try:
                import shutil
                shutil.rmtree(profile, ignore_errors=True)
            except:
                pass
        
        if i < num - 1:
            delay = random.uniform(3, 8)
            print(f"\n[*] Waiting {delay:.1f}s...")
            time.sleep(delay)
    
    print(f"\n{'='*50}")
    print(f"  Results: {len(results)} registered")
    for r in results:
        print(f"  ✅ {r['email']} / {r['password']}")
    print(f"{'='*50}")
    
    import json
    with open(os.path.join(RESULTS_DIR, "registration_results.json"), "w") as f:
        json.dump(results, f, indent=2)


if __name__ == "__main__":
    main()
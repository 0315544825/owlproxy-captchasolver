#!/usr/bin/env python3
"""Test old account - no shell escaping issues"""
import os, sys, time, json, base64, hashlib, secrets, string, imaplib, smtplib, requests
os.environ['DISPLAY'] = ':99'
from urllib.parse import parse_qs, quote
from ruyipage import FirefoxPage, FirefoxOptions
import tempfile

EMAIL = 'chctmbah435136@outlook.com'
PASSWORD = '7uGDMYdi^Pp!'
CLIENT_ID = '9e5f94bc-e8a4-4e73-b8be-63364c29d753'
SCOPES = 'offline_access https://outlook.office.com/IMAP.AccessAsUser.All https://outlook.office.com/SMTP.Send'
REDIRECT = 'https://login.microsoftonline.com/common/oauth2/nativeclient'
FIREFOX = '/home/node/.cache/ruyipage/browsers/firefox-151.0a1-151-ruyi-linux-x86_64/firefox/firefox'

verifier = ''.join(secrets.choice(string.ascii_letters + string.digits + '-._~') for _ in range(128))
challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip('=')

auth_url = (f'https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize?'
    f'client_id={CLIENT_ID}&response_type=code&redirect_uri={quote(REDIRECT)}'
    f'&scope={quote(SCOPES)}&response_mode=query'
    f'&code_challenge={challenge}&code_challenge_method=S256'
    f'&login_hint={quote(EMAIL)}')

sys.path.insert(0, '/tmp/outlook_register')
from controllers.ruyipage_controller import RuyiPageController
ctrl = RuyiPageController()
page, resource = ctrl.launch_browser(proxy_config=None)
if not page:
    print('Failed to launch browser!'); exit()

def wfa(p, ls, t=10):
    e = time.time() + t
    while time.time() < e:
        for l in ls:
            try:
                el = p.ele(l, timeout=0.5)
                if el: return el
            except: pass
        p.wait(0.3)
    return False

try:
    page.listen.start(REDIRECT)
    page.get(auth_url, wait='interactive', timeout=20)
    page.wait(5)
    cur = page.url or ''
    print(f'Initial URL: {cur[:100]}', flush=True)

    if 'code=' not in cur:
        # Email
        li = wfa(page, ['css:[name="loginfmt"]', 'css:#i0116'], t=10)
        if li:
            print(f'  Email input found, typing...', flush=True)
            # Use JS click to avoid viewport bounds issues
            page.run_js('document.getElementById("i0116").focus(); document.getElementById("i0116").value = "";', as_expr=False)
            page.wait(0.3)
            li.input(EMAIL, clear=True)
            page.wait(0.5)
            nxt = wfa(page, ['css:#idSIButton9'], t=5)
            if nxt:
                page.run_js('document.getElementById("idSIButton9").click();', as_expr=False)
            page.wait(5)

        # Check what page we're on
        cur2 = page.url or ''
        pt = page.run_js('return document.body?document.body.innerText.substring(0,300):""', as_expr=False)
        print(f'  After email: url={cur2[:80]}', flush=True)
        print(f'  Page text: {pt[:150]}', flush=True)

        # Password
        pi = wfa(page, ['css:[name="passwd"]', 'css:#i0118', 'css:input[type="password"]'], t=10)
        if pi:
            print(f'  Password input found, typing...', flush=True)
            page.run_js('var p=document.getElementById("i0118")||document.querySelector("[name=passwd]"); if(p){p.focus();p.value="";}', as_expr=False)
            page.wait(0.3)
            pi.input(PASSWORD, clear=True)
            page.wait(0.5)
            si = wfa(page, ['css:#idSIButton9'], t=5)
            if si:
                page.run_js('document.getElementById("idSIButton9").click();', as_expr=False)
            page.wait(6)
            cur3 = page.url or ''
            print(f'  After password: {cur3[:80]}', flush=True)
        else:
            print(f'  No password input found!', flush=True)
            print(f'  Page: {pt[:200]}', flush=True)

        # Handle any additional prompts
        for attempt in range(8):
            cu = page.url or ''
            if 'code=' in cu:
                break
            pkt = page.listen.wait(timeout=2)
            if pkt and 'code=' in (pkt.url or ''):
                break
            btn = wfa(page, ['css:#idSIButton9', 'css:[data-testid="appConsentPrimaryButton"]',
                           'xpath://button[contains(normalize-space(.),"是")]',
                           'xpath://button[contains(normalize-space(.),"Yes")]',
                           'xpath://button[contains(normalize-space(.),"Accept")]',
                           'xpath://button[contains(normalize-space(.),"允许")]'], t=5)
            if btn:
                print(f'  Clicking button (attempt {attempt})', flush=True)
                try: ctrl.click_element(page, btn)
                except:
                    try: btn.click()
                    except: page.run_js('document.getElementById("idSIButton9").click();', as_expr=False)
                page.wait(4)
            else:
                pt2 = page.run_js('return document.body?document.body.innerText.substring(0,300):""', as_expr=False)
                print(f'  No button. Page: {pt2[:200]}', flush=True)
                break

    # Final check for code
    captured = None
    for i in range(30):
        cu = page.url or ''
        if 'code=' in cu:
            captured = cu; break
        pkt = page.listen.wait(timeout=1)
        if pkt and 'code=' in (pkt.url or ''):
            captured = pkt.url; break
        page.wait(1)

    page.listen.stop()

    if not captured or 'code=' not in captured:
        cu = page.url or ''
        pt3 = page.run_js('return document.body?document.body.innerText.substring(0,300):""', as_expr=False)
        print(f'FAILED. URL={cu[:80]} Page={pt3[:200]}', flush=True)
        exit()

    code = parse_qs(captured.split('?')[1])['code'][0]
    print(f'Auth code obtained: {code[:20]}...', flush=True)

    r = requests.post('https://login.microsoftonline.com/consumers/oauth2/v2.0/token', data={
        'client_id': CLIENT_ID, 'code': code, 'redirect_uri': REDIRECT,
        'grant_type': 'authorization_code', 'code_verifier': verifier, 'scope': SCOPES
    }, headers={'Content-Type': 'application/x-www-form-urlencoded'}, timeout=15)

    tokens = r.json()
    if 'refresh_token' in tokens:
        print(f'OAUTH2 SUCCESS!', flush=True)
        at = tokens['access_token']

        # IMAP
        print('IMAP test...', flush=True)
        try:
            mail = imaplib.IMAP4_SSL('outlook.office365.com', 993, timeout=15)
            auth_s = f'user={EMAIL}\x01auth=Bearer {at}\x01\x01'
            mail.authenticate('XOAUTH2', lambda x: auth_s.encode())
            mail.select('INBOX')
            typ, data = mail.search(None, 'ALL')
            count = len(data[0].split()) if data[0] else 0
            print(f'  ✅ IMAP OK! {count} msgs', flush=True)
            mail.logout()
        except Exception as e:
            print(f'  ❌ IMAP: {e}', flush=True)

        # SMTP
        print('SMTP test...', flush=True)
        try:
            server = smtplib.SMTP('smtp-mail.outlook.com', 587, timeout=15)
            server.ehlo(); server.starttls(); server.ehlo()
            auth_b64 = base64.b64encode(f'user={EMAIL}\x01auth=Bearer {at}\x01\x01'.encode()).decode()
            code_r, _ = server.docmd('AUTH', 'XOAUTH2 ' + auth_b64)
            if code_r == 235:
                print(f'  ✅ SMTP OK!', flush=True)
            else:
                print(f'  ❌ SMTP: code={code_r}', flush=True)
            server.docmd('QUIT')
        except Exception as e:
            print(f'  ❌ SMTP: {e}', flush=True)
    else:
        print(f'Token failed: {json.dumps(tokens)[:200]}', flush=True)

except Exception as e:
    print(f'ERR: {e}', flush=True)
    import traceback; traceback.print_exc()
finally:
    try: page.quit(timeout=5, force=True)
    except: pass
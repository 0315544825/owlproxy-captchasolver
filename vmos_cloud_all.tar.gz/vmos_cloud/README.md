# VMOS Cloud 自动注册工具

基于 OwlProxy 脚本改编，适配 VMOS Cloud API。

## 文件结构

```
vmos_cloud/
├── vmos_cloud_api.md              # API 完整文档
├── accounts/                       # 注册账号存储目录
├── scripts/
│   ├── vmos_cloud_auto_register.py     # 全自动注册 (YYDS临时邮箱 + 浏览器解验证码)
│   ├── vmos_cloud_human_captcha_capture.py  # 人工解验证码 + 拦截 captchaVerifyParam
│   ├── vmos_cloud_register.py          # 纯API注册 (需提供 captchaVerifyParam)
│   └── vmos_cloud_oneclick.py          # 一键脚本: 注册 → 领设备 → 查信息
```

## 快速开始

### 1. 安装依赖

```bash
pip install requests opencv-python-headless numpy
# 浏览器自动化 (二选一):
pip install cloakbrowser  # 或
pip install playwright && playwright install chromium
```

### 2. 设置 YYDS API Key (用于自动创建临时邮箱)

```bash
export YYDS_KEY="your-mali-api-key"
```

### 3. 全自动注册

```bash
# 需要 Xvfb 虚拟显示器
xvfb-run --auto-servernum --server-args='-screen 0 1280x800x24' \
    python3 scripts/vmos_cloud_auto_register.py

# 指定邮箱
xvfb-run --auto-servernum --server-args='-screen 0 1280x800x24' \
    python3 scripts/vmos_cloud_auto_register.py --email you@example.com

# 批量注册
xvfb-run --auto-servernum --server-args='-screen 0 1280x800x24' \
    python3 scripts/vmos_cloud_auto_register.py --count 3
```

### 4. 人工解验证码

```bash
python3 scripts/vmos_cloud_human_captcha_capture.py --email you@example.com
# 在弹出的浏览器中手动拖动滑块，脚本会自动拦截 captchaVerifyParam
```

### 5. 纯 API 注册 (需预先获取 captchaVerifyParam)

```bash
python3 scripts/vmos_cloud_register.py \
    --email you@example.com \
    --password YourPassword123 \
    --captcha-token "eyJ..." \
    --verify-code 123456
```

### 6. 一键脚本

```bash
export YYDS_KEY="your-key"
xvfb-run --auto-servernum --server-args='-screen 0 1280x800x24' \
    python3 scripts/vmos_cloud_oneclick.py --register

# 使用已有账号
python3 scripts/vmos_cloud_oneclick.py --token YOUR_TOKEN
```

## 与 OwlProxy 的差异

两个平台使用**完全相同的阿里云验证码** (SceneId: 5jvar3wp, prefix: 69r0rc, region: sgp)，滑块解决方案可以直接复用。

主要差异:
- **API Base URL**: `https://api.vmoscloud.com/vcpcloud` (vs OwlProxy 的 `https://api.owlproxy.com/owlproxy`)
- **X-Tenant Header**: `vmoscloud` (OwlProxy 不需要)
- **appVersion**: `3.6.1800` (vs `2.6.1502`)
- **产品**: 云手机 (vs 代理服务)

## 注意事项

1. **验证码**: 必须通过浏览器解决阿里云滑块验证码，captchaVerifyParam 无法伪造
2. **密码**: 前端使用 MD5 哈希传输密码
3. **邮箱字段名**: `mobilePhone` 字段实际接受邮箱地址（命名误导）
4. **Headers**: smsSend 请求建议只用最少的 Headers，多余 Headers 可能导致签名失败
#!/usr/bin/env python3
"""VMOS Cloud CAPTCHA solver v2 — CDP-level input + trajectory analysis.

Core insight: The 2019 "Signature verification failed" error means Aliyun's
server-side anti-bot detected the automation, regardless of whether the slider
was visually "solved". The popup disappearing doesn't mean success — Aliyun
generates a flagged captchaVerifyParam token that VMOS's smsSend rejects.

Strategy:
1. Use CDP Input.dispatchMouseEvent for more authentic event dispatch
2. Record and replay realistic mouse trajectories with natural timing
3. Hook into Aliyun's captcha callback to check verification result BEFORE
   relying on smsSend
4. If captcha callback indicates failure, retry with different trajectory
5. Add extensive diagnostics to understand what's happening
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import math
import os
import random
import re
import sys
import time
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import requests

try:
    from cloakbrowser import launch_async as cloakbrowser_launch
    HAS_CLOAKBROWSER = True
except ImportError:
    HAS_CLOAKBROWSER = False

# ── Config ──────────────────────────────────────────────────────────
API_BASE = "https://api.vmoscloud.com/vcpcloud"
FRONTEND_URL = "https://cloud.vmoscloud.com"
YYDS_BASE = "https://maliapi.215.im/v1"
ALIYUN_BG_WIDTH = 300

ACCOUNTS_DIR = Path(__file__).resolve().parent.parent / "accounts"

EMAIL_SELECTORS = [
    'input[placeholder*="email"]',
    'input[placeholder*="Email"]',
    'input[placeholder*="邮箱"]',
    'input[type="email"]',
]
LOGIN_BTN_SELECTORS = [
    'button:has-text("Login")',
    'button:has-text("Register")',
    'button:has-text("登录")',
    'button:has-text("注册")',
]


def load_yyds_key() -> str:
    return (os.environ.get("YYDS_KEY") or os.environ.get("MALI_API_KEY") or "AC-29e9b09c5ae93e1347debb66").strip()


def md5_password(p: str) -> str:
    return hashlib.md5(p.encode()).hexdigest()


def vmos_headers(token: str | None = None) -> dict[str, str]:
    h = {
        "Content-Type": "application/json",
        "Accept-Language": "en",
        "clientType": "web",
        "appVersion": "3.6.1800",
        "requestsource": "wechat-miniapp",
        "SupplierType": "0",
        "X-Tenant": "vmoscloud",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    }
    if token:
        h["Token"] = token
    return h


def create_email_yyds(domain: str | None = None) -> tuple[str, str, str]:
    key = load_yyds_key()
    if not domain:
        domain = "a0.engineer"
    local = f"vmos{int(time.time())}{random.randint(10,99)}"
    resp = requests.post(f"{YYDS_BASE}/accounts",
                         headers={"X-API-Key": key, "Content-Type": "application/json"},
                         json={"localPart": local, "domain": domain}, timeout=15)
    result = resp.json()
    if not result.get("success"):
        raise RuntimeError(f"YYDS create failed: {result}")
    return result["data"]["address"], local, domain


def poll_yyds_code(email: str, timeout_s: int = 180, interval: int = 5) -> str | None:
    key = load_yyds_key()
    deadline = time.time() + timeout_s
    idx = 0
    while time.time() < deadline:
        idx += 1
        time.sleep(interval)
        try:
            r = requests.get(f"{YYDS_BASE}/messages",
                           params={"address": email},
                           headers={"X-API-Key": key}, timeout=15)
            msgs = (r.json().get("data") or {}).get("messages") or []
            for msg in msgs:
                mid = msg.get("id")
                full = requests.get(f"{YYDS_BASE}/messages/{mid}",
                                  params={"address": email},
                                  headers={"X-API-Key": key}, timeout=15).text
                codes = re.findall(r'\b(\d{6})\b', full)
                if codes:
                    print(f"  [YYDS] Found code: {codes[-1]}")
                    return codes[-1]
        except Exception as e:
            print(f"  [YYDS] Poll #{idx} error: {e}")
        if idx % 3 == 0:
            print(f"  [YYDS] Waiting... ({idx * interval}s)")
    return None


# ── CV Gap Detection ─────────────────────────────────────────────────

def find_gap_in_crop(bg_img: np.ndarray) -> int | None:
    """Find puzzle gap position using edge detection."""
    gray = cv2.cvtColor(bg_img, cv2.COLOR_BGR2GRAY) if len(bg_img.shape) == 3 else bg_img
    h, w = gray.shape
    if w < 50 or h < 20:
        return None

    edges = cv2.Canny(gray, 50, 150)
    blurred = cv2.GaussianBlur(edges, (5, 5), 0)
    col_sums = np.sum(blurred, axis=0).astype(float)

    kernel_size = min(15, w // 10)
    if kernel_size > 2:
        col_sums = np.convolve(col_sums, np.ones(kernel_size) / kernel_size, mode='same')

    mean_sum = np.mean(col_sums)
    std_sum = np.std(col_sums)
    if std_sum < 1:
        return None

    threshold = mean_sum + 1.5 * std_sum
    peaks = [i for i in range(1, len(col_sums) - 1)
             if col_sums[i] > threshold and col_sums[i] > col_sums[i-1] and col_sums[i] > col_sums[i+1]]

    GAP_MIN = int(w * 0.12)
    GAP_MAX = int(w * 0.22)
    best_x = None
    best_score = 0
    for i in range(len(peaks)):
        for j in range(i + 1, len(peaks)):
            gw = peaks[j] - peaks[i]
            if GAP_MIN <= gw <= GAP_MAX:
                score = col_sums[peaks[i]] + col_sums[peaks[j]] + 0.1 * (peaks[i] / w) * col_sums[peaks[i]]
                if score > best_score:
                    best_score = score
                    best_x = (peaks[i] + peaks[j]) // 2
    if best_x is not None:
        return best_x

    # Fallback: block diff
    block_w = max(w // 6, 30)
    block_h = h // 2
    best_x2 = None
    best_diff = 0
    for x in range(w // 6, w - block_w):
        block = gray[h // 4: h // 4 + block_h, x: x + block_w]
        if x + block_w < w and block.size > 0:
            next_block = gray[h // 4: h // 4 + block_h, x + block_w: x + 2 * block_w]
            if next_block.size > 0:
                diff = abs(float(np.mean(block)) - float(np.mean(next_block)))
                score = diff + np.sum(np.abs(np.diff(gray[h // 4: h // 4 + block_h, max(0, x-1):x+1]))) * 0.001
                if score > best_diff:
                    best_diff = score
                    best_x2 = x
    return best_x2


async def detect_drag_distance(page) -> int | None:
    """Detect drag distance from CAPTCHA screenshot + DOM analysis."""
    shot_path = "/tmp/vmos_captcha_current.png"
    await page.screenshot(path=shot_path)
    img = cv2.imread(shot_path)
    if img is None:
        return None
    h, w = img.shape[:2]
    print(f"  [CV] Screenshot: {w}x{h}")

    # Get puzzle DOM info
    puzzle_info = await page.evaluate("""() => {
        const popup = document.getElementById('aliyunCaptcha-window-popup');
        if (!popup) return null;
        const bgImg = popup.querySelector('img');
        if (!bgImg) return null;
        const bgRect = bgImg.getBoundingClientRect();
        const slider = document.getElementById('aliyunCaptcha-sliding-slider') ||
                       popup.querySelector('[class*="slider"]');
        if (!slider) return null;
        const sliderRect = slider.getBoundingClientRect();
        // Also get the puzzle piece (small image that sits on top)
        const allImgs = popup.querySelectorAll('img');
        let pieceRect = null;
        for (const img of allImgs) {
            const rect = img.getBoundingClientRect();
            // Piece image is small (~50x50) and different from background
            if (rect.width > 5 && rect.width < bgRect.width && rect !== bgImg) {
                pieceRect = { x: rect.x, y: rect.y, w: rect.width, h: rect.height };
            }
        }
        return {
            bgX: bgRect.x, bgY: bgRect.y, bgW: bgRect.width, bgH: bgRect.height,
            sliderX: sliderRect.x, sliderY: sliderRect.y,
            sliderW: sliderRect.width, sliderH: sliderRect.height,
            pieceX: pieceRect ? pieceRect.x : null,
            pieceW: pieceRect ? pieceRect.w : null,
        };
    }""")

    if not puzzle_info:
        print("  [CV] No puzzle info from DOM")
        return random.randint(140, 160)

    print(f"  [CV] Puzzle: bg=({puzzle_info['bgX']:.0f},{puzzle_info['bgY']:.0f}) "
          f"{puzzle_info['bgW']:.0f}x{puzzle_info['bgH']:.0f} "
          f"slider=({puzzle_info['sliderX']:.0f},{puzzle_info['sliderY']:.0f}) "
          f"{puzzle_info['sliderW']:.0f}x{puzzle_info['sliderH']:.0f}")

    # If we have piece position, calculate gap from piece vs background coordinates
    # The piece sits at its initial position (left side) and needs to be dragged
    # to the gap position (somewhere in the middle/right of the background)
    piece_x = puzzle_info.get('pieceX')
    piece_w = puzzle_info.get('pieceW')
    bg_x = puzzle_info['bgX']
    bg_w = puzzle_info['bgW']
    slider_x = puzzle_info['sliderX']

    # Crop background area for edge detection
    x1 = max(0, int(bg_x))
    y1 = max(0, int(puzzle_info['bgY']))
    x2 = min(img.shape[1], int(bg_x + bg_w))
    y2 = min(img.shape[0], int(puzzle_info['bgY'] + puzzle_info['bgH']))

    bg_crop = img[y1:y2, x1:x2]
    if bg_crop.size > 0:
        gap_in_crop = find_gap_in_crop(bg_crop)
        if gap_in_crop is not None:
            # The gap is at absolute position: bg_x + gap_in_crop
            # The slider starts at absolute position: slider_x
            # But we need to account for the fact that the Aliyun CAPTCHA
            # background image is typically 300px wide internally.
            # The slider track width ≈ bg_w (the slider starts at the left
            # edge of the background image and can slide to the right edge).
            # Drag distance = gap_position_relative_to_bg_start
            # In screen coords: gap_abs = bg_x + gap_in_crop
            # The piece starts at the piece position, the gap is at gap_in_crop
            # within the background. The drag distance in internal coords is:
            # gap_in_crop * (ALIYUN_BG_WIDTH / bg_w)
            # But in screen coords, it's just: gap_in_crop
            # (since the background image is displayed at bg_w pixels)

            # Actually, the drag distance in SCREEN pixels is:
            # gap_screen_x - slider_start_x
            # = (bg_x + gap_in_crop) - slider_x
            # But slider_x might not be at bg_x (it could be at the left edge
            # of the track which is the same as bg_x for Aliyun CAPTCHA)

            # For Aliyun CAPTCHA, the slider track typically starts at the
            # left edge of the background image, so:
            drag = gap_in_crop + (bg_x - slider_x)
            drag = int(max(30, min(260, drag)))

            print(f"  [CV] Gap in crop: {gap_in_crop}px, bg offset: {bg_x - slider_x:.0f}, drag: {drag}px")
            return drag

    # Fallback: random distance
    drag = random.randint(140, 160)
    print(f"  [CV] No gap detected, fallback: {drag}px")
    return drag


# ── CDP Mouse Events ─────────────────────────────────────────────────

async def cdp_drag_slider(page, start_x: float, start_y: float, distance: int):
    """Drag slider using CDP Input.dispatchMouseEvent for more authentic events.

    This bypasses Playwright's event system and sends events directly through
    Chrome DevTools Protocol, which produces events that are closer to real
    user input.
    """
    cdp = page.context  # We need the CDP session

    # Get CDP session
    try:
        client = await page.context.new_cdp_session(page) if hasattr(page.context, 'new_cdp_session') else None
    except Exception:
        client = None

    # Random pre-movement pause
    await asyncio.sleep(random.uniform(0.3, 0.8))

    # Approach the slider
    approach_x = start_x + random.uniform(-3, 3)
    approach_y = start_y + random.uniform(-2, 2)

    if client:
        # Use CDP for more authentic events
        await client.send('Input.dispatchMouseEvent', {
            'type': 'mouseMoved', 'x': approach_x, 'y': approach_y
        })
        await asyncio.sleep(random.uniform(0.1, 0.3))

        # Small micro-movements
        for _ in range(random.randint(2, 4)):
            dx = random.uniform(-2, 2)
            dy = random.uniform(-1, 1)
            await client.send('Input.dispatchMouseEvent', {
                'type': 'mouseMoved', 'x': start_x + dx, 'y': start_y + dy
            })
            await asyncio.sleep(random.uniform(0.03, 0.08))

        # Press down
        await client.send('Input.dispatchMouseEvent', {
            'type': 'mousePressed', 'x': start_x, 'y': start_y,
            'button': 'left', 'clickCount': 1
        })
        await asyncio.sleep(random.uniform(0.1, 0.2))

        # Generate trajectory
        end_x = start_x + distance
        end_y = start_y + random.uniform(-3, 3)
        ctrl1_x = start_x + distance * random.uniform(0.25, 0.45)
        ctrl1_y = start_y + random.uniform(-10, 10)
        ctrl2_x = start_x + distance * random.uniform(0.55, 0.80)
        ctrl2_y = start_y + random.uniform(-8, 8)

        total_steps = random.randint(50, 70)
        micro_pause_steps = set(random.sample(range(12, total_steps - 8), random.randint(2, 4)))

        prev_x = start_x
        for step in range(total_steps):
            t = step / total_steps

            # Realistic easing: slow start → fast middle → slow end → slight overshoot → correction
            if t < 0.08:
                progress = t * t / (0.08) * 0.08
            elif t < 0.3:
                progress = 0.08 + (t - 0.08) * 1.3
            elif t < 0.75:
                progress = 0.08 + 0.22 * 1.3 + (t - 0.3) * 0.8
            elif t < 0.92:
                remaining = 1.0 - t
                progress = 1.0 - remaining * remaining * 0.5
            else:
                progress = 0.97 + (t - 0.92) * (0.03 / 0.08) * 0.3
            progress = min(1.0, max(0.0, progress))

            # Bézier interpolation
            x = ((1-progress)**3 * start_x +
                 3*(1-progress)**2 * progress * ctrl1_x +
                 3*(1-progress) * progress**2 * ctrl2_x +
                 progress**3 * end_x)
            y = ((1-progress)**3 * start_y +
                 3*(1-progress)**2 * progress * ctrl1_y +
                 3*(1-progress) * progress**2 * ctrl2_y +
                 progress**3 * end_y)

            # Add Perlin-like noise for natural hand tremor
            noise_x = random.gauss(0, 0.5) + 0.3 * math.sin(step * 0.7)
            noise_y = random.gauss(0, 1.0) + 0.5 * math.sin(step * 0.5 + random.uniform(0, 1))
            actual_x = max(prev_x + 0.3, x + noise_x) if progress > 0.2 else x + noise_x
            actual_y = y + noise_y

            await client.send('Input.dispatchMouseEvent', {
                'type': 'mouseMoved', 'x': actual_x, 'y': actual_y
            })

            # Variable delay — mimics neural processing delay
            base_delay = 0.015
            if progress < 0.1:
                base_delay = 0.025
            elif progress > 0.85:
                base_delay = 0.02
            base_delay += random.uniform(-0.003, 0.005)
            await asyncio.sleep(max(0.008, base_delay))

            if step in micro_pause_steps:
                await asyncio.sleep(random.uniform(0.06, 0.14))

            prev_x = actual_x

        # Overshoot + correction (very human-like)
        overshoot = random.uniform(4, 10)
        await client.send('Input.dispatchMouseEvent', {
            'type': 'mouseMoved', 'x': end_x + overshoot, 'y': end_y + random.gauss(0, 1)
        })
        await asyncio.sleep(random.uniform(0.1, 0.2))

        # Small correction back
        correction_x = end_x + random.uniform(-1.5, 1.5)
        correction_y = end_y + random.gauss(0, 0.8)
        await client.send('Input.dispatchMouseEvent', {
            'type': 'mouseMoved', 'x': correction_x, 'y': correction_y
        })
        await asyncio.sleep(random.uniform(0.05, 0.12))

        # Release
        await client.send('Input.dispatchMouseEvent', {
            'type': 'mouseReleased', 'x': correction_x, 'y': correction_y,
            'button': 'left', 'clickCount': 1
        })
    else:
        # Fallback to Playwright mouse events with improved trajectory
        await page.mouse.move(approach_x, approach_y)
        await asyncio.sleep(random.uniform(0.1, 0.3))

        for _ in range(random.randint(2, 4)):
            await page.mouse.move(start_x + random.uniform(-2, 2), start_y + random.uniform(-1, 1))
            await asyncio.sleep(random.uniform(0.03, 0.08))

        await page.mouse.move(start_x, start_y)
        await asyncio.sleep(random.uniform(0.05, 0.12))
        await page.mouse.down()
        await asyncio.sleep(random.uniform(0.1, 0.2))

        end_x = start_x + distance
        end_y = start_y + random.uniform(-3, 3)
        ctrl1_x = start_x + distance * random.uniform(0.25, 0.45)
        ctrl1_y = start_y + random.uniform(-10, 10)
        ctrl2_x = start_x + distance * random.uniform(0.55, 0.80)
        ctrl2_y = start_y + random.uniform(-8, 8)

        total_steps = random.randint(50, 70)
        micro_pause_steps = set(random.sample(range(12, total_steps - 8), random.randint(2, 4)))

        prev_x = start_x
        for step in range(total_steps):
            t = step / total_steps

            if t < 0.08:
                progress = t * t / 0.08 * 0.08
            elif t < 0.3:
                progress = 0.08 + (t - 0.08) * 1.3
            elif t < 0.75:
                progress = 0.08 + 0.22 * 1.3 + (t - 0.3) * 0.8
            elif t < 0.92:
                remaining = 1.0 - t
                progress = 1.0 - remaining * remaining * 0.5
            else:
                progress = 0.97 + (t - 0.92) * 0.03 / 0.08 * 0.3
            progress = min(1.0, max(0.0, progress))

            x = ((1-progress)**3 * start_x +
                 3*(1-progress)**2 * progress * ctrl1_x +
                 3*(1-progress) * progress**2 * ctrl2_x +
                 progress**3 * end_x)
            y = ((1-progress)**3 * start_y +
                 3*(1-progress)**2 * progress * ctrl1_y +
                 3*(1-progress) * progress**2 * ctrl2_y +
                 progress**3 * end_y)

            noise_x = random.gauss(0, 0.5) + 0.3 * math.sin(step * 0.7)
            noise_y = random.gauss(0, 1.0) + 0.5 * math.sin(step * 0.5 + random.uniform(0, 1))
            actual_x = max(prev_x + 0.3, x + noise_x) if progress > 0.2 else x + noise_x
            actual_y = y + noise_y

            await page.mouse.move(actual_x, actual_y)

            base_delay = 0.015
            if progress < 0.1:
                base_delay = 0.025
            elif progress > 0.85:
                base_delay = 0.02
            base_delay += random.uniform(-0.003, 0.005)
            await asyncio.sleep(max(0.008, base_delay))

            if step in micro_pause_steps:
                await asyncio.sleep(random.uniform(0.06, 0.14))

            prev_x = actual_x

        # Overshoot + correction
        overshoot = random.uniform(4, 10)
        await page.mouse.move(end_x + overshoot, end_y + random.gauss(0, 1))
        await asyncio.sleep(random.uniform(0.1, 0.2))
        await page.mouse.move(end_x + random.uniform(-1.5, 1.5), end_y + random.gauss(0, 0.8))
        await asyncio.sleep(random.uniform(0.05, 0.12))
        await page.mouse.up()


# ── Browser ──────────────────────────────────────────────────────────

async def launch_browser():
    if HAS_CLOAKBROWSER:
        print("[BROWSER] Using CloakBrowser")
        browser = await cloakbrowser_launch(
            headless=False,
            args=["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage"],
        )
    else:
        from playwright.async_api import async_playwright
        pw = await async_playwright().start()
        browser = await pw.chromium.launch(
            headless=False,
            args=["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage",
                  "--disable-blink-features=AutomationControlled"],
        )

    context = await browser.new_context(
        viewport={"width": 1280, "height": 800},
        locale="en",
        timezone_id="America/New_York",
        user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    )

    # Stealth scripts
    await context.add_init_script("""
        Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
        window.chrome = { runtime: {} };
        const origQuery = window.navigator.permissions.query.bind(window.navigator.permissions);
        window.navigator.permissions.query = (p) => p.name === 'notifications'
            ? Promise.resolve({ state: Notification.permission })
            : origQuery(p);
        Object.defineProperty(navigator, 'plugins', { get: () => [1,2,3,4,5] });
        Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'] });
    """)

    return browser, context


async def fill_and_trigger_captcha(page, email: str) -> bool:
    try:
        await page.click('[class*="agreement"]', timeout=2000)
    except Exception:
        pass
    await asyncio.sleep(0.3)

    print(f"  Filling email: {email}")
    filled = False
    for sel in EMAIL_SELECTORS:
        try:
            await page.click(sel, timeout=3000)
            await asyncio.sleep(0.2)
            await page.fill(sel, "", timeout=1000)
            for char in email:
                await page.type(sel, char, delay=random.randint(30, 80))
            filled = True
            break
        except Exception:
            continue
    if not filled:
        print("  Could not fill email!")
        return False

    await asyncio.sleep(random.uniform(0.5, 1.0))

    print("  Clicking Login/Register...")
    for sel in LOGIN_BTN_SELECTORS:
        try:
            await page.click(sel, timeout=3000)
            break
        except Exception:
            continue

    # Wait for CAPTCHA to appear
    deadline = time.time() + 15
    while time.time() < deadline:
        try:
            captcha_state = await page.evaluate("""() => {
                const popup = document.getElementById('aliyunCaptcha-window-popup');
                const slider = document.getElementById('aliyunCaptcha-sliding-slider') ||
                               (popup && popup.querySelector('[class*="slider"]'));
                const visible = !!popup && popup.style.display !== 'none' && popup.offsetHeight > 0;
                return { visible, hasSlider: !!slider };
            }""")
            if captcha_state and (captcha_state.get("visible") or captcha_state.get("hasSlider")):
                print("  CAPTCHA slider detected")
                return True
        except Exception:
            pass
        await asyncio.sleep(0.5)

    return False


async def solve_captcha(page, max_attempts: int = 6) -> bool:
    """Solve CAPTCHA with CDP-level input and Aliyun callback monitoring."""
    for attempt in range(1, max_attempts + 1):
        print(f"\n[CAPTCHA] Attempt {attempt}/{max_attempts}")
        await asyncio.sleep(random.uniform(1.5, 2.5))

        # Inject callback monitor to check captcha result
        await page.evaluate("""() => {
            window.__captchaResult = null;
            // Try to hook into Aliyun's callback
            const origInit = window.initAliyunCaptcha;
            if (origInit) {
                window.initAliyunCaptcha = function(config) {
                    const origCallback = config.captchaVerifyCallback;
                    config.captchaVerifyCallback = async function(param) {
                        window.__captchaResult = { captchaVerifyParam: param, timestamp: Date.now() };
                        if (origCallback) return origCallback(param);
                        return param;
                    };
                    return origInit(config);
                };
            }
        }""")

        # Detect drag distance
        drag_distance = await detect_drag_distance(page)
        if drag_distance is None or drag_distance < 90:
            old = drag_distance
            drag_distance = random.randint(140, 160)
            print(f"  [CAPTCHA] Distance {old}px too low/None; using fallback: {drag_distance}px")

        # Find slider
        slider = await page.query_selector('#aliyunCaptcha-sliding-slider') or \
                 await page.query_selector('[class*="slider"]')
        if not slider:
            captcha_visible = await page.evaluate("""() => {
                const el = document.getElementById('aliyunCaptcha-window-popup');
                return el && el.style.display !== 'none' && el.offsetHeight > 0;
            }""")
            if not captcha_visible:
                print("  ✅ CAPTCHA already passed!")
                return True
            print("  No slider found")
            return False

        box = await slider.bounding_box()
        if not box:
            print("  Slider has no bounding box")
            return False

        start_x = box["x"] + box["width"] / 2
        start_y = box["y"] + box["height"] / 2
        actual_drag = max(30, drag_distance + random.randint(-2, 2))
        print(f"  Slider at ({start_x:.0f}, {start_y:.0f}), dragging {actual_drag}px")

        # Drag with CDP-level input
        await cdp_drag_slider(page, start_x, start_y, actual_drag)

        # Wait for verification
        await asyncio.sleep(4 + random.uniform(0.5, 1.5))

        # Check if CAPTCHA popup is gone
        captcha_visible = await page.evaluate("""() => {
            const el = document.getElementById('aliyunCaptcha-window-popup');
            return el && el.style.display !== 'none' && el.offsetHeight > 0;
        }""")

        # Check for success/failure text in the DOM
        captcha_result = await page.evaluate("""() => {
            const popup = document.getElementById('aliyunCaptcha-window-popup');
            if (!popup) return { visible: false, text: null };
            const visible = popup.style.display !== 'none' && popup.offsetHeight > 0;
            // Check for success/failure indicators
            const successEl = popup.querySelector('[class*="success"]') ||
                             popup.querySelector('[class*="valid"]');
            const failEl = popup.querySelector('[class*="fail"]') ||
                          popup.querySelector('[class*="err"]') ||
                          popup.querySelector('[class*="error"]');
            return {
                visible,
                success: !!successEl,
                fail: !!failEl,
                text: popup.textContent.substring(0, 200)
            };
        }""")

        print(f"  [CAPTCHA] visible={captcha_result.get('visible')}, "
              f"success={captcha_result.get('success')}, fail={captcha_result.get('fail')}, "
              f"text={str(captcha_result.get('text', ''))[:80]}")

        if not captcha_visible:
            print(f"  ✅ CAPTCHA popup closed (attempt {attempt})!")
            # Wait a bit more and check for any error messages
            await asyncio.sleep(2)
            return True

        # Check our injected callback
        captcha_cb_result = await page.evaluate("() => window.__captchaResult")
        if captcha_cb_result:
            print(f"  [CAPTCHA] Callback fired: param length={len(str(captcha_cb_result.get('captchaVerifyParam', '')))}")

        print(f"  ❌ CAPTCHA still visible, retrying...")

        # Refresh
        try:
            refresh = await page.query_selector('#aliyunCaptcha-btn-refresh') or \
                      await page.query_selector('[class*="refresh"]')
            if refresh:
                await asyncio.sleep(random.uniform(1.0, 2.0))
                await refresh.click()
                await asyncio.sleep(random.uniform(2.0, 3.5))
        except Exception:
            pass

    return False


async def register_one(email: str, password: str = "VmosCloud2026!", captcha_retries: int = 6) -> dict | None:
    browser, context = await launch_browser()
    page = await context.new_page()

    captured = {"smsSend_response": None}

    async def on_response(resp):
        if "smsSend" in resp.url:
            try:
                text = await resp.text()
                captured["smsSend_response"] = text
                result = json.loads(text)
                code = result.get("code")
                if code == 200:
                    print(f"  [INTERCEPT] ✅ smsSend SUCCESS")
                elif code == 2019:
                    print(f"  [INTERCEPT] ❌ smsSend Signature verification FAILED (2019)")
                else:
                    print(f"  [INTERCEPT] ⚠️ smsSend code={code}: {result.get('msg', '')[:80]}")
            except Exception:
                pass

    page.on("response", on_response)

    try:
        print(f"\n[1] Opening VMOS Cloud...")
        await page.goto(FRONTEND_URL, wait_until="networkidle", timeout=60000)
        await asyncio.sleep(random.uniform(1.5, 3.0))

        print(f"[2] Filling email: {email}")
        captcha_appeared = await fill_and_trigger_captcha(page, email)

        if captcha_appeared:
            print(f"[3] Solving CAPTCHA...")
            solved = await solve_captcha(page, max_attempts=captcha_retries)
            if not solved:
                print("  CAPTCHA not solved")
                await page.screenshot(path="/tmp/vmos_captcha_failure.png")
            await asyncio.sleep(3)
        else:
            print("  No CAPTCHA, waiting...")
            await asyncio.sleep(5)

        print(f"\n[4] Checking smsSend result...")
        if captured["smsSend_response"]:
            result = json.loads(captured["smsSend_response"])
            code = result.get("code")
            if code == 200:
                print(f"  ✅ Verification code sent!")
            elif code == 2019:
                print(f"  ❌ Signature verification failed")
            else:
                print(f"  ⚠️ code={code}")
        else:
            print(f"  No smsSend intercepted")

        print(f"\n[5] Polling YYDS for code to {email}...")
        verify_code = poll_yyds_code(email, timeout_s=180)
        if not verify_code:
            print("  ❌ No verification code received")
            await page.screenshot(path="/tmp/vmos_no_code.png")
            return None

        print(f"  ✅ Got code: {verify_code}")

        print(f"\n[6] Logging in...")
        resp = requests.post(f"{API_BASE}/api/user/login", headers=vmos_headers(), json={
            "mobilePhone": email, "loginType": 0, "verifyCode": verify_code,
            "password": md5_password(password), "channel": ""
        }, timeout=30)
        result = resp.json()

        if result.get("code") == 200:
            data = result.get("data", {})
            token = data.get("token", "")
            user_id = data.get("userId", "")
            is_new = data.get("isRegister", False)

            ACCOUNTS_DIR.mkdir(parents=True, exist_ok=True)
            account = {
                "email": email, "password": password,
                "password_md5": md5_password(password),
                "token": token, "userId": user_id,
                "isRegister": is_new, "platform": "vmos_cloud",
                "created_at": int(time.time()),
            }
            out_file = ACCOUNTS_DIR / f"{email}.json"
            out_file.write_text(json.dumps(account, ensure_ascii=False, indent=2))

            print(f"\n{'='*50}")
            print(f"  ✅ {'REGISTERED' if is_new else 'LOGGED IN'}!")
            print(f"  Email:    {email}")
            print(f"  Password: {password}")
            print(f"  User ID:  {user_id}")
            print(f"  Token:    {token[:30]}..." if token else "  Token:    N/A")
            print(f"  Saved:    {out_file}")
            print(f"{'='*50}")
            return account
        else:
            print(f"  ❌ Login failed: {result}")
            return None

    finally:
        await browser.close()


async def main():
    import argparse
    parser = argparse.ArgumentParser(description="VMOS Cloud registration v2 — CDP input + trajectory analysis")
    parser.add_argument("--email", default=None)
    parser.add_argument("--password", default="VmosCloud2026!")
    parser.add_argument("--domain", default="a0.engineer")
    parser.add_argument("--captcha-retries", type=int, default=6)
    parser.add_argument("--count", type=int, default=1)
    parser.add_argument("--retries", type=int, default=2)
    args = parser.parse_args()

    results = []
    for i in range(args.count):
        email = args.email
        if not email:
            print(f"\n[0] Creating YYDS email...")
            try:
                email, _, _ = create_email_yyds(args.domain)
                print(f"  Email: {email}")
            except Exception as e:
                print(f"  ❌ Failed: {e}")
                continue

        for attempt in range(1, args.retries + 1):
            print(f"\n{'='*60}")
            print(f"  Account {i+1}/{args.count}, attempt {attempt}/{args.retries}")
            print(f"{'='*60}")
            result = await register_one(email, args.password, args.captcha_retries)
            if result:
                results.append(result)
                break
            if attempt < args.retries:
                wait = random.uniform(5, 10)
                print(f"  Retrying in {wait:.1f}s...")
                await asyncio.sleep(wait)

    print(f"\n{'='*60}")
    print(f"  Results: {len(results)}/{args.count} successful")
    for r in results:
        print(f"  {r['email']} → userId={r.get('userId')}")
    print(f"{'='*60}")


if __name__ == "__main__":
    asyncio.run(main())
#!/usr/bin/env python3
"""VMOS Cloud CAPTCHA solver v3 — Touch events + improved detection.

Key changes from v2:
1. Use touch events (touchstart/touchmove/touchend) instead of mouse events
   - Aliyun may treat touch events differently than mouse events
   - Mobile touch events have different trajectory patterns
2. Improved CAPTCHA visibility detection (check class names, not just display)
3. Better gap detection using puzzle piece position
4. Added real-time captcha verification monitoring
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import math
import os
import random
import re
import time
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import requests

try:
    from cloakbrowser import launch_async as cloakbrowser_launch
    HAS_CLOAKBROWSER = True
except ImportError:
    HAS_CLOAKBROWSER = False

API_BASE = "https://api.vmoscloud.com/vcpcloud"
FRONTEND_URL = "https://cloud.vmoscloud.com"
YYDS_BASE = "https://maliapi.215.im/v1"
ACCOUNTS_DIR = Path(__file__).resolve().parent.parent / "accounts"

EMAIL_SELECTORS = ['input[placeholder*="email"]', 'input[placeholder*="Email"]', 'input[placeholder*="邮箱"]', 'input[type="email"]']
LOGIN_BTN_SELECTORS = ['button:has-text("Login")', 'button:has-text("Register")', 'button:has-text("登录")', 'button:has-text("注册")']


def load_yyds_key() -> str:
    return (os.environ.get("YYDS_KEY") or os.environ.get("MALI_API_KEY") or "AC-29e9b09c5ae93e1347debb66").strip()

def md5_password(p: str) -> str:
    return hashlib.md5(p.encode()).hexdigest()

def vmos_headers(token=None):
    h = {"Content-Type": "application/json", "Accept-Language": "en", "clientType": "web",
         "appVersion": "3.6.1800", "requestsource": "wechat-miniapp", "SupplierType": "0",
         "X-Tenant": "vmoscloud", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
    if token: h["Token"] = token
    return h

def create_email_yyds(domain="a0.engineer"):
    key = load_yyds_key()
    local = f"vmos{int(time.time())}{random.randint(10,99)}"
    resp = requests.post(f"{YYDS_BASE}/accounts", headers={"X-API-Key": key, "Content-Type": "application/json"},
                         json={"localPart": local, "domain": domain}, timeout=15)
    result = resp.json()
    if not result.get("success"):
        raise RuntimeError(f"YYDS create failed: {result}")
    return result["data"]["address"], local, domain

def poll_yyds_code(email, timeout_s=180, interval=5):
    key = load_yyds_key()
    deadline = time.time() + timeout_s
    idx = 0
    while time.time() < deadline:
        idx += 1; time.sleep(interval)
        try:
            r = requests.get(f"{YYDS_BASE}/messages", params={"address": email}, headers={"X-API-Key": key}, timeout=15)
            msgs = (r.json().get("data") or {}).get("messages") or []
            for msg in msgs:
                mid = msg.get("id")
                full = requests.get(f"{YYDS_BASE}/messages/{mid}", params={"address": email}, headers={"X-API-Key": key}, timeout=15).text
                codes = re.findall(r'\b(\d{6})\b', full)
                if codes:
                    print(f"  [YYDS] Code: {codes[-1]}")
                    return codes[-1]
        except Exception as e:
            print(f"  [YYDS] Error: {e}")
        if idx % 3 == 0:
            print(f"  [YYDS] Waiting... ({idx * interval}s)")
    return None


# ── Gap Detection ────────────────────────────────────────────────────

def find_gap_in_crop(bg_img):
    gray = cv2.cvtColor(bg_img, cv2.COLOR_BGR2GRAY) if len(bg_img.shape) == 3 else bg_img
    h, w = gray.shape
    if w < 50 or h < 20: return None
    edges = cv2.Canny(gray, 50, 150)
    blurred = cv2.GaussianBlur(edges, (5, 5), 0)
    col_sums = np.sum(blurred, axis=0).astype(float)
    ks = min(15, w // 10)
    if ks > 2: col_sums = np.convolve(col_sums, np.ones(ks) / ks, mode='same')
    mean_s, std_s = np.mean(col_sums), np.std(col_sums)
    if std_s < 1: return None
    thresh = mean_s + 1.5 * std_s
    peaks = [i for i in range(1, len(col_sums)-1) if col_sums[i] > thresh and col_sums[i] > col_sums[i-1] and col_sums[i] > col_sums[i+1]]
    best_x, best_score = None, 0
    for i in range(len(peaks)):
        for j in range(i+1, len(peaks)):
            gw = peaks[j] - peaks[i]
            if w * 0.12 <= gw <= w * 0.22:
                score = col_sums[peaks[i]] + col_sums[peaks[j]] + 0.1 * (peaks[i]/w) * col_sums[peaks[i]]
                if score > best_score: best_score, best_x = score, (peaks[i]+peaks[j])//2
    return best_x


async def detect_drag_distance(page):
    """Use DOM to get puzzle piece position vs gap position for precise drag distance."""
    await page.screenshot(path="/tmp/vmos_captcha_current.png")
    
    info = await page.evaluate("""() => {
        const popup = document.getElementById('aliyunCaptcha-window-popup');
        if (!popup) return null;
        const bgImg = document.getElementById('aliyunCaptcha-img');
        const puzzle = document.getElementById('aliyunCaptcha-puzzle');
        const slider = document.getElementById('aliyunCaptcha-sliding-slider');
        if (!bgImg || !slider) return null;
        const bgRect = bgImg.getBoundingClientRect();
        const sliderRect = slider.getBoundingClientRect();
        let puzzleRect = null;
        if (puzzle) puzzleRect = puzzle.getBoundingClientRect();
        return {
            bgX: bgRect.x, bgY: bgRect.y, bgW: bgRect.width, bgH: bgRect.height,
            sliderX: sliderRect.x, sliderY: sliderRect.y, sliderW: sliderRect.width, sliderH: sliderRect.height,
            puzzleX: puzzleRect ? puzzleRect.x : null,
            puzzleY: puzzleRect ? puzzleRect.y : null,
            puzzleW: puzzleRect ? puzzleRect.width : null,
            puzzleH: puzzleRect ? puzzleRect.height : null,
        };
    }""")
    
    if not info:
        print("  [CV] No DOM info")
        return random.randint(140, 160)
    
    print(f"  [CV] bg=({info['bgX']:.0f},{info['bgY']:.0f}) {info['bgW']:.0f}x{info['bgH']:.0f} "
          f"slider=({info['sliderX']:.0f},{info['sliderY']:.0f}) "
          f"piece=({info.get('puzzleX')},{info.get('puzzleY')}) {info.get('puzzleW')}")
    
    # Use screenshot + edge detection as primary method
    img = cv2.imread("/tmp/vmos_captcha_current.png")
    if img is None:
        return random.randint(140, 160)
    
    h, w = img.shape[:2]
    
    # Crop the background image area
    x1 = max(0, int(info['bgX']))
    y1 = max(0, int(info['bgY']))
    x2 = min(w, int(info['bgX'] + info['bgW']))
    y2 = min(h, int(info['bgY'] + info['bgH']))
    bg_crop = img[y1:y2, x1:x2]
    
    if bg_crop.size > 0:
        gap = find_gap_in_crop(bg_crop)
        if gap is not None and 30 < gap < info['bgW'] - 30:
            # Convert to screen coordinates
            # The drag distance = gap position relative to the slider start
            # In Aliyun CAPTCHA: slider starts at the left edge of the track
            # The track is typically the same width as the background image
            # So drag = gap_in_crop * (internal_width / display_width)
            # But since we're using screen coordinates, we need:
            # drag = (bg_x + gap) - slider_x
            drag = int(gap + (info['bgX'] - info['sliderX']))
            drag = max(30, min(260, drag))
            print(f"  [CV] Gap at {gap}px in crop, drag={drag}px")
            return drag
    
    return random.randint(140, 160)


# ── Drag with Touch Events ───────────────────────────────────────────

async def drag_slider_touch(page, start_x, start_y, distance):
    """Drag slider using touch events for more mobile-like interaction.
    
    Aliyun's anti-bot may treat touch events differently and potentially
    with less scrutiny than mouse events.
    """
    await asyncio.sleep(random.uniform(0.2, 0.5))
    
    end_x = start_x + distance
    end_y = start_y + random.uniform(-2, 2)
    
    # Generate Bézier control points
    ctrl1_x = start_x + distance * random.uniform(0.3, 0.5)
    ctrl1_y = start_y + random.uniform(-8, 8)
    ctrl2_x = start_x + distance * random.uniform(0.6, 0.8)
    ctrl2_y = start_y + random.uniform(-6, 6)
    
    total_steps = random.randint(55, 75)
    micro_pauses = set(random.sample(range(15, total_steps - 10), random.randint(2, 4)))
    
    # Touch start
    await page.evaluate(f"""() => {{
        const el = document.elementFromPoint({start_x}, {start_y});
        if (!el) return;
        const touch = new Touch({{
            identifier: 1,
            target: el,
            clientX: {start_x},
            clientY: {start_y},
            pageX: {start_x},
            pageY: {start_y},
            screenX: {start_x},
            screenY: {start_y},
            radiusX: 5, radiusY: 5,
            force: 1
        }});
        el.dispatchEvent(new TouchEvent('touchstart', {{
            touches: [touch],
            targetTouches: [touch],
            changedTouches: [touch],
            bubbles: true, cancelable: true
        }}));
    }}""")
    await asyncio.sleep(random.uniform(0.05, 0.12))
    
    prev_x = start_x
    for step in range(total_steps):
        t = step / total_steps
        
        # Easing
        if t < 0.1:
            progress = t * t / 0.1
        elif t < 0.35:
            progress = 0.1 + (t - 0.1) * 1.4
        elif t < 0.7:
            progress = 0.1 + 0.25 * 1.4 + (t - 0.35) * 0.85
        elif t < 0.92:
            remaining = 1.0 - t
            progress = 1.0 - remaining * remaining * 0.6
        else:
            progress = 0.95 + (t - 0.92) * 0.05 / 0.08 * 0.5
        progress = min(1.0, max(0.0, progress))
        
        x = ((1-progress)**3 * start_x + 3*(1-progress)**2 * progress * ctrl1_x +
             3*(1-progress) * progress**2 * ctrl2_x + progress**3 * end_x)
        y = ((1-progress)**3 * start_y + 3*(1-progress)**2 * progress * ctrl1_y +
             3*(1-progress) * progress**2 * ctrl2_y + progress**3 * end_y)
        
        x += random.gauss(0, 0.6)
        y += random.gauss(0, 1.0)
        x = max(prev_x + 0.3, x) if progress > 0.15 else x  # prevent backward movement
        
        await page.evaluate(f"""() => {{
            const el = document.elementFromPoint({x}, {y});
            if (!el) return;
            const touch = new Touch({{
                identifier: 1,
                target: el,
                clientX: {x},
                clientY: {y},
                pageX: {x},
                pageY: {y},
                screenX: {x},
                screenY: {y},
                radiusX: 5, radiusY: 5,
                force: 1
            }});
            el.dispatchEvent(new TouchEvent('touchmove', {{
                touches: [touch],
                targetTouches: [touch],
                changedTouches: [touch],
                bubbles: true, cancelable: true
            }}));
        }}""")
        
        delay = 0.02
        if progress < 0.1: delay = 0.03
        elif progress > 0.85: delay = 0.025
        await asyncio.sleep(delay + random.uniform(-0.003, 0.005))
        
        if step in micro_pauses:
            await asyncio.sleep(random.uniform(0.06, 0.14))
        
        prev_x = x
    
    # Overshoot + correction
    overshoot = random.uniform(3, 8)
    await page.evaluate(f"""() => {{
        const el = document.elementFromPoint({end_x + overshoot}, {end_y});
        if (!el) return;
        const touch = new Touch({{
            identifier: 1, target: el,
            clientX: {end_x + overshoot}, clientY: {end_y},
            pageX: {end_x + overshoot}, pageY: {end_y},
            screenX: {end_x + overshoot}, screenY: {end_y},
            radiusX: 5, radiusY: 5, force: 1
        }});
        el.dispatchEvent(new TouchEvent('touchmove', {{
            touches: [touch], targetTouches: [touch], changedTouches: [touch],
            bubbles: true, cancelable: true
        }}));
    }}""")
    await asyncio.sleep(random.uniform(0.08, 0.16))
    
    final_x = end_x + random.uniform(-1, 1)
    final_y = end_y + random.gauss(0, 0.5)
    await page.evaluate(f"""() => {{
        const el = document.elementFromPoint({final_x}, {final_y});
        if (!el) return;
        const touch = new Touch({{
            identifier: 1, target: el,
            clientX: {final_x}, clientY: {final_y},
            pageX: {final_x}, pageY: {final_y},
            screenX: {final_x}, screenY: {final_y},
            radiusX: 5, radiusY: 5, force: 1
        }});
        el.dispatchEvent(new TouchEvent('touchend', {{
            touches: [], targetTouches: [], changedTouches: [touch],
            bubbles: true, cancelable: true
        }}));
    }}""")
    
    # Also do mouse events (some CAPTCHA implementations need both)
    # Use page.mouse as fallback
    await page.mouse.move(start_x, start_y)
    await asyncio.sleep(random.uniform(0.05, 0.12))
    await page.mouse.down()
    await asyncio.sleep(random.uniform(0.05, 0.1))
    
    # Redo the drag with mouse events too, in case touch events alone don't work
    for step in range(total_steps):
        t = step / total_steps
        if t < 0.1: progress = t * t / 0.1
        elif t < 0.35: progress = 0.1 + (t - 0.1) * 1.4
        elif t < 0.7: progress = 0.1 + 0.25 * 1.4 + (t - 0.35) * 0.85
        elif t < 0.92:
            remaining = 1.0 - t; progress = 1.0 - remaining * remaining * 0.6
        else: progress = 0.95 + (t - 0.92) * 0.05 / 0.08 * 0.5
        progress = min(1.0, max(0.0, progress))
        
        x = ((1-progress)**3 * start_x + 3*(1-progress)**2 * progress * ctrl1_x +
             3*(1-progress) * progress**2 * ctrl2_x + progress**3 * end_x)
        y = ((1-progress)**3 * start_y + 3*(1-progress)**2 * progress * ctrl1_y +
             3*(1-progress) * progress**2 * ctrl2_y + progress**3 * end_y)
        x += random.gauss(0, 0.6); y += random.gauss(0, 1.0)
        x = max(prev_x + 0.3, x) if progress > 0.15 else x
        await page.mouse.move(x, y)
        delay = 0.02
        if progress < 0.1: delay = 0.03
        elif progress > 0.85: delay = 0.025
        await asyncio.sleep(delay + random.uniform(-0.003, 0.005))
        prev_x = x
    
    await page.mouse.move(end_x + overshoot, end_y + random.gauss(0, 1))
    await asyncio.sleep(random.uniform(0.08, 0.16))
    await page.mouse.move(final_x, final_y)
    await asyncio.sleep(random.uniform(0.05, 0.12))
    await page.mouse.up()


# ── Main ──────────────────────────────────────────────────────────────

async def register_one(email, password="VmosCloud2026!", captcha_retries=6):
    if HAS_CLOAKBROWSER:
        browser = await cloakbrowser_launch(headless=False, args=["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage"])
    else:
        from playwright.async_api import async_playwright
        pw = await async_playwright().start()
        browser = await pw.chromium.launch(headless=False, args=["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage", "--disable-blink-features=AutomationControlled"])
    
    context = await browser.new_context(viewport={"width": 1280, "height": 800}, locale="en",
        timezone_id="America/New_York", user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36")
    await context.add_init_script("""
        Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
        window.chrome = { runtime: {} };
        const origQuery = window.navigator.permissions.query.bind(window.navigator.permissions);
        window.navigator.permissions.query = (p) => p.name === 'notifications' ? Promise.resolve({ state: Notification.permission }) : origQuery(p);
        Object.defineProperty(navigator, 'plugins', { get: () => [1,2,3,4,5] });
        Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'] });
    """)
    page = await context.new_page()
    
    captured = {"smsSend_response": None}
    async def on_response(resp):
        if "smsSend" in resp.url:
            try:
                text = await resp.text()
                captured["smsSend_response"] = text
                result = json.loads(text)
                code = result.get("code")
                if code == 200: print(f"  [INTERCEPT] ✅ smsSend SUCCESS")
                elif code == 2019: print(f"  [INTERCEPT] ❌ smsSend FAILED (2019)")
                else: print(f"  [INTERCEPT] ⚠️ code={code}")
            except: pass
    page.on("response", on_response)
    
    try:
        print(f"\n[1] Opening VMOS Cloud...")
        await page.goto(FRONTEND_URL, wait_until="networkidle", timeout=60000)
        await asyncio.sleep(random.uniform(1.5, 3.0))
        
        try: await page.click('[class*="agreement"]', timeout=2000)
        except: pass
        await asyncio.sleep(0.3)
        
        print(f"[2] Filling email: {email}")
        for sel in EMAIL_SELECTORS:
            try:
                await page.click(sel, timeout=3000); await asyncio.sleep(0.2)
                await page.fill(sel, "", timeout=1000)
                for c in email: await page.type(sel, c, delay=random.randint(30, 80))
                break
            except: continue
        await asyncio.sleep(random.uniform(0.5, 1.0))
        
        for sel in LOGIN_BTN_SELECTORS:
            try: await page.click(sel, timeout=3000); break
            except: continue
        
        # Wait for CAPTCHA
        deadline = time.time() + 15
        while time.time() < deadline:
            state = await page.evaluate("""() => {
                const popup = document.getElementById('aliyunCaptcha-window-popup');
                const slider = document.getElementById('aliyunCaptcha-sliding-slider');
                return { hasPopup: !!popup, hasSlider: !!slider, 
                         visible: popup ? (popup.style.display !== 'none' && popup.offsetHeight > 0) : false,
                         classList: popup ? popup.className : null };
            }""")
            if state.get("hasSlider"):
                print("  CAPTCHA slider detected")
                break
            await asyncio.sleep(0.5)
        
        # Solve CAPTCHA
        for attempt in range(1, captcha_retries + 1):
            print(f"\n[CAPTCHA] Attempt {attempt}/{captcha_retries}")
            await asyncio.sleep(random.uniform(1.5, 2.5))
            
            drag = await detect_drag_distance(page)
            if drag < 90:
                old = drag; drag = random.randint(140, 160)
                print(f"  [CAPTCHA] Distance {old}px too low; fallback: {drag}px")
            
            slider = await page.query_selector('#aliyunCaptcha-sliding-slider')
            if not slider:
                # Check if CAPTCHA is gone (passed)
                state = await page.evaluate("""() => {
                    const popup = document.getElementById('aliyunCaptcha-window-popup');
                    if (!popup) return {gone: true};
                    return {gone: popup.style.display === 'none' || popup.className.includes('window-hide')};
                }""")
                if state.get("gone"):
                    print("  ✅ CAPTCHA passed (popup gone)!")
                    break
                print("  No slider found")
                return None
            
            box = await slider.bounding_box()
            if not box: return None
            sx, sy = box["x"] + box["width"] / 2, box["y"] + box["height"] / 2
            actual_drag = max(30, drag + random.randint(-2, 2))
            print(f"  Slider ({sx:.0f},{sy:.0f}), dragging {actual_drag}px")
            
            await drag_slider_touch(page, sx, sy, actual_drag)
            await asyncio.sleep(4 + random.uniform(0.5, 1.5))
            
            # Check CAPTCHA state
            state = await page.evaluate("""() => {
                const popup = document.getElementById('aliyunCaptcha-window-popup');
                if (!popup) return {gone: true, msg: null};
                const hidden = popup.style.display === 'none' || popup.className.includes('window-hide') || popup.offsetHeight === 0;
                // Check for success indicator
                const successEl = popup.querySelector('[class*="success"]') || popup.querySelector('[class*="valid"]');
                const failEl = popup.querySelector('[class*="fail"]') || popup.querySelector('[class*="err"]');
                return { gone: hidden, success: !!successEl, fail: !!failEl,
                         class: popup.className, text: popup.textContent.substring(0, 100) };
            }""")
            
            print(f"  State: {state}")
            
            if state.get("gone") or state.get("success"):
                print(f"  ✅ CAPTCHA passed (attempt {attempt})!")
                break
            elif state.get("fail"):
                print(f"  ❌ CAPTCHA failed, refreshing...")
            else:
                print(f"  ❌ CAPTCHA still visible")
            
            # Refresh
            try:
                refresh = await page.query_selector('#aliyunCaptcha-btn-refresh')
                if refresh:
                    await asyncio.sleep(random.uniform(1.0, 2.0))
                    await refresh.click()
                    await asyncio.sleep(random.uniform(2.0, 3.5))
            except: pass
        
        await asyncio.sleep(3)
        
        # Check smsSend
        print(f"\n[4] Checking smsSend result...")
        if captured["smsSend_response"]:
            result = json.loads(captured["smsSend_response"])
            code = result.get("code")
            if code == 200: print(f"  ✅ Code sent!")
            elif code == 2019: print(f"  ❌ Signature verification failed")
            else: print(f"  ⚠️ code={code}")
        else: print(f"  No smsSend intercepted")
        
        # Poll for code
        print(f"\n[5] Polling YYDS for code...")
        verify_code = poll_yyds_code(email, timeout_s=180)
        if not verify_code:
            print("  ❌ No code received")
            return None
        print(f"  ✅ Got code: {verify_code}")
        
        # Login
        print(f"\n[6] Logging in...")
        resp = requests.post(f"{API_BASE}/api/user/login", headers=vmos_headers(), json={
            "mobilePhone": email, "loginType": 0, "verifyCode": verify_code,
            "password": md5_password(password), "channel": ""}, timeout=30)
        result = resp.json()
        if result.get("code") == 200:
            data = result.get("data", {})
            ACCOUNTS_DIR.mkdir(parents=True, exist_ok=True)
            account = {"email": email, "password": password, "password_md5": md5_password(password),
                       "token": data.get("token"), "userId": data.get("userId"),
                       "isRegister": data.get("isRegister"), "platform": "vmos_cloud", "created_at": int(time.time())}
            out = ACCOUNTS_DIR / f"{email}.json"
            out.write_text(json.dumps(account, ensure_ascii=False, indent=2))
            print(f"\n{'='*50}\n  ✅ {'REGISTERED' if data.get('isRegister') else 'LOGGED IN'}!\n  Email: {email}\n  Password: {password}\n  User ID: {data.get('userId')}\n{'='*50}")
            return account
        else:
            print(f"  ❌ Login failed: {result}")
            return None
    finally:
        await browser.close()

async def main():
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--email", default=None)
    p.add_argument("--password", default="VmosCloud2026!")
    p.add_argument("--domain", default="a0.engineer")
    p.add_argument("--captcha-retries", type=int, default=6)
    p.add_argument("--count", type=int, default=1)
    p.add_argument("--retries", type=int, default=2)
    args = p.parse_args()
    
    results = []
    for i in range(args.count):
        email = args.email
        if not email:
            print(f"\n[0] Creating email...")
            try: email, _, _ = create_email_yyds(args.domain); print(f"  Email: {email}")
            except Exception as e: print(f"  ❌ {e}"); continue
        for attempt in range(1, args.retries + 1):
            print(f"\n{'='*60}\n  Account {i+1}/{args.count}, attempt {attempt}/{args.retries}\n{'='*60}")
            result = await register_one(email, args.password, args.captcha_retries)
            if result: results.append(result); break
            if attempt < args.retries:
                w = random.uniform(5, 10); print(f"  Retrying in {w:.0f}s..."); await asyncio.sleep(w)
    
    print(f"\n{'='*60}\n  Results: {len(results)}/{args.count}\n{'='*60}")

if __name__ == "__main__":
    asyncio.run(main())
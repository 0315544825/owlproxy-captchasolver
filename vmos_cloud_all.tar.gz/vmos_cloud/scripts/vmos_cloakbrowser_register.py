#!/usr/bin/env python3
"""VMOS Cloud registration using CloakBrowser (anti-detection browser).
Based on OwlProxy's approach - CloakBrowser bypasses Aliyun CAPTCHA fingerprint detection.
"""

import asyncio
import hashlib
import json
import math
import random
import re
import time

import requests
from cloakbrowser import launch_async

YYDS_KEY = "AC-29e9b09c5ae93e1347debb66"
API_BASE = "https://api.vmoscloud.com/vcpcloud"

EMAIL_SELECTORS = [
    'input[placeholder*="邮箱"]',
    'input[placeholder*="Email"]',
    'input[placeholder*="email"]',
    'input[type="email"]',
]
LOGIN_SELECTORS = [
    'button:has-text("Login")',
    'button:has-text("Register")',
    'button:has-text("登录")',
    'button:has-text("注册")',
]


async def register_one(email: str, password: str = "VmosCloud2026!"):
    # Create YYDS email
    print(f"\n[0] Using email: {email}")
    
    browser = await launch_async(
        headless=False,
        args=["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage"]
    )
    context = await browser.new_context(
        viewport={"width": 1280, "height": 800},
        locale="en",
        timezone_id="America/New_York",
    )
    page = await context.new_page()

    # Capture network requests
    captured = {"smsSend_body": None, "smsSend_response": None}

    async def on_request(req):
        if "smsSend" in req.url:
            try:
                body = req.post_data
                if body:
                    parsed = json.loads(body) if isinstance(body, str) else body
                    captured["smsSend_body"] = parsed
            except:
                pass

    async def on_response(resp):
        if "smsSend" in resp.url:
            try:
                captured["smsSend_response"] = await resp.text()
            except:
                pass

    page.on("request", on_request)
    page.on("response", on_response)

    try:
        # Navigate
        print("[1] Opening VMOS Cloud...")
        await page.goto("https://cloud.vmoscloud.com/", wait_until="networkidle", timeout=60000)
        await asyncio.sleep(2)

        # Agree & fill email
        try:
            await page.click('[class*="agreement"]', timeout=2000)
        except:
            pass
        await asyncio.sleep(0.3)

        print(f"[2] Filling email: {email}")
        filled = False
        for sel in EMAIL_SELECTORS:
            try:
                await page.fill(sel, email, timeout=3000)
                filled = True
                break
            except:
                continue
        if not filled:
            print("  Could not fill email!")
            await browser.close()
            return None
        await asyncio.sleep(0.5)

        # Click Login/Register
        print("[3] Clicking Login/Register...")
        clicked = False
        for sel in LOGIN_SELECTORS:
            try:
                await page.click(sel, timeout=3000)
                clicked = True
                break
            except:
                continue
        if not clicked:
            print("  Could not click login!")
            await browser.close()
            return None
        await asyncio.sleep(3)

        # Solve CAPTCHA
        print("[4] Solving CAPTCHA with CloakBrowser...")
        for attempt, drag_dist in enumerate([149, 160, 140, 170, 130, 155, 145, 125, 180, 120], 1):
            slider = await page.query_selector('#aliyunCaptcha-sliding-slider') or await page.query_selector('.slider-move')
            if not slider:
                print("  No slider found - CAPTCHA may have auto-passed or not loaded")
                break

            box = await slider.bounding_box()
            if not box:
                print("  Slider has no bounding box")
                break

            sx, sy = box["x"] + box["width"] / 2, box["y"] + box["height"] / 2
            print(f"  Attempt {attempt}: drag {drag_dist}px")

            await page.mouse.move(sx, sy)
            await asyncio.sleep(0.3 + random.random() * 0.2)
            await page.mouse.down()
            await asyncio.sleep(0.1)

            # OwlProxy-style easeOutQuad with 0.85 clamp
            for i in range(1, 51):
                t = i / 50
                progress = 1 - (1 - t) ** 2.5
                if progress > 0.85:
                    progress = 0.85 + (progress - 0.85) * 0.3
                x = sx + drag_dist * progress
                y = sy + random.gauss(0, 1.5)
                await page.mouse.move(x, y)
                await asyncio.sleep(0.05)

            await page.mouse.up()
            await asyncio.sleep(5)

            # Check CAPTCHA
            captcha_visible = await page.evaluate("""() => {
                const el = document.getElementById('aliyunCaptcha-window-popup');
                if (!el) return false;
                return el.style.display !== 'none' && el.offsetHeight > 0;
            }""")

            if not captcha_visible:
                print(f"  CAPTCHA PASSED (attempt {attempt})!")
                break
            else:
                print(f"  Still visible, refreshing...")
                try:
                    ref = await page.query_selector('#aliyunCaptcha-btn-refresh')
                    if ref:
                        await ref.click()
                        await asyncio.sleep(2)
                except:
                    pass

        # Check smsSend result
        await asyncio.sleep(2)
        print(f"\n[5] Checking smsSend result...")
        if captured["smsSend_response"]:
            print(f"  Response: {captured['smsSend_response'][:200]}")
            resp_data = json.loads(captured["smsSend_response"])
            if resp_data.get("code") == 2019:
                print("  ❌ Signature verification FAILED - CAPTCHA not truly passed")
            elif resp_data.get("code") == 200:
                print("  ✅ smsSend SUCCESS!")
            else:
                print(f"  ⚠️ Unexpected code: {resp_data.get('code')}")
        else:
            print("  No smsSend request captured")

        # Extract captchaVerifyParam from storage (OwlProxy method)
        print("\n[6] Extracting captchaVerifyParam...")
        captcha_param = await page.evaluate("""() => {
            const candidates = [];
            for (const store of [localStorage, sessionStorage]) {
                for (let i = 0; i < store.length; i++) {
                    const key = store.key(i);
                    const val = store.getItem(key);
                    if (!val || typeof val !== 'string') continue;
                    candidates.push({key, val, len: val.length, store: store === localStorage ? 'local' : 'session'});
                }
            }
            candidates.sort((a,b) => b.len - a.len);
            for (const item of candidates) {
                const v = item.val;
                if (v.length > 10000) return {value: v, len: v.length, source: item.store + ':' + item.key};
                if (v.length > 1000 && v.includes('sceneId') && v.includes('certifyId')) return {value: v, len: v.length, source: item.store + ':' + item.key};
                if (v.length > 500 && v.includes('hash') && v.includes('nums')) return {value: v, len: v.length, source: item.store + ':' + item.key};
            }
            if (typeof window.captchaVerifyParam === 'string') return {value: window.captchaVerifyParam, len: window.captchaVerifyParam.length, source: 'window.captchaVerifyParam'};
            return {value: null, keys: candidates.slice(0, 10).map(c => ({key: c.key, len: c.len}))};
        }""")
        
        if isinstance(captcha_param, dict) and captcha_param.get("value"):
            token = captcha_param["value"]
            print(f"  Found: {captcha_param['source']} ({captcha_param['len']} chars)")
        else:
            print(f"  No captchaVerifyParam in storage")
            if isinstance(captcha_param, dict) and "keys" in captcha_param:
                print(f"  Top keys: {json.dumps(captcha_param['keys'], indent=2)}")

        # If browser smsSend failed, try direct API call with captured token
        if captured["smsSend_body"] and captured["smsSend_body"].get("captchaVerifyParam"):
            cvp = captured["smsSend_body"]["captchaVerifyParam"]
            print(f"\n[7] Trying direct smsSend API call...")
            headers = {"Content-Type": "application/json", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
            payload = {"smsType": 2, "mobilePhone": email, "captchaVerifyParam": cvp}
            resp = requests.post(f"{API_BASE}/api/sms/smsSend", json=payload, headers=headers, timeout=30)
            print(f"  Status: {resp.status_code}")
            print(f"  Response: {resp.text[:200]}")

        # Poll YYDS for verification code
        print(f"\n[8] Polling YYDS for verification code...")
        verify_code = None
        for i in range(30):
            time.sleep(10)
            try:
                r = requests.get(f"https://maliapi.215.im/v1/messages?address={email}",
                               headers={"X-API-Key": YYDS_KEY}, timeout=15)
                msgs = (r.json().get("data") or {}).get("messages") or []
                if msgs:
                    for msg in msgs:
                        mid = msg.get("id")
                        full = requests.get(f"https://maliapi.215.im/v1/messages/{mid}?address={email}",
                                           headers={"X-API-Key": YYDS_KEY}, timeout=15).text
                        codes = re.findall(r'\b(\d{6})\b', full)
                        if codes:
                            verify_code = codes[-1]
                            print(f"  ✅ CODE: {verify_code}")
                            break
            except Exception as e:
                print(f"  Error: {e}")
            if verify_code:
                break
            if i % 3 == 0:
                print(f"  Waiting... ({(i+1)*10}s)")

        if verify_code:
            # Login via API
            print(f"\n[9] Logging in with code {verify_code}...")
            login_headers = {
                "Content-Type": "application/json",
                "Accept-Language": "en",
                "clientType": "web",
                "appVersion": "3.6.1800",
                "requestsource": "wechat-miniapp",
                "SupplierType": "0",
                "X-Tenant": "vmoscloud",
            }
            login_resp = requests.post(f"{API_BASE}/api/user/login", headers=login_headers, json={
                "mobilePhone": email,
                "loginType": 0,
                "verifyCode": verify_code,
                "password": hashlib.md5(password.encode()).hexdigest(),
                "channel": ""
            }, timeout=30)
            result = login_resp.json()
            print(json.dumps(result, indent=2, ensure_ascii=False)[:500])

            if result.get("code") == 200:
                data = result.get("data", {})
                print(f"\n{'='*50}")
                print(f"  ✅ REGISTERED/LOGGED IN!")
                print(f"  Email:    {email}")
                print(f"  Password: {password}")
                print(f"  User ID:  {data.get('userId')}")
                tok = data.get("token", "")
                print(f"  Token:    {tok[:30]}..." if tok else "  Token:    N/A")
                print(f"  isRegister: {data.get('isRegister')}")
                print(f"{'='*50}")

                # Save account
                import os
                account = {
                    "email": email, "password": password,
                    "password_md5": hashlib.md5(password.encode()).hexdigest(),
                    "token": data.get("token"), "userId": data.get("userId"),
                    "isRegister": data.get("isRegister"), "platform": "vmos_cloud",
                    "created_at": str(int(time.time())),
                }
                os.makedirs("accounts", exist_ok=True)
                with open(f"accounts/{email}.json", "w") as f:
                    json.dump(account, f, ensure_ascii=False, indent=2)
                print(f"  Saved to accounts/{email}.json")
                return account
            else:
                print(f"  Login failed: {result}")
        else:
            print("  ❌ No verification code received")

        await page.screenshot(path="/tmp/vmos_cloakbrowser.png")
    finally:
        await browser.close()

    return None


if __name__ == "__main__":
    # Create YYDS email
    EMAIL = f"vmos{int(time.time())}{random.randint(10,99)}@a0.engineer"
    PASSWORD = "VmosCloud2026!"
    
    print(f"Creating YYDS email: {EMAIL}")
    resp = requests.post("https://maliapi.215.im/v1/accounts",
        headers={"X-API-Key": YYDS_KEY, "Content-Type": "application/json"},
        json={"localPart": EMAIL.split("@")[0], "domain": "a0.engineer"},
        timeout=15)
    result = resp.json()
    if result.get("success"):
        EMAIL = result["data"]["address"]
        print(f"  Email: {EMAIL}")
    else:
        print(f"  Failed: {result}")

    asyncio.run(register_one(EMAIL, PASSWORD))
#!/usr/bin/env python3
"""VMOS Cloud Auto-Registration with YYDS temp email.

Adapted from owlproxy_auto_register.py for VMOS Cloud (api.vmoscloud.com).

Flow:
1. Create YYDS temp email
2. Open VMOS Cloud in browser → fill email → trigger CAPTCHA
3. Auto-solve Aliyun slider CAPTCHA
4. Intercept captchaVerifyParam
5. POST /api/sms/smsSend to send verification code
6. Poll YYDS for verification code
7. POST /api/user/login with verifyCode to register
8. Save account + token

Usage:
    xvfb-run --auto-servernum --server-args='-screen 0 1280x800x24' \
        python3 scripts/vmos_cloud_auto_register.py --email you@example.com

    # Or let YYDS create temp email automatically:
    xvfb-run --auto-servernum --server-args='-screen 0 1280x800x24' \
        python3 scripts/vmos_cloud_auto_register.py

    # Batch:
    xvfb-run --auto-servernum --server-args='-screen 0 1280x800x24' \
        python3 scripts/vmos_cloud_auto_register.py --count 3
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
import random
import re
import secrets
import string
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import requests

try:
    from cloakbrowser import launch_async
except ImportError:
    from playwright.async_api import async_playwright

    async def launch_async(**kwargs):
        pw = await async_playwright().start()
        browser = await pw.chromium.launch(**kwargs)
        browser._pw = pw
        return browser

# ── Config ──────────────────────────────────────────────────────────
API_BASE = "https://api.vmoscloud.com/vcpcloud"
FRONTEND_URL = "https://cloud.vmoscloud.com"
ACCOUNTS_DIR = Path("/home/node/.openclaw/workspace/vmos_cloud/accounts")
YYDS_BASE = "https://maliapi.215.im/v1"

DEFAULT_PASSWORD = "VmosCloud123!"

# Aliyun CAPTCHA config (identical to OwlProxy)
CAPTCHA_SCENE_ID = "5jvar3wp"
CAPTCHA_PREFIX = "69r0rc"
CAPTCHA_REGION = "sgp"

# ── Selectors ────────────────────────────────────────────────────────
# VMOS Cloud uses English UI by default; include Chinese as fallback
EMAIL_SELECTORS = [
    'input[placeholder*="email"]',
    'input[placeholder*="Email"]',
    'input[placeholder*="邮箱"]',
    'input[placeholder*="请输入"]',
    'input[type="email"]',
]
CODE_INPUT_SELECTORS = [
    'input[type="number"]',
    'input[placeholder*="code"]',
    'input[placeholder*="Code"]',
    'input[placeholder*="验证码"]',
]
PASSWORD_SELECTORS = [
    'input[placeholder*="密码"]',
    'input[placeholder*="Password"]',
    'input[type="password"]',
]
LOGIN_BTN_SELECTORS = [
    'button:has-text("Login")',
    'button:has-text("Register")',
    'button:has-text("登录")',
    'button:has-text("注册")',
    'button:has-text("Login/Register")',
]


# ── Helpers ──────────────────────────────────────────────────────────

def md5_password(password: str) -> str:
    return hashlib.md5(password.encode()).hexdigest()


def make_password() -> str:
    alphabet = string.ascii_letters + string.digits
    core = "".join(secrets.choice(alphabet) for _ in range(14))
    return f"Vc{core}!9"


def vmos_headers(token: str | None = None, user_id: str | None = None) -> dict[str, str]:
    h = {
        "Content-Type": "application/json",
        "Accept-Language": "en",
        "clientType": "web",
        "appVersion": "3.6.1800",
        "requestsource": "wechat-miniapp",
        "SupplierType": "0",
        "X-Tenant": "vmoscloud",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    }
    if token:
        h["Token"] = token
    if user_id:
        h["userId"] = user_id
    return h


# ── YYDS Email ───────────────────────────────────────────────────────

def load_yyds_key() -> str:
    for name in ("YYDS_KEY", "MALI_API_KEY"):
        val = os.getenv(name)
        if val:
            return val.strip()
    raise RuntimeError("YYDS key not found. Set YYDS_KEY or MALI_API_KEY in environment.")


def yyds_headers() -> dict[str, str]:
    return {"X-API-Key": load_yyds_key()}


def yyds_json(method: str, path: str, **kwargs) -> dict[str, Any]:
    headers = {**yyds_headers(), **kwargs.pop("headers", {})}
    resp = requests.request(method, f"{YYDS_BASE}{path}", headers=headers, timeout=30, **kwargs)
    resp.raise_for_status()
    return resp.json()


def create_email_yyds(domain: str | None = None) -> tuple[str, str, str]:
    if not domain:
        d = yyds_json("GET", "/domains")
        if not d.get("success"):
            raise RuntimeError(f"YYDS domains failed: {d}")
        domains: list[str] = []
        for x in d.get("data", []):
            recs = x.get("dnsRecords", {}) or {}
            if (
                x.get("isPublic")
                and x.get("isVerified")
                and x.get("isMxValid")
                and recs.get("receivingReady")
                and recs.get("status") == "healthy"
            ):
                domains.append(x["domain"])
        if not domains:
            domains = ["dysu.ccwu.cc", "chen-hai.sryze.cc"]
        domain = random.choice(domains)

    local = f"vmos{int(time.time())}{random.randint(10, 99)}"
    d = yyds_json(
        "POST",
        "/accounts",
        headers={"Content-Type": "application/json"},
        json={"localPart": local, "domain": domain},
    )
    if not d.get("success"):
        raise RuntimeError(f"YYDS create failed: {d}")
    return d["data"]["address"], local, domain


def poll_yyds_code(email: str, timeout_s: int = 180, interval: int = 5) -> str | None:
    deadline = time.time() + timeout_s
    idx = 0
    while time.time() < deadline:
        idx += 1
        time.sleep(interval)
        try:
            lst = yyds_json("GET", "/messages", params={"address": email})
        except Exception as e:
            print(f"  [YYDS poll {idx}] API error: {e}")
            continue

        total = (lst.get("data") or {}).get("total", 0)
        if total <= 0:
            print(f"  [YYDS poll {idx}] no code yet...")
            continue

        messages = (lst.get("data") or {}).get("messages") or []
        for msg in messages[:3]:
            mid = msg.get("id")
            if not mid:
                continue
            try:
                full = yyds_json("GET", f"/messages/{mid}", params={"address": email})
            except Exception as e:
                print(f"  [YYDS poll {idx}] Failed to fetch message: {e}")
                continue

            def walk(x):
                if isinstance(x, dict):
                    for v in x.values():
                        yield from walk(v)
                elif isinstance(x, list):
                    for v in x:
                        yield from walk(v)
                elif isinstance(x, str):
                    yield x

            txt = " ".join(walk(full))
            codes = re.findall(r"\b(\d{6})\b", txt)
            if codes:
                print(f"  [YYDS] Found code: {codes[0]}")
                return codes[0]
    return None


# ── VMOS Cloud API ───────────────────────────────────────────────────

def check_email(email: str) -> dict[str, Any]:
    """Check if email is already registered."""
    url = f"{API_BASE}/api/user/checkEmail"
    params = {"mobilePhone": email}
    headers = vmos_headers()
    print(f"[API] GET {url}?mobilePhone={email}")
    resp = requests.get(url, params=params, headers=headers, timeout=30)
    print(f"[API] Status: {resp.status_code}")
    print(f"[API] Response: {resp.text[:500]}")
    return resp.json()


def send_sms(email: str, captcha_token: str) -> dict[str, Any]:
    """Send verification code to email."""
    url = f"{API_BASE}/api/sms/smsSend"
    payload = {
        "smsType": 2,
        "mobilePhone": email,
        "captchaVerifyParam": captcha_token,
    }
    # Use minimal headers for smsSend — extra headers can break Aliyun signature
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    }
    print(f"[API] POST {url}")
    print(f"[API] Body: mobilePhone={email}, smsType=2, captchaVerifyParam=({len(captcha_token)} chars)")
    resp = requests.post(url, json=payload, headers=headers, timeout=30)
    print(f"[API] Status: {resp.status_code}")
    print(f"[API] Response: {resp.text[:500]}")
    return resp.json()


def login_register(email: str, password: str, verify_code: str, *, channel: str = "") -> dict[str, Any]:
    """Login or register with verification code."""
    url = f"{API_BASE}/api/user/login"
    payload = {
        "mobilePhone": email,
        "loginType": 0,
        "verifyCode": verify_code,
        "password": md5_password(password),
        "channel": channel,
    }
    headers = vmos_headers()
    print(f"[API] POST {url}")
    print(f"[API] Body: {json.dumps({k: v for k, v in payload.items() if k != 'password'}, indent=2)}")
    resp = requests.post(url, json=payload, headers=headers, timeout=30)
    print(f"[API] Status: {resp.status_code}")
    print(f"[API] Response: {resp.text[:500]}")
    return resp.json()


def get_user_info(token: str) -> dict[str, Any]:
    """Get user info with token."""
    url = f"{API_BASE}/api/user/getUserInfo"
    headers = vmos_headers(token=token)
    resp = requests.get(url, headers=headers, timeout=30)
    return resp.json()


# ── Browser Automation ───────────────────────────────────────────────

async def click_first(page, selectors: list[str], timeout: float = 3) -> bool:
    for selector in selectors:
        try:
            await page.click(selector, timeout=int(timeout * 1000))
            return True
        except Exception:
            continue
    return False


async def fill_first(page, selectors: list[str], value: str, timeout: float = 3) -> bool:
    for selector in selectors:
        try:
            await page.fill(selector, value, timeout=int(timeout * 1000))
            return True
        except Exception:
            continue
    return False


async def solve_captcha(page, attempt: int = 1) -> bool:
    """Auto-solve the Aliyun slider CAPTCHA using image analysis."""
    print(f"[CAPTCHA] Capturing... attempt={attempt}")
    await asyncio.sleep(2)
    shot = f"/tmp/vmos_captcha_{attempt}.png"
    crop_path = f"/tmp/vmos_captcha_crop_{attempt}.png"
    await page.screenshot(path=shot)

    gap_x = 85
    try:
        full_img = cv2.imread(shot)
        if full_img is not None:
            h, w = full_img.shape[:2]
            cx, cy = w // 2, h // 2
            crop = full_img[cy - 120 : cy + 80, cx - 180 : cx + 180]
            cv2.imwrite(crop_path, crop)
            gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
            ch, cw = gray.shape
            _, white = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY)
            best_x, best_score = 85, 0
            for x in range(20, cw // 2 - 20):
                region = white[:, x - 10 : x + 10]
                if region.size > 0:
                    score = int(np.sum(region))
                    if score > best_score:
                        best_score = score
                        best_x = x
            gap_x = best_x
            print(f"[CAPTCHA] Gap detected at x={gap_x}")
    except Exception as e:
        print(f"[WARN] Gap detection error: {e}")

    slider = await page.query_selector('[class*="slider"]')
    if not slider:
        # Try alternative selectors
        for sel in ['[id*="captcha"] [class*="slide"]', '[class*="nc_iconfont"]', '[class*="btn_slide"]']:
            slider = await page.query_selector(sel)
            if slider:
                break
    if not slider:
        print("[ERROR] No slider element found")
        return False

    box = await slider.bounding_box()
    if not box:
        print("[ERROR] Slider has no bounding box")
        return False
    start_x = box["x"] + box["width"] / 2
    start_y = box["y"] + box["height"] / 2

    print(f"[CAPTCHA] Dragging {gap_x}px with human-like easing...")
    await page.mouse.move(start_x, start_y)
    await page.mouse.down()

    # Human-like drag with easeOutQuart curve + jitter
    steps = 50
    for i in range(steps):
        t = i / steps
        # easeOutQuart: fast start, slow end
        progress = 1 - (1 - t) ** 4
        if progress > 0.85:
            progress = 0.85 + (progress - 0.85) * 0.3
        x = int(gap_x * progress)
        y = int(np.random.normal(0, 1.5))
        await page.mouse.move(start_x + x, start_y + y)
        await asyncio.sleep(0.04 + random.random() * 0.03)

    # Small overshoot + correction
    await page.mouse.move(start_x + gap_x + 3, start_y + int(np.random.normal(0, 1)))
    await asyncio.sleep(0.1)
    await page.mouse.move(start_x + gap_x, start_y + int(np.random.normal(0, 1)))
    await asyncio.sleep(0.05)
    await page.mouse.up()

    await asyncio.sleep(5)

    # Check if CAPTCHA disappeared (success)
    try:
        captcha_visible = await page.locator("[class*='captcha']").is_visible()
        if not captcha_visible:
            print("[CAPTCHA] SUCCESS — slider challenge passed!")
            return True
    except Exception:
        # Element may not exist anymore = success
        print("[CAPTCHA] SUCCESS — captcha element gone")
        return True
    return False


async def get_captcha_verify_param(page) -> str | None:
    """Extract captchaVerifyParam from browser JS context or storage."""
    print("[EXTRACT] Getting captchaVerifyParam...")
    methods = [
        ("storage", """() => {
            const candidates = [];
            for (const store of [localStorage, sessionStorage]) {
                for (let i = 0; i < store.length; i++) {
                    const key = store.key(i);
                    const val = store.getItem(key);
                    if (!val || typeof val !== 'string') continue;
                    candidates.push({key, val, len: val.length});
                }
            }
            candidates.sort((a,b) => b.len - a.len);
            for (const item of candidates) {
                const v = item.val;
                if (v.length > 10000) return v;
                if (v.length > 1000 && v.includes('"hash"') && v.includes('"nums"')) return v;
            }
            return null;
        }"""),
        ("explicit-window", """() => {
            if (typeof window.captchaVerifyParam === 'string') return window.captchaVerifyParam;
            if (typeof window.__captchaVerifyParam === 'string') return window.__captchaVerifyParam;
            return null;
        }"""),
        ("window-scan", """() => {
            const candidates = [];
            for (const key of Object.keys(window)) {
                const val = window[key];
                if (typeof val === 'string') candidates.push({key, val, len: val.length});
            }
            candidates.sort((a,b) => b.len - a.len);
            for (const item of candidates) {
                const v = item.val;
                if (v.length > 10000) return v;
                if (v.length > 1000 && v.includes('"hash"') && v.includes('"nums"')) return v;
            }
            return null;
        }"""),
    ]
    for name, method in methods:
        try:
            result = await page.evaluate(method)
            if result and isinstance(result, str):
                if len(result) > 10000 or ('"hash"' in result and '"nums"' in result and len(result) > 1000):
                    print(f"[EXTRACT] {name} found param ({len(result)} chars)")
                    return result
                print(f"[EXTRACT] {name} ignored weak candidate ({len(result)} chars)")
        except Exception as e:
            print(f"[EXTRACT] {name} failed: {e}")
    return None


async def intercept_captcha_verify_param(page) -> str | None:
    """Intercept captchaVerifyParam from network requests (smsSend)."""
    captured: dict[str, Any] = {}

    async def on_request(req):
        if "smsSend" in req.url:
            try:
                post_data = req.post_data
                if post_data:
                    body = json.loads(post_data)
                    token = body.get("captchaVerifyParam", "")
                    if token and len(token) > 100:
                        captured["token"] = token
                        print(f"[INTERCEPT] Got captchaVerifyParam from smsSend ({len(token)} chars)")
            except Exception:
                pass

    page.on("request", on_request)
    # Wait up to 30s for the request
    for _ in range(60):
        if captured.get("token"):
            return captured["token"]
        await asyncio.sleep(0.5)
    return None


async def new_browser():
    """Launch browser for VMOS Cloud."""
    try:
        browser = await launch_async(
            headless=False,
            args=["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage"],
        )
    except Exception:
        from playwright.async_api import async_playwright
        pw = await async_playwright().start()
        browser = await pw.chromium.launch(
            headless=False,
            args=["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage"],
        )

    context = await browser.new_context(
        viewport={"width": 1280, "height": 800},
        locale="en",
        timezone_id="America/New_York",
    )
    page = await context.new_page()
    return browser, context, page


async def prepare_captcha_token(email: str, captcha_retries: int = 3) -> str | None:
    """Open VMOS Cloud, fill email, solve CAPTCHA, extract token."""
    browser, context, page = await new_browser()
    try:
        print("[STEP 1] Opening VMOS Cloud...")
        await page.goto(FRONTEND_URL, wait_until="networkidle", timeout=60000)
        await asyncio.sleep(2)

        # Click the email input and type email
        print(f"[STEP 1] Filling email: {email}")
        filled = False
        for sel in EMAIL_SELECTORS:
            try:
                await page.fill(sel, email, timeout=5000)
                filled = True
                print(f"[STEP 1] Email filled via {sel}")
                break
            except Exception:
                continue
        if not filled:
            # Try combobox approach
            try:
                combo = await page.query_selector('[role="combobox"] input')
                if combo:
                    await combo.fill(email)
                    filled = True
            except Exception:
                pass
        if not filled:
            raise RuntimeError("Could not fill email input")
        await asyncio.sleep(1)

        # Click Login/Register button to trigger CAPTCHA
        print("[STEP 1] Clicking Login/Register...")
        clicked = False
        for sel in LOGIN_BTN_SELECTORS:
            try:
                await page.click(sel, timeout=3000)
                clicked = True
                print(f"[STEP 1] Clicked {sel}")
                break
            except Exception:
                continue
        if not clicked:
            # Try to find and click the button by text content
            try:
                btn = await page.query_selector('button')
                if btn:
                    await btn.click()
                    clicked = True
            except Exception:
                pass
        await asyncio.sleep(3)

        # Solve CAPTCHA
        for attempt in range(1, captcha_retries + 1):
            print(f"[STEP 2] Solving CAPTCHA attempt {attempt}/{captcha_retries}...")
            if await solve_captcha(page, attempt=attempt):
                await asyncio.sleep(2)
                # Try to extract captchaVerifyParam
                token = await get_captcha_verify_param(page)
                if token:
                    print(f"[SUCCESS] Got captchaVerifyParam ({len(token)} chars)")
                    return token
                print("[WARN] CAPTCHA solved but captchaVerifyParam not found in page context")
            else:
                print(f"[WARN] CAPTCHA attempt {attempt} failed, retrying...")

        await page.screenshot(path="/tmp/vmos_captcha_failure.png")
        print("[ERROR] All CAPTCHA attempts failed")
        return None
    finally:
        await browser.close()


async def complete_registration_api(
    email: str, password: str, verify_code: str, captcha_token: str, *, channel: str = ""
) -> dict[str, Any] | None:
    """Complete registration via API (no browser needed for this step)."""
    print(f"\n[STEP 4] Registering {email}...")

    # First, send SMS with captcha token
    sms_result = send_sms(email, captcha_token)
    sms_ok = sms_result.get("code") == 200 or sms_result.get("success")

    if not sms_ok:
        print(f"[WARN] SMS send response: {sms_result}")
        # Continue anyway — the code may have already been sent during browser flow

    # Login/register with the verification code
    login_result = login_register(email, password, verify_code, channel=channel)

    if login_result.get("code") == 200:
        data = login_result.get("data", {})
        token = data.get("token", "")
        is_new = data.get("isRegister", False)
        print(f"[SUCCESS] {'Registered' if is_new else 'Logged in'} successfully!")
        print(f"[TOKEN] {token[:20]}..." if token else "[WARN] No token in response")
        return login_result
    else:
        print(f"[FAILED] Login/register failed: {login_result}")
        return None


def save_account(email: str, password: str, token: str, user_info: dict[str, Any]) -> Path:
    ACCOUNTS_DIR.mkdir(parents=True, exist_ok=True)
    account = {
        "email": email,
        "password": password,
        "password_md5": md5_password(password),
        "token": token,
        "userId": (user_info.get("data") or {}).get("userId"),
        "platform": "vmos_cloud",
        "created_at": int(time.time()),
    }
    out_file = ACCOUNTS_DIR / f"{email}.json"
    out_file.write_text(json.dumps(account, ensure_ascii=False, indent=2), encoding="utf-8")
    return out_file


async def register_one(args: argparse.Namespace, index: int = 1) -> dict[str, Any] | None:
    print("\n" + "=" * 60)
    print(f"  VMOS Cloud Auto-Registration #{index}")
    print("=" * 60)

    email = ""
    captcha_token = None
    verify_code = None

    try:
        # Step 0: Create temp email (or use provided)
        if args.email:
            email = args.email
            print(f"\n[STEP 0] Using provided email: {email}")
        else:
            print("\n[STEP 0] Creating YYDS temp email...")
            email, _local, _domain = create_email_yyds(args.domain)
            print(f"[EMAIL] {email}")

        password = args.password or (DEFAULT_PASSWORD if args.fixed_password else make_password())

        # Step 1-2: Browser CAPTCHA + extract token
        captcha_token = await prepare_captcha_token(email, args.captcha_retries)
        if not captcha_token:
            raise RuntimeError("captchaVerifyParam not extracted")

        # Step 3: Send verification code via API
        print("\n[STEP 3] Sending verification code via API...")
        sms_result = send_sms(email, captcha_token)
        sms_ok = sms_result.get("code") == 200 or sms_result.get("success")
        if sms_ok:
            print("[SUCCESS] Verification code sent!")
            is_register = sms_result.get("isRegister", sms_result.get("data", {}).get("isRegister", None))
            if is_register is not None:
                print(f"[INFO] isRegister={is_register} (server flag from smsSend)")
        else:
            # Code might already be sent from browser flow
            print(f"[WARN] SMS response: {sms_result}")

        # Step 4: Poll for verification code
        if not args.verify_code:
            print("\n[STEP 4] Polling YYDS for verification code...")
            verify_code = poll_yyds_code(email, timeout_s=args.email_timeout)
            if not verify_code:
                # Fallback: ask user
                print("[INPUT] Could not auto-retrieve code. Enter verification code:")
                verify_code = input("> ").strip()
        else:
            verify_code = args.verify_code
        print(f"[SUCCESS] Got verification code: {verify_code}")

        # Step 5: Login/Register via API
        print("\n[STEP 5] Registering...")
        login_result = login_register(email, password, verify_code, channel=args.channel or "")

        if login_result.get("code") == 200:
            data = login_result.get("data", {})
            token = data.get("token", "")
            user_id = data.get("userId", "")

            # Get full user info
            user_info = {}
            if token:
                user_info = get_user_info(token)

            out_file = save_account(email, password, token, user_info)

            print("\n" + "=" * 60)
            print("  REGISTRATION SUCCESS!")
            print("=" * 60)
            print(f"[EMAIL]    {email}")
            print(f"[PASSWORD] {password}")
            print(f"[USER_ID]  {user_id}")
            print(f"[TOKEN]    {token[:20]}... (len={len(token)})" if token else "[WARN] No token")
            print(f"[SAVED]    {out_file}")
            return {"email": email, "password": password, "token": token, "file": str(out_file)}
        else:
            print(f"[FAILED] Registration failed: {login_result}")
            return None

    except Exception as e:
        print(f"[ERROR] Registration failed for {email or '<no-email>'}: {e}")
        return None


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="VMOS Cloud auto-register with YYDS temp email")
    p.add_argument("--email", default=None, help="Email address (auto-created if omitted)")
    p.add_argument("--password", default=None, help="Explicit password")
    p.add_argument("--fixed-password", action="store_true", help=f"Use fixed password {DEFAULT_PASSWORD!r}")
    p.add_argument("--verify-code", default=None, help="Skip YYDS polling; use this code directly")
    p.add_argument("--channel", default="", help="Channel parameter (default: empty)")
    p.add_argument("--domain", default=None, help="YYDS domain override")
    p.add_argument("--count", type=int, default=1, help="Number of accounts to register")
    p.add_argument("--retries", type=int, default=2, help="Full-flow retries per account")
    p.add_argument("--captcha-retries", type=int, default=3, help="CAPTCHA solve attempts per account")
    p.add_argument("--email-timeout", type=int, default=180, help="Seconds to wait for email code")
    return p.parse_args()


async def main() -> None:
    args = parse_args()
    results: list[dict[str, Any]] = []

    for i in range(1, args.count + 1):
        ok = None
        for attempt in range(1, args.retries + 1):
            print(f"\n[BATCH] account={i}/{args.count} attempt={attempt}/{args.retries}")
            ok = await register_one(args, index=i)
            if ok:
                results.append(ok)
                break
            if attempt < args.retries:
                print("[RETRY] Waiting before next attempt...")
                await asyncio.sleep(5)
        if not ok:
            print(f"[BATCH] Failed account {i}/{args.count}")

    print("\n" + "=" * 60)
    print(f"DONE success={len(results)}/{args.count}")
    for r in results:
        print(f"  {r['email']} -> {r['file']}")


if __name__ == "__main__":
    asyncio.run(main())
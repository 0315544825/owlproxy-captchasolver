#!/usr/bin/env python3
"""VMOS Cloud human-in-the-loop CAPTCHA capture.

Opens VMOS Cloud in a visible browser, fills email, and hooks
network requests to intercept captchaVerifyParam when you manually
solve the slider CAPTCHA.

Usage:
    python3 scripts/vmos_cloud_human_captcha_capture.py --email you@example.com
"""

import argparse
import asyncio
import json
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError

API_BASE = "https://api.vmoscloud.com/vcpcloud"
FRONTEND_URL = "https://cloud.vmoscloud.com"

EMAIL_SELECTORS = [
    'input[placeholder*="email"]',
    'input[placeholder*="Email"]',
    'input[type="email"]',
]
CODE_SELECTORS = [
    'input[placeholder*="code"]',
    'input[placeholder*="Code"]',
    'input[type="number"]',
]


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--email", required=True)
    p.add_argument("--timeout", type=int, default=180, help="Seconds to wait for manual CAPTCHA")
    return p.parse_args()


async def main():
    args = parse_args()
    captured: dict[str, Any] = {"request": None, "response": None, "check_email": None}

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=False)
        context = await browser.new_context(
            viewport={"width": 1280, "height": 800},
            locale="en",
            timezone_id="America/New_York",
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36"
            ),
        )
        page = await context.new_page()

        async def on_request(req):
            url = req.url
            if "/api/sms/smsSend" in url:
                try:
                    captured["request"] = {
                        "url": url,
                        "method": req.method,
                        "headers": dict(req.headers),
                        "post_data": req.post_data,
                    }
                    print("\n✅ [smsSend request captured]")
                    if req.post_data:
                        body = json.loads(req.post_data)
                        print(f"   mobilePhone: {body.get('mobilePhone')}")
                        print(f"   smsType: {body.get('smsType')}")
                        print(f"   captchaVerifyParam: ({len(body.get('captchaVerifyParam', ''))} chars)")
                except Exception as e:
                    print(f"   request capture error: {e}")

            if "/api/user/checkEmail" in url:
                try:
                    captured["check_email"] = {
                        "url": url,
                        "method": req.method,
                    }
                    print(f"\n✅ [checkEmail request captured] {url}")
                except Exception:
                    pass

        async def on_response(resp):
            url = resp.url
            if "/api/sms/smsSend" in url:
                try:
                    body = await resp.text()
                    captured["response"] = {
                        "url": url,
                        "status": resp.status,
                        "body": body,
                    }
                    print(f"\n✅ [smsSend response captured] status={resp.status}")
                    print(f"   {body[:500]}")
                except Exception as e:
                    print(f"   response capture error: {e}")

            if "/api/user/checkEmail" in url:
                try:
                    body = await resp.text()
                    print(f"\n✅ [checkEmail response] {body[:300]}")
                except Exception:
                    pass

        page.on("request", on_request)
        page.on("response", on_response)

        print(f"\n🌐 Opening VMOS Cloud: {FRONTEND_URL}")
        await page.goto(FRONTEND_URL, wait_until="networkidle", timeout=60000)
        await asyncio.sleep(2)

        # Fill email
        print(f"\n📧 Filling email: {args.email}")
        filled = False
        for sel in EMAIL_SELECTORS:
            try:
                await page.fill(sel, args.email, timeout=5000)
                filled = True
                print(f"   Filled via {sel}")
                break
            except PlaywrightTimeoutError:
                continue
        if not filled:
            # Try combobox input
            try:
                combo = await page.query_selector('[role="combobox"] input')
                if combo:
                    await combo.fill(args.email)
                    filled = True
                    print("   Filled via combobox")
            except Exception:
                pass

        if not filled:
            print("⚠️  Could not auto-fill email. Please enter it manually in the browser.")

        # Click Login/Register button
        print("\n🔑 Clicking Login/Register...")
        for sel in [
            'button:has-text("Login/Register")',
            'button:has-text("Login")',
            'button:has-text("Register")',
        ]:
            try:
                await page.click(sel, timeout=3000)
                print(f"   Clicked {sel}")
                break
            except PlaywrightTimeoutError:
                continue

        print("\n" + "=" * 60)
        print("  👆 Please solve the CAPTCHA manually in the browser")
        print("=" * 60)

        deadline = asyncio.get_event_loop().time() + args.timeout
        while asyncio.get_event_loop().time() < deadline:
            if captured["request"] and captured["response"]:
                break
            await asyncio.sleep(0.5)

        if not captured["request"]:
            print("\n⚠️  No smsSend request captured. CAPTCHA may not have been completed.")
        else:
            post = captured["request"].get("post_data") or "{}"
            try:
                body = json.loads(post)
            except Exception:
                body = {"raw": post}

            print("\n" + "=" * 60)
            print("  📋 Extracted Data")
            print("=" * 60)
            print(json.dumps({
                "mobilePhone": body.get("mobilePhone"),
                "smsType": body.get("smsType"),
                "captchaVerifyParam_length": len(body.get("captchaVerifyParam", "")),
                "captchaVerifyParam_preview": body.get("captchaVerifyParam", "")[:200] + "..." if body.get("captchaVerifyParam") else None,
                "smsSend_status": captured["response"]["status"] if captured["response"] else None,
                "smsSend_response_preview": captured["response"]["body"][:500] if captured["response"] else None,
            }, ensure_ascii=False, indent=2))

            # Save full captchaVerifyParam to file
            token = body.get("captchaVerifyParam", "")
            if token:
                from pathlib import Path
                out = Path("/tmp/vmos_captchaVerifyParam.txt")
                out.write_text(token)
                print(f"\n💾 Full captchaVerifyParam saved to {out}")

        await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
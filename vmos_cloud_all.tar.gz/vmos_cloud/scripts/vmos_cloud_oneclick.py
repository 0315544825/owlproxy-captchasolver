#!/usr/bin/env python3
"""VMOS Cloud one-click: register → claim free cloud device → extract info.

Requires YYDS_KEY environment variable for temp email creation.

Usage:
    export YYDS_KEY="your-mali-api-key"
    xvfb-run --auto-servernum --server-args='-screen 0 1280x800x24' \
        python3 scripts/vmos_cloud_oneclick.py

    # With existing email:
    export YYDS_KEY="your-mali-api-key"
    xvfb-run --auto-servernum --server-args='-screen 0 1280x800x24' \
        python3 scripts/vmos_cloud_oneclick.py --email you@example.com --password YourPass123

    # Skip registration, use existing token:
    python3 scripts/vmos_cloud_oneclick.py --token YOUR_TOKEN
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import requests

API_BASE = "https://api.vmoscloud.com/vcpcloud"
SCRIPT_DIR = Path(__file__).resolve().parent
ACCOUNTS_DIR = Path("/home/node/.openclaw/workspace/vmos_cloud/accounts")


def vmos_headers(token: str | None = None, user_id: str | None = None) -> dict[str, str]:
    h = {
        "Content-Type": "application/json",
        "Accept-Language": "en",
        "clientType": "web",
        "appVersion": "3.6.1800",
        "requestsource": "wechat-miniapp",
        "SupplierType": "0",
        "X-Tenant": "vmoscloud",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    }
    if token:
        h["Token"] = token
    if user_id:
        h["userId"] = str(user_id)
    return h


def api_get(path: str, token: str, params: dict | None = None) -> dict[str, Any]:
    url = f"{API_BASE}{path}"
    headers = vmos_headers(token=token)
    resp = requests.get(url, headers=headers, params=params or {}, timeout=30)
    resp.raise_for_status()
    return resp.json()


def api_post(path: str, token: str, payload: dict | None = None) -> dict[str, Any]:
    url = f"{API_BASE}{path}"
    headers = vmos_headers(token=token)
    resp = requests.post(url, headers=headers, json=payload or {}, timeout=30)
    resp.raise_for_status()
    return resp.json()


def get_user_info(token: str) -> dict[str, Any]:
    return api_get("/api/user/getUserInfo", token)


def claim_new_user_gift(token: str) -> dict[str, Any] | None:
    """Claim new user free cloud device (if available)."""
    print("[STEP] Checking new user guide...")
    config = api_get("/api/newUserGuide/getNewUserGuideConfig_V2", token)
    if config.get("code") != 200:
        print(f"[WARN] Guide config failed: {config}")
        return None

    data = config.get("data", {})
    guide_id = data.get("guideId")
    server_code = data.get("serverCode", "")
    print(f"  guideId: {guide_id}, serverCode: {server_code}")

    if not guide_id:
        print("[INFO] No guide available (may already be claimed)")
        return None

    # Need captchaVerifyParam for this endpoint
    # Try without it first
    result = api_post("/api/newUserGuide/getUserReceiveEquipment", token, {
        "guideId": guide_id,
        "countryCode": server_code or "US",
        "captchaVerifyParam": "",
    })
    if result.get("code") == 200:
        print("[OK] New user gift claimed!")
    else:
        print(f"[INFO] Gift claim response: {result}")
    return result


def check_balance(token: str) -> dict[str, Any]:
    """Check cloud device quota/balance if applicable."""
    try:
        resp = api_get("/api/userEquipment/getAuthorizedPermission", token)
        return resp
    except Exception as e:
        print(f"[WARN] Balance check failed: {e}")
        return {}


def load_latest_account() -> dict | None:
    files = sorted(ACCOUNTS_DIR.glob("*.json"), key=os.path.getmtime, reverse=True)
    if not files:
        return None
    return json.loads(files[0].read_text())


def load_account_by_email(email: str) -> dict | None:
    f = ACCOUNTS_DIR / f"{email}.json"
    if f.exists():
        return json.loads(f.read_text())
    return None


def register_account(count: int = 1) -> list[dict]:
    """Run the auto-register script."""
    print(f"\n{'=' * 60}")
    print(f"  Registering {count} account(s)")
    print(f"{'=' * 60}")

    env = os.environ.copy()
    env["DISPLAY"] = os.environ.get("DISPLAY", ":99")

    cmd = [
        sys.executable,
        str(SCRIPT_DIR / "vmos_cloud_auto_register.py"),
        "--count", str(count),
        "--captcha-retries", "3",
    ]

    result = subprocess.run(cmd, env=env, capture_output=True, text=True, timeout=600)
    print(result.stdout)
    if result.stderr:
        print(result.stderr, file=sys.stderr)

    accounts = []
    for f in sorted(ACCOUNTS_DIR.glob("*.json")):
        try:
            data = json.loads(f.read_text())
            if data.get("token"):
                accounts.append(data)
        except Exception:
            pass
    return accounts


def main():
    parser = argparse.ArgumentParser(description="VMOS Cloud 一键脚本: 注册 → 领设备 → 查信息")
    parser.add_argument("--yyds-key", help="YYDS API key (or set YYDS_KEY env)")
    parser.add_argument("--token", help="Existing token (skip registration)")
    parser.add_argument("--email", help="Existing email (skip registration)")
    parser.add_argument("--password", help="Password for registration")
    parser.add_argument("--register", action="store_true", help="Register new account")
    parser.add_argument("--count", type=int, default=1, help="Number of accounts to register")
    parser.add_argument("--skip-register", action="store_true", help="Skip registration")
    parser.add_argument("--skip-gift", action="store_true", help="Skip claiming new user gift")
    parser.add_argument("--skip-info", action="store_true", help="Skip user info display")
    args = parser.parse_args()

    # ── Get Token ──────────────────────────────────────────────────
    token = args.token
    account = None

    if args.register:
        if args.yyds_key:
            os.environ["YYDS_KEY"] = args.yyds_key
        accounts = register_account(args.count)
        if not accounts:
            latest = load_latest_account()
            if latest:
                accounts = [latest]
            else:
                print("[ERROR] Registration failed, no accounts")
                return
        account = accounts[-1]
        token = account["token"]
        print(f"\n[OK] Using account: {account['email']}")
    elif args.email:
        account = load_account_by_email(args.email)
        if not account:
            print(f"[ERROR] Account not found: {args.email}")
            return
        token = account["token"]
    elif not token:
        account = load_latest_account()
        if not account:
            print("[ERROR] No accounts found. Use --register or --token")
            return
        token = account["token"]
        print(f"[OK] Using account: {account['email']}")

    if not token:
        print("[ERROR] Missing token")
        return

    # ── Claim New User Gift ─────────────────────────────────────────
    if not args.skip_gift:
        print(f"\n{'=' * 60}")
        print("  Step 1: Claim new user gift")
        print(f"{'=' * 60}")
        claim_new_user_gift(token)

    # ── User Info ───────────────────────────────────────────────────
    if not args.skip_info:
        print(f"\n{'=' * 60}")
        print("  Step 2: User info")
        print(f"{'=' * 60}")
        user_info = get_user_info(token)
        if user_info.get("code") == 200:
            data = user_info.get("data", {})
            print(f"  User ID:    {data.get('userId')}")
            print(f"  Email:      {data.get('email') or data.get('mobilePhone')}")
            print(f"  Nickname:   {data.get('nickname')}")
            print(f"  VIP:        {data.get('vip', 'N/A')}")
            print(f"  Created:    {data.get('createTime', 'N/A')}")

            # Save updated account info
            if account:
                account.update(user_info)
                out_file = ACCOUNTS_DIR / f"{account.get('email', 'unknown')}.json"
                out_file.write_text(json.dumps(account, ensure_ascii=False, indent=2))
        else:
            print(f"  Error: {user_info}")

    print("\n[DONE]")


if __name__ == "__main__":
    main()
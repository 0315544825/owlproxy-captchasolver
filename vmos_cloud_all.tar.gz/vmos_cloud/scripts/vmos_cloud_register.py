#!/usr/bin/env python3
"""VMOS Cloud registration via API (no browser needed).

Requires a pre-obtained captchaVerifyParam.
Use vmos_cloud_human_captcha_capture.py or vmos_cloud_auto_register.py to get one.

Usage:
    # Step 1: Get captchaVerifyParam from browser script
    # Step 2: Run this script
    python3 scripts/vmos_cloud_register.py \
        --email you@example.com \
        --password YourPassword123 \
        --captcha-token "eyJ..." \
        --verify-code 123456
"""

import argparse
import hashlib
import json
import requests

API_BASE = "https://api.vmoscloud.com/vcpcloud"


def md5_password(password: str) -> str:
    return hashlib.md5(password.encode()).hexdigest()


def vmos_headers(token: str | None = None, user_id: str | None = None) -> dict[str, str]:
    h = {
        "Content-Type": "application/json",
        "Accept-Language": "en",
        "clientType": "web",
        "appVersion": "3.6.1800",
        "requestsource": "wechat-miniapp",
        "SupplierType": "0",
        "X-Tenant": "vmoscloud",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    }
    if token:
        h["Token"] = token
    if user_id:
        h["userId"] = user_id
    return h


def check_email(email: str) -> dict:
    """Check if email is already registered."""
    url = f"{API_BASE}/api/user/checkEmail"
    params = {"mobilePhone": email}
    headers = vmos_headers()
    print(f"[GET] {url}?mobilePhone={email}")
    resp = requests.get(url, params=params, headers=headers, timeout=30)
    print(f"[STATUS] {resp.status_code}")
    print(f"[RESPONSE] {resp.text[:500]}")
    return resp.json()


def sms_send(email: str, captcha_verify_param: str) -> dict:
    """Send verification code to email."""
    url = f"{API_BASE}/api/sms/smsSend"
    payload = {
        "smsType": 2,
        "mobilePhone": email,
        "captchaVerifyParam": captcha_verify_param,
    }
    # Minimal headers — extra headers can break Aliyun signature
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    }
    print(f"\n[POST] {url}")
    print(f"[BODY] mobilePhone={email}, smsType=2, captchaVerifyParam=({len(captcha_verify_param)} chars)")
    resp = requests.post(url, json=payload, headers=headers, timeout=30)
    print(f"[STATUS] {resp.status_code}")
    print(f"[RESPONSE] {resp.text[:500]}")
    return resp.json()


def login(email: str, password: str, verify_code: str, *, channel: str = "", login_type: int = 0) -> dict:
    """Login or register with verification code."""
    url = f"{API_BASE}/api/user/login"
    payload = {
        "mobilePhone": email,
        "loginType": login_type,
        "verifyCode": verify_code if login_type == 0 else None,
        "password": md5_password(password) if login_type == 1 else md5_password(password),
        "channel": channel,
    }
    # Remove None values
    payload = {k: v for k, v in payload.items() if v is not None}
    headers = vmos_headers()
    print(f"\n[POST] {url}")
    print(f"[BODY] {json.dumps({k: v for k, v in payload.items() if k != 'password'}, indent=2)}")
    resp = requests.post(url, json=payload, headers=headers, timeout=30)
    print(f"[STATUS] {resp.status_code}")
    print(f"[RESPONSE] {resp.text[:500]}")
    return resp.json()


def get_user_info(token: str) -> dict:
    """Get user info with token."""
    url = f"{API_BASE}/api/user/getUserInfo"
    headers = vmos_headers(token=token)
    resp = requests.get(url, headers=headers, timeout=30)
    return resp.json()


def main():
    parser = argparse.ArgumentParser(description="VMOS Cloud Registration (API only)")
    parser.add_argument("--email", required=True, help="Email address")
    parser.add_argument("--password", required=True, help="Password (will be MD5 hashed)")
    parser.add_argument("--captcha-token", required=True, help="captchaVerifyParam from browser intercept")
    parser.add_argument("--verify-code", required=True, help="6-digit verification code from email")
    parser.add_argument("--channel", default="", help="Channel parameter")
    parser.add_argument("--sms-only", action="store_true", help="Only send SMS, skip login")
    parser.add_argument("--check-only", action="store_true", help="Only check if email is registered")
    args = parser.parse_args()

    print("=" * 60)
    print("  VMOS Cloud Registration (API)")
    print("=" * 60)

    # Check email
    print("\n[STEP 0] Checking email...")
    check_result = check_email(args.email)
    if args.check_only:
        return

    # Send SMS
    print("\n[STEP 1] Sending verification code...")
    sms_result = sms_send(args.email, args.captcha_token)

    sms_ok = sms_result.get("code") == 200 or sms_result.get("success")
    if sms_ok:
        print("\n[SUCCESS] Verification code sent!")
        is_register = sms_result.get("isRegister", sms_result.get("data", {}).get("isRegister", None))
        if is_register is not None:
            print(f"[INFO] isRegister={is_register} (server flag from smsSend)")
    else:
        print(f"\n[WARNING] SMS send may have failed: {sms_result}")
        if not args.sms_only:
            cont = input("Continue with login anyway? (y/n): ")
            if cont.lower() != "y":
                return

    if args.sms_only:
        print("\n[DONE] SMS-only mode. Check your email for the code.")
        return

    # Login/Register
    print("\n[STEP 2] Logging in / registering...")
    login_result = login(args.email, args.password, args.verify_code, channel=args.channel)

    if login_result.get("code") == 200:
        data = login_result.get("data", {})
        token = data.get("token", "")
        user_id = data.get("userId", "")
        print(f"\n[SUCCESS] Registration/Login completed!")
        print(f"[TOKEN]   {token[:20]}... (len={len(token)})" if token else "[WARN] No token")
        print(f"[USER_ID] {user_id}")

        # Verify token
        if token:
            user_info = get_user_info(token)
            print(f"\n[USER INFO] {json.dumps(user_info, indent=2, ensure_ascii=False)[:500]}")
    else:
        print(f"\n[FAILED] {login_result}")


if __name__ == "__main__":
    main()
#!/usr/bin/env python3
"""VMOS Cloud registration with OpenCV gap detection + CloakBrowser.
The key issue: fixed drag distance (149px) doesn't match the actual puzzle gap position.
This script uses OpenCV to detect the gap position dynamically, like OwlProxy does.
"""

import asyncio
import hashlib
import json
import math
import random
import re
import time

import cv2
import numpy as np
import requests
from cloakbrowser import launch_async

YYDS_KEY = "AC-29e9b09c5ae93e1347debb66"
API_BASE = "https://api.vmoscloud.com/vcpcloud"


def detect_gap_x(page_screenshot_path: str) -> int:
    """Detect the puzzle gap X position from a screenshot using OpenCV.
    Same approach as OwlProxy's solve_captcha function.
    """
    try:
        full_img = cv2.imread(page_screenshot_path)
        if full_img is None:
            return 85  # fallback
        
        h, w = full_img.shape[:2]
        cx, cy = w // 2, h // 2
        
        # Crop around the center where CAPTCHA usually appears
        crop = full_img[cy - 120:cy + 80, cx - 180:cx + 180]
        gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
        ch, cw = gray.shape
        
        # Threshold to find bright white areas (puzzle gap outline)
        _, white = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY)
        
        best_x, best_score = 85, 0
        for x in range(20, cw // 2 - 20):
            region = white[:, max(0, x - 10):x + 10]
            if region.size > 0:
                score = int(np.sum(region))
                if score > best_score:
                    best_score = score
                    best_x = x
        
        # Convert crop coordinates back to page coordinates
        # The slider starts at some offset from the left edge of the CAPTCHA
        # We need to figure out the gap position relative to the slider start
        print(f"  [CV] Gap detected at crop_x={best_x}, score={best_score}")
        return best_x
    except Exception as e:
        print(f"  [CV] Error: {e}")
        return 85


async def register_one(email: str, password: str = "VmosCloud2026!"):
    print(f"\n[0] Using email: {email}")
    
    browser = await launch_async(
        headless=False,
        args=["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage"]
    )
    context = await browser.new_context(
        viewport={"width": 1280, "height": 800},
        locale="en",
        timezone_id="America/New_York",
    )
    page = await context.new_page()

    # Capture network
    captured = {"smsSend_response": None}

    async def on_response(resp):
        if "smsSend" in resp.url:
            try:
                captured["smsSend_response"] = await resp.text()
            except:
                pass

    page.on("response", on_response)

    try:
        # Navigate
        print("[1] Opening VMOS Cloud...")
        await page.goto("https://cloud.vmoscloud.com/", wait_until="networkidle", timeout=60000)
        await asyncio.sleep(2)

        try:
            await page.click('[class*="agreement"]', timeout=2000)
        except:
            pass
        await asyncio.sleep(0.3)

        # Fill email
        print(f"[2] Filling email: {email}")
        for sel in ['input[placeholder*="email"]', 'input[placeholder*="Email"]']:
            try:
                await page.fill(sel, email, timeout=3000)
                break
            except:
                continue
        await asyncio.sleep(0.5)

        # Click Login
        print("[3] Clicking Login/Register...")
        for sel in ['button:has-text("Login")', 'button:has-text("Register")']:
            try:
                await page.click(sel, timeout=3000)
                break
            except:
                continue
        await asyncio.sleep(3)

        # Solve CAPTCHA with OpenCV gap detection
        print("[4] Solving CAPTCHA with OpenCV gap detection...")
        for attempt in range(1, 8):
            # Take screenshot and detect gap
            await asyncio.sleep(2)
            shot_path = f"/tmp/vmos_captcha_{attempt}.png"
            await page.screenshot(path=shot_path)
            
            gap_x = detect_gap_x(shot_path)
            
            slider = await page.query_selector('#aliyunCaptcha-sliding-slider') or await page.query_selector('.slider-move')
            if not slider:
                print("  No slider found - CAPTCHA may have auto-passed")
                break

            box = await slider.bounding_box()
            if not box:
                print("  Slider has no bounding box")
                break

            # Calculate actual drag distance
            # gap_x is relative to the crop area, we need to convert to absolute page coordinates
            # The slider starts at box.x, the gap is at (cx - 180 + gap_x) in page coords
            # But we need drag distance relative to slider start
            page_full = cv2.imread(shot_path)
            if page_full is not None:
                pw = page_full.shape[1]
                cx = pw // 2
                # Gap position in page coordinates
                gap_page_x = (cx - 180) + gap_x
                # Slider center X
                slider_cx = box["x"] + box["width"] / 2
                # The actual puzzle image area typically starts at some offset
                # We need to find where the puzzle background image starts
                # The slider track usually starts at slider position
                # The gap in the puzzle image is at gap_page_x
                # The drag distance = gap_page_x - slider_start_x (approximately)
                # But we need to account for the puzzle image offset
                
                # Let's find the puzzle image container
                puzzle_info = await page.evaluate("""() => {
                    const popup = document.getElementById('aliyunCaptcha-window-popup');
                    if (!popup) return null;
                    const rect = popup.getBoundingClientRect();
                    const img = popup.querySelector('img');
                    if (!img) return null;
                    const imgRect = img.getBoundingClientRect();
                    return {
                        popupX: rect.x, popupY: rect.y, popupW: rect.width, popupH: rect.height,
                        imgX: imgRect.x, imgY: imgRect.y, imgW: imgRect.width, imgH: imgRect.height,
                        sliderX: 0  // will add separately
                    };
                }""")
                
                if puzzle_info:
                    # The gap position relative to the puzzle background image
                    # gap_page_x is in page coordinates, puzzle image starts at puzzle_info.imgX
                    gap_relative_to_img = gap_page_x - puzzle_info['imgX']
                    # The slider starts at box.x
                    # Drag distance = gap position relative to slider start
                    # But we need to account for the puzzle piece start offset
                    drag_dist = int(gap_relative_to_img - box["width"] / 2)
                    if drag_dist < 20:
                        drag_dist = 85 + random.randint(50, 80)  # fallback
                    print(f"  [CV] Popup: x={puzzle_info['popupX']}, img: x={puzzle_info['imgX']}, w={puzzle_info['imgW']}")
                    print(f"  [CV] Gap relative to img: {gap_relative_to_img}, slider_cx: {slider_cx}")
                    print(f"  [CV] Calculated drag distance: {drag_dist}px")
                else:
                    drag_dist = 85 + random.randint(50, 80)
                    print(f"  [CV] No puzzle container found, using fallback: {drag_dist}px")
            else:
                drag_dist = 85 + random.randint(50, 80)
                print(f"  [CV] Screenshot failed, using fallback: {drag_dist}px")

            sx, sy = box["x"] + box["width"] / 2, box["y"] + box["height"] / 2
            print(f"  Attempt {attempt}: drag {drag_dist}px from ({sx:.0f}, {sy:.0f})")

            await page.mouse.move(sx, sy)
            await asyncio.sleep(0.3 + random.random() * 0.2)
            await page.mouse.down()
            await asyncio.sleep(0.1)

            # OwlProxy-style drag
            for i in range(1, 51):
                t = i / 50
                progress = 1 - (1 - t) ** 2.5
                if progress > 0.85:
                    progress = 0.85 + (progress - 0.85) * 0.3
                x = sx + drag_dist * progress
                y = sy + random.gauss(0, 1.5)
                await page.mouse.move(x, y)
                await asyncio.sleep(0.05)
            
            await page.mouse.up()
            await asyncio.sleep(5)

            # Check result
            captcha_visible = await page.evaluate("""() => {
                const el = document.getElementById('aliyunCaptcha-window-popup');
                if (!el) return false;
                return el.style.display !== 'none' && el.offsetHeight > 0;
            }""")

            if not captcha_visible:
                print(f"  ✅ CAPTCHA PASSED (attempt {attempt})!")
                break
            else:
                print(f"  ❌ Still visible, refreshing...")
                try:
                    ref = await page.query_selector('#aliyunCaptcha-btn-refresh')
                    if ref:
                        await ref.click()
                        await asyncio.sleep(2)
                except:
                    pass

        # Check smsSend result
        await asyncio.sleep(2)
        print(f"\n[5] smsSend result: {captured['smsSend_response'][:200] if captured['smsSend_response'] else 'NO REQUEST'}")

        # Poll YYDS
        print(f"\n[6] Polling YYDS for verification code to {email}...")
        verify_code = None
        for i in range(24):
            time.sleep(10)
            try:
                r = requests.get(f"https://maliapi.215.im/v1/messages?address={email}",
                               headers={"X-API-Key": YYDS_KEY}, timeout=15)
                msgs = (r.json().get("data") or {}).get("messages") or []
                if msgs:
                    for msg in msgs:
                        mid = msg.get("id")
                        full = requests.get(f"https://maliapi.215.im/v1/messages/{mid}?address={email}",
                                           headers={"X-API-Key": YYDS_KEY}, timeout=15).text
                        codes = re.findall(r'\b(\d{6})\b', full)
                        if codes:
                            verify_code = codes[-1]
                            print(f"  ✅ CODE: {verify_code}")
                            break
            except Exception as e:
                print(f"  Error: {e}")
            if verify_code:
                break
            if i % 3 == 0:
                print(f"  Waiting... ({(i+1)*10}s)")

        if verify_code:
            print(f"\n[7] Logging in...")
            login_headers = {
                "Content-Type": "application/json", "Accept-Language": "en",
                "clientType": "web", "appVersion": "3.6.1800",
                "requestsource": "wechat-miniapp", "SupplierType": "0", "X-Tenant": "vmoscloud",
            }
            login_resp = requests.post(f"{API_BASE}/api/user/login", headers=login_headers, json={
                "mobilePhone": email, "loginType": 0, "verifyCode": verify_code,
                "password": hashlib.md5(password.encode()).hexdigest(), "channel": ""
            }, timeout=30)
            result = login_resp.json()
            print(json.dumps(result, indent=2, ensure_ascii=False)[:500])

            if result.get("code") == 200:
                data = result.get("data", {})
                print(f"\n{'='*50}")
                print(f"  ✅ SUCCESS!")
                print(f"  Email:    {email}")
                print(f"  Password: {password}")
                print(f"  User ID:  {data.get('userId')}")
                print(f"{'='*50}")
                
                import os
                account = {
                    "email": email, "password": password,
                    "password_md5": hashlib.md5(password.encode()).hexdigest(),
                    "token": data.get("token"), "userId": data.get("userId"),
                    "isRegister": data.get("isRegister"), "platform": "vmos_cloud",
                    "created_at": str(int(time.time())),
                }
                os.makedirs("accounts", exist_ok=True)
                with open(f"accounts/{email}.json", "w") as f:
                    json.dump(account, f, ensure_ascii=False, indent=2)
                print(f"  Saved to accounts/{email}.json")
                return account
        else:
            print("  ❌ No verification code received")

    finally:
        await browser.close()
    return None


if __name__ == "__main__":
    EMAIL = f"vmos{int(time.time())}{random.randint(10,99)}@a0.engineer"
    PASSWORD = "VmosCloud2026!"
    
    print(f"Creating YYDS email: {EMAIL}")
    resp = requests.post("https://maliapi.215.im/v1/accounts",
        headers={"X-API-Key": YYDS_KEY, "Content-Type": "application/json"},
        json={"localPart": EMAIL.split("@")[0], "domain": "a0.engineer"},
        timeout=15)
    result = resp.json()
    if result.get("success"):
        EMAIL = result["data"]["address"]
        print(f"  Email: {EMAIL}")
    
    asyncio.run(register_one(EMAIL, PASSWORD))
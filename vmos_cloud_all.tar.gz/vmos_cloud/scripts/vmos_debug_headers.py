#!/usr/bin/env python3
"""VMOS Cloud - Capture FULL smsSend request details including headers.
We need to understand WHY the browser's smsSend works but API call fails with Signature verification."""

import asyncio
import json
import random
import time

import requests

YYDS_KEY = "AC-29e9b09c5ae93e1347debb66"


async def debug_smsSend():
    from playwright.async_api import async_playwright

    EMAIL = f"vmos{int(time.time())}{random.randint(10,99)}@a0.engineer"
    
    print(f"Creating email: {EMAIL}")
    resp = requests.post("https://maliapi.215.im/v1/accounts",
        headers={"X-API-Key": YYDS_KEY, "Content-Type": "application/json"},
        json={"localPart": EMAIL.split("@")[0], "domain": "a0.engineer"},
        timeout=15)
    print(f"  Email result: {resp.json().get('success')}")

    pw = await async_playwright().start()
    browser = await pw.chromium.launch(
        headless=False,
        args=['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage']
    )
    context = await browser.new_context(viewport={"width": 1280, "height": 800}, locale="en")
    page = await context.new_page()

    # Capture ALL request details
    all_requests = []

    async def on_request(req):
        if "smsSend" in req.url or "checkEmail" in req.url or "captcha" in req.url.lower():
            info = {
                "url": req.url,
                "method": req.method,
                "headers": dict(req.headers),
                "post_data": req.post_data[:3000] if req.post_data else None,
            }
            all_requests.append(info)
            print(f"\n[REQUEST] {req.method} {req.url[:100]}")
            if req.post_data:
                try:
                    body = json.loads(req.post_data)
                    cvp = body.get("captchaVerifyParam", "")
                    print(f"  captchaVerifyParam length: {len(cvp)}")
                    if cvp:
                        # Parse the captchaVerifyParam if it's JSON
                        try:
                            parsed = json.loads(cvp)
                            print(f"  captchaVerifyParam keys: {list(parsed.keys()) if isinstance(parsed, dict) else 'not dict'}")
                        except:
                            print(f"  captchaVerifyParam preview: {cvp[:200]}")
                    print(f"  Other body keys: {[k for k in body.keys() if k != 'captchaVerifyParam']}")
                except:
                    pass

    async def on_response(resp):
        if "smsSend" in resp.url or "checkEmail" in resp.url:
            try:
                text = await resp.text()
                print(f"\n[RESPONSE] {resp.url[:80]} status={resp.status}")
                print(f"  Body: {text[:500]}")
            except:
                pass

    page.on("request", on_request)
    page.on("response", on_response)

    # Navigate and register
    print("\n[Navigate] Opening VMOS Cloud...")
    await page.goto("https://cloud.vmoscloud.com/", wait_until="networkidle", timeout=60000)
    await asyncio.sleep(2)

    try:
        await page.click('[class*="agreement"]', timeout=2000)
    except:
        pass
    await asyncio.sleep(0.3)

    print(f"\n[Fill] Email: {EMAIL}")
    try:
        await page.fill('input[placeholder*="email"]', EMAIL, timeout=5000)
    except:
        await page.fill('input[placeholder*="Email"]', EMAIL, timeout=5000)
    await asyncio.sleep(0.5)

    print("[Click] Login/Register...")
    try:
        await page.click('button:has-text("Login")', timeout=5000)
    except:
        try:
            await page.click('button:has-text("Register")', timeout=5000)
        except:
            pass
    await asyncio.sleep(3)

    # Solve CAPTCHA
    print("\n[Solve] CAPTCHA...")
    slider = await page.query_selector('#aliyunCaptcha-sliding-slider') or await page.query_selector('.slider-move')
    if slider:
        box = await slider.bounding_box()
        if box:
            sx, sy = box["x"] + box["width"] / 2, box["y"] + box["height"] / 2
            for attempt, drag_dist in enumerate([149], 1):
                print(f"  Drag {drag_dist}px...")
                await page.mouse.move(sx, sy)
                await asyncio.sleep(0.3)
                await page.mouse.down()
                await asyncio.sleep(0.1)
                for i in range(1, 51):
                    t = i / 50
                    progress = 1 - (1 - t) ** 2.5
                    if progress > 0.85:
                        progress = 0.85 + (progress - 0.85) * 0.3
                    x = sx + drag_dist * progress
                    y = sy + random.gauss(0, 1.5)
                    await page.mouse.move(x, y)
                    await asyncio.sleep(0.05)
                await page.mouse.up()
                await asyncio.sleep(5)

                captcha_visible = await page.evaluate("""() => {
                    const el = document.getElementById('aliyunCaptcha-window-popup');
                    if (!el) return false;
                    return el.style.display !== 'none' && el.offsetHeight > 0;
                }""")
                print(f"  CAPTCHA visible: {captcha_visible}")

    await asyncio.sleep(3)

    # Print all captured requests
    print(f"\n\n{'='*60}")
    print("CAPTURED REQUESTS:")
    print(f"{'='*60}")
    for i, req in enumerate(all_requests):
        print(f"\n--- Request {i+1} ---")
        print(f"URL: {req['url']}")
        print(f"Method: {req['method']}")
        print(f"Headers:")
        for k, v in req['headers'].items():
            if k.lower() in ['content-type', 'token', 'userid', 'x-tenant', 'appversion', 'clienttype', 'requestsource', 'suppliertype', 'accept-language', 'referer', 'origin', 'cookie']:
                print(f"  {k}: {v}")
        if req['post_data']:
            try:
                body = json.loads(req['post_data'])
                cvp_len = len(body.get('captchaVerifyParam', ''))
                print(f"Body keys: {list(body.keys())}")
                print(f"captchaVerifyParam length: {cvp_len}")
                if cvp_len > 0 and cvp_len < 500:
                    print(f"captchaVerifyParam: {body['captchaVerifyParam']}")
            except:
                print(f"Post data (raw): {req['post_data'][:500]}")

    await browser.close()


if __name__ == "__main__":
    asyncio.run(debug_smsSend())
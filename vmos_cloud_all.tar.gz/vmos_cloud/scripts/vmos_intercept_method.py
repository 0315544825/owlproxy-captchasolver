#!/usr/bin/env python3
"""VMOS Cloud registration - Intercept captchaVerifyParam from network request.
Based on OwlProxy's approach but adapted for VMOS Cloud.
1. Open fresh browser, navigate to VMOS Cloud
2. Fill email, click login
3. Solve CAPTCHA slider
4. Intercept the smsSend network request to capture captchaVerifyParam
5. If browser smsSend fails, call smsSend API directly with the captured token
6. Poll YYDS for verification code
7. Login via API
"""

import asyncio
import hashlib
import json
import math
import random
import re
import time

import requests

YYDS_KEY = "AC-29e9b09c5ae93e1347debb66"
API_BASE = "https://api.vmoscloud.com/vcpcloud"


async def register():
    from playwright.async_api import async_playwright

    # Create new YYDS email
    EMAIL = f"vmos{int(time.time())}{random.randint(10,99)}@a0.engineer"
    PASSWORD = "VmosCloud2026!"
    
    print(f"[0] Creating email: {EMAIL}")
    resp = requests.post("https://maliapi.215.im/v1/accounts",
        headers={"X-API-Key": YYDS_KEY, "Content-Type": "application/json"},
        json={"localPart": EMAIL.split("@")[0], "domain": "a0.engineer"},
        timeout=15)
    email_result = resp.json()
    if not email_result.get("success"):
        print(f"  Failed to create email: {email_result}")
        return
    print(f"  Email created: {email_result['data']['address']}")

    pw = await async_playwright().start()
    browser = await pw.chromium.launch(
        headless=False,
        args=['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage']
    )
    context = await browser.new_context(viewport={"width": 1280, "height": 800}, locale="en")
    page = await context.new_page()

    # Intercept network requests
    captured = {"smsSend_body": None, "smsSend_response": None, "captchaVerifyParam": None}

    async def on_request(req):
        if "smsSend" in req.url:
            try:
                body = req.post_data
                if body:
                    parsed = json.loads(body) if isinstance(body, str) else body
                    captured["smsSend_body"] = parsed
                    cvp = parsed.get("captchaVerifyParam", "")
                    if cvp:
                        captured["captchaVerifyParam"] = cvp
                        print(f"  [INTERCEPT] smsSend captchaVerifyParam: {len(cvp)} chars")
            except Exception:
                pass

    async def on_response(resp):
        if "smsSend" in resp.url:
            try:
                captured["smsSend_response"] = await resp.text()
                print(f"  [INTERCEPT] smsSend response: {captured['smsSend_response'][:200]}")
            except Exception:
                pass

    page.on("request", on_request)
    page.on("response", on_response)

    # Navigate
    print("[1] Opening VMOS Cloud...")
    await page.goto("https://cloud.vmoscloud.com/", wait_until="networkidle", timeout=60000)
    await asyncio.sleep(2)

    # Agree & fill email
    try:
        await page.click('[class*="agreement"]', timeout=2000)
    except Exception:
        pass
    await asyncio.sleep(0.3)
    print(f"[2] Filling email: {EMAIL}")
    try:
        await page.fill('input[placeholder*="email"]', EMAIL, timeout=5000)
    except Exception:
        await page.fill('input[placeholder*="Email"]', EMAIL, timeout=5000)
    await asyncio.sleep(0.5)

    # Click Login/Register
    print("[3] Clicking Login/Register...")
    try:
        await page.click('button:has-text("Login")', timeout=5000)
    except Exception:
        try:
            await page.click('button:has-text("Register")', timeout=5000)
        except Exception:
            pass
    await asyncio.sleep(3)

    # Solve CAPTCHA
    print("[4] Solving CAPTCHA...")
    slider = await page.query_selector('#aliyunCaptcha-sliding-slider') or await page.query_selector('.slider-move')
    if not slider:
        print("  No slider found - CAPTCHA may have auto-passed or not loaded")
    else:
        box = await slider.bounding_box()
        if box:
            sx, sy = box["x"] + box["width"] / 2, box["y"] + box["height"] / 2
            for attempt, drag_dist in enumerate([149, 160, 140, 170, 130, 155, 145, 125, 180, 120], 1):
                print(f"  Attempt {attempt}: drag {drag_dist}px")
                slider = await page.query_selector('#aliyunCaptcha-sliding-slider') or await page.query_selector('.slider-move')
                if slider:
                    box = await slider.bounding_box()
                    if box:
                        sx, sy = box["x"] + box["width"] / 2, box["y"] + box["height"] / 2

                await page.mouse.move(sx, sy)
                await asyncio.sleep(0.3)
                await page.mouse.down()
                await asyncio.sleep(0.1)
                # OwlProxy-style drag
                for i in range(1, 51):
                    t = i / 50
                    progress = 1 - (1 - t) ** 2.5
                    if progress > 0.85:
                        progress = 0.85 + (progress - 0.85) * 0.3
                    x = sx + drag_dist * progress
                    y = sy + random.gauss(0, 1.5)
                    await page.mouse.move(x, y)
                    await asyncio.sleep(0.05)
                await page.mouse.up()
                await asyncio.sleep(5)

                captcha_visible = await page.evaluate("""() => {
                    const el = document.getElementById('aliyunCaptcha-window-popup');
                    if (!el) return false;
                    return el.style.display !== 'none' && el.offsetHeight > 0;
                }""")

                if not captcha_visible:
                    print(f"  CAPTCHA PASSED (attempt {attempt})!")
                    break
                else:
                    print(f"  Still visible, refreshing...")
                    try:
                        ref = await page.query_selector('#aliyunCaptcha-btn-refresh')
                        if ref:
                            await ref.click()
                            await asyncio.sleep(2)
                    except Exception:
                        pass

    await asyncio.sleep(2)

    # Check what we captured
    print(f"\n[5] Checking captured data...")
    print(f"  smsSend_body: {'YES' if captured['smsSend_body'] else 'NO'}")
    print(f"  captchaVerifyParam: {len(captured['captchaVerifyParam']) if captured['captchaVerifyParam'] else 'NONE'} chars")
    print(f"  smsSend_response: {captured['smsSend_response'][:200] if captured['smsSend_response'] else 'NONE'}")

    # Also check localStorage for captchaVerifyParam (OwlProxy method)
    storage_param = await page.evaluate("""() => {
        const candidates = [];
        for (const store of [localStorage, sessionStorage]) {
            for (let i = 0; i < store.length; i++) {
                const key = store.key(i);
                const val = store.getItem(key);
                if (!val || typeof val !== 'string') continue;
                if (val.length > 500) candidates.push({key, len: val.length, preview: val.substring(0, 80)});
            }
        }
        candidates.sort((a,b) => b.len - a.len);
        return candidates;
    }""")
    print(f"  Large storage entries: {json.dumps(storage_param[:5], indent=2)}")

    # If we captured captchaVerifyParam, try calling smsSend directly
    if captured["captchaVerifyParam"]:
        token = captured["captchaVerifyParam"]
        print(f"\n[6] Calling smsSend API directly with captured token...")
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        }
        payload = {
            "smsType": 2,
            "mobilePhone": EMAIL,
            "captchaVerifyParam": token
        }
        resp = requests.post(f"{API_BASE}/api/sms/smsSend", json=payload, headers=headers, timeout=30)
        print(f"  Status: {resp.status_code}")
        print(f"  Response: {resp.text[:500]}")

    elif captured["smsSend_response"]:
        print(f"\n[6] Browser smsSend response: {captured['smsSend_response'][:500]}")
    else:
        print("\n[6] No smsSend was called - CAPTCHA likely failed")

    # Poll for verification code anyway
    print(f"\n[7] Polling YYDS for verification code to {EMAIL}...")
    verify_code = None
    for i in range(18):
        time.sleep(10)
        try:
            r = requests.get(f"https://maliapi.215.im/v1/messages?address={EMAIL}",
                           headers={"X-API-Key": YYDS_KEY}, timeout=15)
            msgs = (r.json().get("data") or {}).get("messages") or []
            if msgs:
                for msg in msgs:
                    mid = msg.get("id")
                    full = requests.get(f"https://maliapi.215.im/v1/messages/{mid}?address={EMAIL}",
                                       headers={"X-API-Key": YYDS_KEY}, timeout=15).text
                    codes = re.findall(r'\b(\d{6})\b', full)
                    if codes:
                        verify_code = codes[-1]
                        print(f"  CODE: {verify_code}")
                        break
        except Exception as e:
            print(f"  Error: {e}")
        if verify_code:
            break
        print(f"  Waiting... ({(i+1)*10}s)")

    if verify_code:
        print(f"\n[8] Logging in with code {verify_code}...")
        login_headers = {
            "Content-Type": "application/json",
            "Accept-Language": "en",
            "clientType": "web",
            "appVersion": "3.6.1800",
            "requestsource": "wechat-miniapp",
            "SupplierType": "0",
            "X-Tenant": "vmoscloud",
        }
        login_resp = requests.post(f"{API_BASE}/api/user/login", headers=login_headers, json={
            "mobilePhone": EMAIL,
            "loginType": 0,
            "verifyCode": verify_code,
            "password": hashlib.md5(PASSWORD.encode()).hexdigest(),
            "channel": ""
        }, timeout=30)
        result = login_resp.json()
        print(json.dumps(result, indent=2, ensure_ascii=False)[:500])
    else:
        print("  No verification code received")

    await page.screenshot(path="/tmp/vmos_owlproxy_method.png")
    await browser.close()


if __name__ == "__main__":
    asyncio.run(register())
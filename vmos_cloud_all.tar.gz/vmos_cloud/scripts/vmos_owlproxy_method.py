#!/usr/bin/env python3
"""VMOS Cloud registration using OwlProxy's approach:
1. Solve CAPTCHA slider in browser
2. Extract captchaVerifyParam from browser storage (not from network intercept)
3. Call smsSend API directly with the token
4. Poll YYDS for verification code
5. Login via API
"""

import asyncio
import hashlib
import json
import math
import random
import re
import time

import requests

YYDS_KEY = "AC-29e9b09c5ae93e1347debb66"
API_BASE = "https://api.vmoscloud.com/vcpcloud"


async def register():
    from playwright.async_api import async_playwright

    pw = await async_playwright().start()
    browser = await pw.chromium.connect_over_cdp("http://127.0.0.1:18800")
    context = browser.contexts[0]

    # Find VMOS page
    page = None
    for p in context.pages:
        if "cloud.vmoscloud.com" in p.url:
            page = p
            break

    if not page:
        print("No VMOS page found, opening new one...")
        page = await context.new_page()
        await page.goto("https://cloud.vmoscloud.com/", wait_until="networkidle", timeout=60000)
        await asyncio.sleep(2)
        try:
            await page.click('[class*="agreement"]', timeout=2000)
        except Exception:
            pass
        await asyncio.sleep(0.3)
        EMAIL = "alex.cloud@a0.engineer"
        try:
            await page.fill('input[placeholder*="email"]', EMAIL, timeout=5000)
        except Exception:
            await page.fill('input[placeholder*="Email"]', EMAIL, timeout=5000)
        await asyncio.sleep(0.5)
        try:
            await page.click('button:has-text("Login")', timeout=5000)
        except Exception:
            await page.click('button:has-text("Register")', timeout=5000)
        await asyncio.sleep(3)

    print(f"Page: {page.url}")

    # Create YYDS email
    EMAIL = "alex.cloud@a0.engineer"
    PASSWORD = "VmosCloud2026!"

    # Step 1: Solve CAPTCHA
    print("[1] Solving CAPTCHA...")
    slider = await page.query_selector('#aliyunCaptcha-sliding-slider') or await page.query_selector('.slider-move')
    if slider:
        box = await slider.bounding_box()
        if box:
            sx, sy = box["x"] + box["width"] / 2, box["y"] + box["height"] / 2
            for attempt, drag_dist in enumerate([149, 160, 140, 170, 130, 155, 145, 125, 180, 120], 1):
                print(f"  Attempt {attempt}: drag {drag_dist}px")
                slider = await page.query_selector('#aliyunCaptcha-sliding-slider') or await page.query_selector('.slider-move')
                if slider:
                    box = await slider.bounding_box()
                    if box:
                        sx, sy = box["x"] + box["width"] / 2, box["y"] + box["height"] / 2

                await page.mouse.move(sx, sy)
                await asyncio.sleep(0.3)
                await page.mouse.down()
                await asyncio.sleep(0.1)
                for i in range(1, 51):
                    t = i / 50
                    progress = 1 - (1 - t) ** 2.5
                    if progress > 0.85:
                        progress = 0.85 + (progress - 0.85) * 0.3
                    x = sx + drag_dist * progress
                    y = sy + random.gauss(0, 1.5)
                    await page.mouse.move(x, y)
                    await asyncio.sleep(0.05)
                await page.mouse.up()
                await asyncio.sleep(5)

                captcha_visible = await page.evaluate("""() => {
                    const el = document.getElementById('aliyunCaptcha-window-popup');
                    if (!el) return false;
                    return el.style.display !== 'none' && el.offsetHeight > 0;
                }""")

                if not captcha_visible:
                    print(f"  CAPTCHA PASSED (attempt {attempt})!")
                    break
                else:
                    print(f"  Still visible, refreshing...")
                    try:
                        ref = await page.query_selector('#aliyunCaptcha-btn-refresh')
                        if ref:
                            await ref.click()
                            await asyncio.sleep(2)
                    except Exception:
                        pass
    else:
        print("  No slider found")

    # Step 2: Extract captchaVerifyParam from browser storage (OwlProxy method!)
    print("\n[2] Extracting captchaVerifyParam from browser storage...")
    captcha_param = await page.evaluate("""() => {
        const candidates = [];
        for (const store of [localStorage, sessionStorage]) {
            for (let i = 0; i < store.length; i++) {
                const key = store.key(i);
                const val = store.getItem(key);
                if (!val || typeof val !== 'string') continue;
                candidates.push({key, val, len: val.length, store: store === localStorage ? 'local' : 'session'});
            }
        }
        candidates.sort((a,b) => b.len - a.len);
        for (const item of candidates) {
            const v = item.val;
            if (v.length > 10000) return {value: v, len: v.length, source: item.store + ':' + item.key};
            if (v.length > 1000 && v.includes('sceneId') && v.includes('certifyId')) return {value: v, len: v.length, source: item.store + ':' + item.key};
            if (v.length > 500 && v.includes('hash') && v.includes('nums')) return {value: v, len: v.length, source: item.store + ':' + item.key};
        }
        if (typeof window.captchaVerifyParam === 'string') return {value: window.captchaVerifyParam, len: window.captchaVerifyParam.length, source: 'window.captchaVerifyParam'};
        if (typeof window.__captchaVerifyParam === 'string') return {value: window.__captchaVerifyParam, len: window.__captchaVerifyParam.length, source: 'window.__captchaVerifyParam'};
        for (const key of Object.keys(window)) {
            try {
                const val = window[key];
                if (typeof val === 'string' && val.length > 1000) {
                    if (val.includes('sceneId') || val.includes('certifyId') || (val.includes('hash') && val.includes('nums'))) {
                        return {value: val, len: val.length, source: 'window.' + key};
                    }
                }
            } catch(e) {}
        }
        const storageKeys = [];
        for (const store of [localStorage, sessionStorage]) {
            for (let i = 0; i < store.length; i++) {
                const key = store.key(i);
                const val = store.getItem(key);
                storageKeys.push({key, len: val ? val.length : 0, preview: val ? val.substring(0, 100) : ''});
            }
        }
        return {value: null, storageKeys};
    }""")

    print(f"  Result: {json.dumps(captcha_param, ensure_ascii=False)[:500] if isinstance(captcha_param, dict) else str(captcha_param)[:500]}")

    if not (isinstance(captcha_param, dict) and captcha_param.get('value')):
        print("  No captchaVerifyParam found!")
        if isinstance(captcha_param, dict) and 'storageKeys' in captcha_param:
            print(f"  Storage keys: {json.dumps(captcha_param['storageKeys'], indent=2)}")
        await pw.stop()
        return

    token = captcha_param['value']
    print(f"  Found captchaVerifyParam: {captcha_param['source']} ({captcha_param['len']} chars)")
    print(f"  Preview: {token[:150]}...")

    # Step 3: Call smsSend API directly (like OwlProxy does)
    print("\n[3] Calling smsSend API directly...")
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    }
    payload = {
        "smsType": 2,
        "mobilePhone": EMAIL,
        "captchaVerifyParam": token
    }
    resp = requests.post(f"{API_BASE}/api/sms/smsSend", json=payload, headers=headers, timeout=30)
    print(f"  Status: {resp.status_code}")
    print(f"  Response: {resp.text[:500]}")

    sms_result = resp.json()
    if sms_result.get("code") != 200 and not sms_result.get("success"):
        print("  smsSend FAILED!")
        await pw.stop()
        return

    print("  smsSend SUCCESS!")

    # Step 4: Poll YYDS for verification code
    print("\n[4] Polling YYDS for verification code...")
    verify_code = None
    for i in range(30):
        time.sleep(10)
        try:
            r = requests.get(f"https://maliapi.215.im/v1/messages?address={EMAIL}",
                           headers={"X-API-Key": YYDS_KEY}, timeout=15)
            msgs = (r.json().get("data") or {}).get("messages") or []
            if msgs:
                for msg in msgs:
                    mid = msg.get("id")
                    full = requests.get(f"https://maliapi.215.im/v1/messages/{mid}?address={EMAIL}",
                                       headers={"X-API-Key": YYDS_KEY}, timeout=15).text
                    codes = re.findall(r'\b(\d{6})\b', full)
                    if codes:
                        verify_code = codes[-1]
                        print(f"  CODE: {verify_code}")
                        break
        except Exception as e:
            print(f"  Error: {e}")
        if verify_code:
            break
        if i % 3 == 0:
            print(f"  Waiting... ({(i+1)*10}s)")

    if not verify_code:
        print("  No verification code received!")
        await pw.stop()
        return

    # Step 5: Login via API
    print(f"\n[5] Logging in with code {verify_code}...")
    login_headers = {
        "Content-Type": "application/json",
        "Accept-Language": "en",
        "clientType": "web",
        "appVersion": "3.6.1800",
        "requestsource": "wechat-miniapp",
        "SupplierType": "0",
        "X-Tenant": "vmoscloud",
    }
    login_resp = requests.post(f"{API_BASE}/api/user/login", headers=login_headers, json={
        "mobilePhone": EMAIL,
        "loginType": 0,
        "verifyCode": verify_code,
        "password": hashlib.md5(PASSWORD.encode()).hexdigest(),
        "channel": ""
    }, timeout=30)
    result = login_resp.json()
    print(json.dumps(result, indent=2, ensure_ascii=False)[:500])

    if result.get("code") == 200:
        data = result.get("data", {})
        print(f"\n{'='*50}")
        print(f"  SUCCESS!")
        print(f"  Email:    {EMAIL}")
        print(f"  Password: {PASSWORD}")
        print(f"  User ID:  {data.get('userId')}")
        tok = data.get("token", "")
        print(f"  Token:    {tok[:30]}..." if tok else "  Token:    N/A")
        print(f"  isRegister: {data.get('isRegister')}")
        print(f"{'='*50}")
    else:
        print(f"  Login failed: {result}")

    await pw.stop()


if __name__ == "__main__":
    asyncio.run(register())
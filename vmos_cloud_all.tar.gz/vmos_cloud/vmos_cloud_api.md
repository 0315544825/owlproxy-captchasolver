# VMOS Cloud 注册 API 完整文档

> 来源: https://cloud.vmoscloud.com 前端 JS 分析 + 浏览器网络拦截
> API Base: `https://api.vmoscloud.com/vcpcloud`
> 前端版本: 3.6.1800
> 更新: 2026-06-20

## 通用请求头

```
Content-Type: application/json
Accept-Language: en
clientType: web
appVersion: 3.6.1800
requestsource: wechat-miniapp
SupplierType: 0
X-Tenant: vmoscloud
Token: <登录后token>
userId: <登录后userId>
```

## 认证流程

```
输入邮箱
    ↓
检查邮箱 → GET /api/user/checkEmail?mobilePhone={email}
    ↓
阿里云滑块验证码 (SceneId: 5jvar3wp, prefix: 69r0rc, region: sgp)
    ↓
POST /api/sms/smsSend (需要 captchaVerifyParam)
    ↓
收到6位邮箱验证码 (有效期5分钟)
    ↓
POST /api/user/login (loginType=0, verifyCode)
    ↓
获取 Token + userId
```

**关键点:**
- 无独立注册接口，`/api/user/login` 同时处理注册和登录
- `loginType: 0` = 验证码模式, `loginType: 1` = 密码模式
- `checkEmail.data=true` 不是已注册；密码登录接口返回 `User not registered` 才说明未完成注册
- 密码使用 MD5 哈希
- `mobilePhone` 字段实际上接受邮箱地址

---

## 1. 检查邮箱

```
GET /api/user/checkEmail?mobilePhone={email}
```

**Headers:** 通用请求头 (userId=0)

**响应:**
```json
{
  "code": 200,
  "data": true,     // true=可继续验证码登录/注册流程（不是“已注册”）
  "2fa": false      // 是否启用了2FA
}
```

---

## 2. 阿里云滑块验证码

**SDK:** `https://o.alicdn.com/captcha-frontend/aliyunCaptcha/AliyunCaptcha.js`

**配置:**
```javascript
initAliyunCaptcha({
  SceneId: "5jvar3wp",
  prefix: "69r0rc",
  mode: "popup",
  region: "sgp",
  element: "#captcha-element",
  slideStyle: { width: 360, height: 40 },
  captchaVerifyCallback: async (captchaVerifyParam) => {
    // 用 captchaVerifyParam 调用 smsSend
  }
});
```

**关键:** captchaVerifyParam 无法伪造，必须通过阿里云服务器验证后生成。推荐使用浏览器自动化解决。

---

## 3. 发送验证码

```
POST /api/sms/smsSend
```

**Request Body:**
```json
{
  "smsType": 2,
  "mobilePhone": "user@example.com",
  "captchaVerifyParam": "<阿里云验证码token>"
}
```

**注意:** 此请求建议使用最少 Headers（Content-Type + User-Agent），多余的 Headers 可能导致阿里云签名验证失败。

**响应:**
```json
{
  "code": 200,
  "data": {
    "isRegister": false   // false=新用户, true=已注册
  }
}
```

---

## 4. 登录/注册

```
POST /api/user/login
```

### 验证码登录/注册
```json
{
  "mobilePhone": "user@example.com",
  "loginType": 0,
  "verifyCode": "123456",
  "password": "<MD5 hash>",
  "channel": ""
}
```

### 密码登录
```json
{
  "mobilePhone": "user@example.com",
  "loginType": 1,
  "password": "<MD5 hash>",
  "channel": ""
}
```

**2FA 验证码 (如启用):**
```json
{
  "mobilePhone": "user@example.com",
  "loginType": 0,
  "verifyCode": "123456",
  "code": "<2FA验证码>",
  "channel": ""
}
```

**响应:**
```json
{
  "code": 200,
  "data": {
    "token": "...",
    "userId": 12345,
    "isRegister": true
  }
}
```

---

## 5. 第三方登录

### Google 登录
```
POST /api/user/googleLogin
```
```json
{
  "loginType": 6,
  "acctoken": "<Google access_token>",
  "tempCode": "<state中的code>",
  "channel": "web"
}
```

**Google OAuth 配置:**
- client_id: `1080357856969-q0fgj24pd2csvqdm0ksg61msuojir4jj.apps.googleusercontent.com`
- redirect_uri: `https://cloud.vmoscloud.com/login/google`

### Facebook 登录
```
POST /api/user/facebookLogin
```
```json
{
  "loginType": 7,
  "acctoken": "<Facebook access_token>",
  "tempCode": "<state中的code>",
  "channel": "web"
}
```

**Facebook OAuth 配置:**
- client_id: `856047963242901`
- redirect_uri: `https://cloud.vmoscloud.com/login/facebook`

### Kakao 登录
```
POST /api/user/kakaologin
```
```json
{
  "loginType": 6,
  "acctoken": "<Kakao code>",
  "tempCode": "<state中的code>",
  "channel": "web",
  "redirectUri": "<redirect_uri>"
}
```

---

## 6. 用户相关 API

| API | 方法 | 说明 |
|-----|------|------|
| `/api/user/getUserInfo` | GET | 获取用户信息 |
| `/api/user/modifyNickname` | GET | 修改昵称 (params: nickname) |
| `/api/user/updateUserPassword` | POST | 设置/更新密码 |
| `/api/user/updateUserPasswordV2` | POST | 设置密码 V2 |
| `/api/user/changeBindingMobile` | POST | 换绑手机号 |
| `/api/user/logoutUser` | POST | 退出登录 |
| `/api/user/checkReceiveEquipment` | GET | 检查设备接收状态 |
| `/api/user/updateUserLocale` | GET | 更新语言设置 |

---

## 7. 2FA 相关 API

| API | 方法 | 说明 |
|-----|------|------|
| `/api/vcGoogle2fa/status` | GET | 2FA 状态 |
| `/api/vcGoogle2fa/generateSecret` | GET | 生成 2FA 密钥 |
| `/api/vcGoogle2fa/verifyGoogle2fa` | POST | 验证 Google 2FA |
| `/api/vcGoogle2fa/verifySmsCode` | POST | 验证短信验证码 |
| `/api/vcGoogle2fa/closeGoogle2fa` | POST | 关闭 2FA |
| `/api/vcGoogle2fa/unbindGoogle2fa` | POST | 解绑 2FA |

---

## 8. 新用户引导 API

| API | 方法 | 说明 |
|-----|------|------|
| `/api/newUserGuide/getNewUserGuideConfig_V2` | GET | 新用户引导配置 |
| `/api/newUserGuide/getUserReceiveEquipment` | POST | 领取新用户免费设备 (需 captchaVerifyParam) |
| `/api/newUserGuide/getCountryList` | GET | 国家列表 |

---

## 9. 其他 API

| API | 方法 | 说明 |
|-----|------|------|
| `/api/configure/getSystemDicts` | GET | 系统字典配置 |
| `/api/vcCloudGood/getGoodMonthListNew` | GET | 云手机套餐列表 |
| `/api/vcAndroid/getAndroidVersion` | GET | Android 版本列表 |
| `/api/order/createMoneyOrder` | POST | 创建订单 |
| `/api/userEquipment/authorizeOtherUser` | POST | 授权其他用户 |
| `/api/userEquipment/getLastPermission` | GET | 获取最近权限 |
| `/api/padManage/padScreenshotsNew` | POST | 云手机截图 |

---

## 与 OwlProxy 的对比

| 项目 | VMOS Cloud | OwlProxy |
|------|-----------|----------|
| **Base URL** | `https://api.vmoscloud.com/vcpcloud` | `https://api.owlproxy.com/owlproxy` |
| **前端 URL** | `https://cloud.vmoscloud.com` | `https://proxy.owlproxy.com` |
| **appVersion** | `3.6.1800` | `2.6.1502` |
| **X-Tenant** | `vmoscloud` | 未使用 |
| **验证码 SceneId** | `5jvar3wp` | `5jvar3wp` ✅ 相同 |
| **验证码 prefix** | `69r0rc` | `69r0rc` ✅ 相同 |
| **验证码 region** | `sgp` | `sgp` ✅ 相同 |
| **密码哈希** | MD5 | MD5 ✅ 相同 |
| **注册方式** | 验证码登录即注册 | 验证码登录即注册 ✅ 相同 |
| **核心产品** | 云手机 | 代理服务 |
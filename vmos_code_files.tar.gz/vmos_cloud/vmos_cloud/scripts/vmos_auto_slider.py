#!/usr/bin/env python3
"""VMOS Cloud — Browser automation with realistic trajectory simulation.

Uses Playwright to:
1. Open VMOS Cloud registration page
2. Auto-fill email
3. Generate realistic human-like slider drag trajectory
4. Use CDP to dispatch trusted mouse events (isTrusted=true)
5. Intercept captchaVerifyParam from smsSend request
6. Auto-complete registration (YYDS email polling + API calls)

The key insight: the 'data' field in captchaVerifyParam is SERVER-ISSUED by Aliyun.
We cannot forge it. But we CAN make Aliyun issue a VALID data token by:
- Using trusted (isTrusted=true) mouse events via CDP
- Generating realistic human-like drag trajectories
- Avoiding detection heuristics (straight lines, uniform speed, no jitter)
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import math
import random
import re
import secrets
import string
import sys
import time
from pathlib import Path
from typing import Any

import requests

# ── Config ─────────────────────────────────────────────────────────────

API_BASE = "https://api.vmoscloud.com/vcpcloud"
FRONTEND_URL = "https://cloud.vmoscloud.com"
YYDS_BASE = "https://maliapi.215.im/v1"
ACCOUNTS_DIR = Path(__file__).resolve().parent.parent / "accounts"
DEFAULT_PASSWORD = "VmosCloud123!"
YYDS_KEY = "AC-29e9b09c5ae93e1347debb66"

# ── Helpers ────────────────────────────────────────────────────────────


def md5_password(p: str) -> str:
    return hashlib.md5(p.encode()).hexdigest()


def vmos_headers(token: str | None = None) -> dict[str, str]:
    h = {
        "Content-Type": "application/json",
        "Accept-Language": "en",
        "clientType": "web",
        "appVersion": "3.6.1800",
        "requestsource": "wechat-miniapp",
        "SupplierType": "0",
        "X-Tenant": "vmoscloud",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    }
    if token:
        h["Token"] = token
    return h


# ── YYDS Email ─────────────────────────────────────────────────────────


def create_email_yyds(domain: str | None = None) -> tuple[str, str, str]:
    headers = {"X-API-Key": YYDS_KEY, "Content-Type": "application/json"}
    if not domain:
        resp = requests.get(f"{YYDS_BASE}/domains", headers={"X-API-Key": YYDS_KEY}, timeout=15)
        data = resp.json()
        domains = []
        for x in (data.get("data") or []):
            recs = x.get("dnsRecords", {}) or {}
            if (x.get("isPublic") and x.get("isVerified") and x.get("isMxValid")
                    and recs.get("receivingReady") and recs.get("status") == "healthy"):
                domains.append(x["domain"])
        if not domains:
            domains = ["a0.engineer"]
        domain = random.choice(domains)

    local = f"vmos{int(time.time())}{random.randint(10, 99)}"
    resp = requests.post(
        f"{YYDS_BASE}/accounts",
        headers=headers,
        json={"localPart": local, "domain": domain},
        timeout=15,
    )
    result = resp.json()
    if not result.get("success"):
        raise RuntimeError(f"YYDS create failed: {result}")
    return result["data"]["address"], local, domain


def poll_yyds_code(email: str, timeout_s: int = 180, interval: int = 5) -> str | None:
    headers = {"X-API-Key": YYDS_KEY}
    deadline = time.time() + timeout_s
    attempt = 0
    while time.time() < deadline:
        attempt += 1
        time.sleep(interval)
        try:
            resp = requests.get(
                f"{YYDS_BASE}/messages",
                params={"address": email},
                headers=headers,
                timeout=15,
            )
            data = resp.json()
            messages = (data.get("data") or {}).get("messages") or []
            if not messages:
                print(f"  📬 Poll {attempt}: no messages yet...")
                continue
            for msg in messages:
                mid = msg.get("id")
                if not mid:
                    continue
                try:
                    full = requests.get(
                        f"{YYDS_BASE}/messages/{mid}",
                        params={"address": email},
                        headers=headers,
                        timeout=15,
                    ).text
                    codes = re.findall(r"\b(\d{6})\b", full)
                    if codes:
                        code = codes[0]
                        print(f"  ✅ Found verification code: {code}")
                        return code
                except Exception as e:
                    print(f"  ⚠️  Error reading message {mid}: {e}")
            print(f"  📬 Poll {attempt}: messages found but no 6-digit code yet...")
        except Exception as e:
            print(f"  ⚠️  Poll {attempt} error: {e}")
    return None


# ── VMOS Cloud API ─────────────────────────────────────────────────────


def send_sms(email: str, captcha_verify_param: str) -> dict[str, Any]:
    url = f"{API_BASE}/api/sms/smsSend"
    payload = {
        "smsType": 2,
        "mobilePhone": email,
        "captchaVerifyParam": captcha_verify_param,
    }
    headers = vmos_headers()
    print(f"\n📱 Sending SMS to {email}...")
    print(f"   captchaVerifyParam length: {len(captcha_verify_param)} chars")
    resp = requests.post(url, json=payload, headers=headers, timeout=30)
    result = resp.json()
    code = result.get("code")
    if code == 200:
        print(f"   ✅ SMS sent successfully!")
    else:
        print(f"   ❌ SMS failed: code={code} message={result.get('message', '')}")
    return result


def login_register(email: str, password: str, verify_code: str, *, channel: str = "") -> dict[str, Any]:
    url = f"{API_BASE}/api/user/login"
    payload = {
        "mobilePhone": email,
        "loginType": 0,
        "verifyCode": verify_code,
        "password": md5_password(password),
        "channel": channel,
    }
    headers = vmos_headers()
    print(f"\n🔑 Registering {email}...")
    resp = requests.post(url, json=payload, headers=headers, timeout=30)
    result = resp.json()
    code = result.get("code")
    if code == 200:
        data = result.get("data") or {}
        print(f"   ✅ Registration successful!")
        print(f"   userId: {data.get('userId')}")
    else:
        print(f"   ❌ Registration failed: {result}")
    return result


def get_user_info(token: str) -> dict[str, Any]:
    url = f"{API_BASE}/api/user/getUserInfo"
    headers = vmos_headers(token=token)
    resp = requests.get(url, headers=headers, timeout=30)
    return resp.json()


def save_account(email: str, password: str, token: str, user_info: dict) -> Path:
    ACCOUNTS_DIR.mkdir(parents=True, exist_ok=True)
    account = {
        "email": email,
        "password": password,
        "password_md5": md5_password(password),
        "token": token,
        "userId": (user_info.get("data") or {}).get("userId"),
        "platform": "vmos_cloud",
        "created_at": int(time.time()),
    }
    out_file = ACCOUNTS_DIR / f"{email}.json"
    out_file.write_text(json.dumps(account, ensure_ascii=False, indent=2), encoding="utf-8")
    return out_file


# ── Trajectory Generation ──────────────────────────────────────────────


def generate_human_trajectory(
    start_x: float,
    start_y: float,
    end_x: float,
    end_y: float,
    duration_ms: int = 800,
) -> list[dict]:
    """Generate a realistic human-like slider drag trajectory.

    Uses bezier curves for natural movement with:
    - Variable speed (acceleration at start, deceleration at end)
    - Y-axis micro-jitter (human hands tremble)
    - Occasional micro-pauses
    - Overshoot + correction at the end
    """
    points = []

    # Phase 1: Acceleration (0-30% of distance)
    # Phase 2: Constant speed (30-70%)
    # Phase 3: Deceleration (70-90%)
    # Phase 4: Overshoot + correction (90-100%)

    total_distance = end_x - start_x
    num_points = random.randint(25, 40)  # Realistic number of move events

    # Bezier control points for natural curve
    ctrl_y_offset = random.uniform(-3, 3)  # Slight vertical deviation

    # Overshoot parameters
    overshoot = random.uniform(3, 8)
    correction_steps = random.randint(2, 4)

    # Generate main movement points using bezier-like interpolation
    t_values = []
    for i in range(num_points):
        # Ease-in-out distribution (more points at start and end)
        t = i / (num_points - 1)
        # Apply easing: slow start, fast middle, slow end
        t_eased = t * t * (3 - 2 * t)  # smoothstep
        t_values.append(t_eased)

    # Generate x coordinates
    x_coords = []
    for t in t_values:
        x = start_x + total_distance * t
        x_coords.append(x)

    # Add overshoot at the end
    peak_x = end_x + overshoot
    for i in range(1, correction_steps + 1):
        x_coords.append(peak_x - (overshoot * i / correction_steps))

    # Generate y coordinates with natural jitter
    y_coords = []
    for i, t in enumerate(t_values):
        # Base y: slight curve through bezier
        y = start_y + (end_y - start_y) * t + ctrl_y_offset * math.sin(math.pi * t)
        # Add micro-jitter (human hand tremor)
        if i > 0 and i < len(t_values) - 1:
            y += random.gauss(0, 1.5)  # Gaussian noise
        y_coords.append(y)

    # Add correction y coords
    for i in range(correction_steps):
        y = end_y + random.gauss(0, 0.5)
        y_coords.append(y)

    # Generate timestamps
    base_time = int(time.time() * 1000)
    start_ts = base_time + random.randint(100, 300)  # Small delay before start

    # Build track list
    track_list = []

    # Mouse down event
    track_list.append({
        "type": "mc",  # mousedown
        "x": round(start_x, 2),
        "y": round(start_y, 2),
        "t": start_ts,
        "extra": random.randint(0, 1),
    })

    # Mouse move events
    current_ts = start_ts
    for i in range(len(x_coords)):
        # Variable time between events (faster in middle, slower at edges)
        if i == 0:
            dt = random.randint(20, 50)  # Initial reaction time
        elif i < num_points * 0.3:
            dt = random.randint(15, 35)  # Acceleration phase
        elif i < num_points * 0.7:
            dt = random.randint(10, 25)  # Fast middle
        elif i < num_points:
            dt = random.randint(20, 45)  # Deceleration
        else:
            dt = random.randint(30, 60)  # Correction

        current_ts += dt

        track_list.append({
            "type": "mm",  # mousemove
            "x": round(x_coords[i], 2),
            "y": round(y_coords[i], 2),
            "t": current_ts,
            "extra": random.randint(0, 2),
        })

    # Small pause at end (human reaction)
    current_ts += random.randint(50, 150)

    # Mouse up event
    track_list.append({
        "type": "mu",  # mouseup
        "x": round(end_x, 2),
        "y": round(end_y + random.gauss(0, 0.5), 2),
        "t": current_ts,
        "extra": random.randint(0, 1),
    })

    return track_list


# ── Browser Automation ──────────────────────────────────────────────────


async def auto_register(
    email: str,
    password: str,
    *,
    headless: bool = False,
    timeout: int = 180,
    email_timeout: int = 180,
    channel: str = "",
) -> dict[str, Any] | None:
    """Full auto-registration with realistic trajectory simulation."""

    from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError

    captured = {
        "captcha_token": None,
        "sms_request": None,
        "sms_response": None,
    }

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(
            headless=headless,
            args=[
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-dev-shm-usage",
                "--disable-blink-features=AutomationControlled",
            ],
        )
        context = await browser.new_context(
            viewport={"width": 1280, "height": 800},
            locale="en",
            timezone_id="America/New_York",
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        )
        page = await context.new_page()

        # ── Intercept network requests ────────────────────────────
        async def on_request(req):
            url = req.url
            if "/api/sms/smsSend" in url:
                try:
                    post_data = req.post_data
                    if post_data:
                        body = json.loads(post_data)
                        token = body.get("captchaVerifyParam", "")
                        if token and len(token) > 50:
                            captured["captcha_token"] = token
                            captured["sms_request"] = {
                                "url": url,
                                "mobilePhone": body.get("mobilePhone"),
                                "smsType": body.get("smsType"),
                            }
                            print(f"\n✅ [Intercepted] smsSend request captured")
                            print(f"   captchaVerifyParam: {len(token)} chars")
                except Exception as e:
                    print(f"   ⚠️  Request capture error: {e}")

        async def on_response(resp):
            url = resp.url
            if "/api/sms/smsSend" in url:
                try:
                    body = await resp.text()
                    captured["sms_response"] = {"status": resp.status, "body": body}
                    resp_data = json.loads(body) if body else {}
                    code = resp_data.get("code")
                    if code == 200:
                        print(f"   ✅ smsSend response: code=200 SUCCESS")
                    else:
                        print(f"   ❌ smsSend response: code={code} message={resp_data.get('message', '')}")
                except Exception as e:
                    print(f"   ⚠️  Response capture error: {e}")

        page.on("request", on_request)
        page.on("response", on_response)

        # ── Navigate ───────────────────────────────────────────────
        print(f"\n🌐 Opening VMOS Cloud...")
        await page.goto(FRONTEND_URL, wait_until="networkidle", timeout=60000)
        await asyncio.sleep(2)

        # ── Fill email ──────────────────────────────────────────────
        print(f"\n📧 Filling email: {email}")
        email_selectors = [
            'input[placeholder*="email"]',
            'input[placeholder*="Email"]',
            'input[placeholder*="邮箱"]',
            'input[placeholder*="请输入"]',
            'input[type="email"]',
            'input[type="text"]',
        ]
        filled = False
        for sel in email_selectors:
            try:
                el = await page.wait_for_selector(sel, timeout=3000)
                if el and await el.is_visible():
                    await el.fill(email)
                    filled = True
                    print(f"   Filled via {sel}")
                    break
            except PlaywrightTimeoutError:
                continue
        if not filled:
            print("   ⚠️  Could not auto-fill email. Please enter it manually.")
        await asyncio.sleep(1)

        # ── Click Login/Register ──────────────────────────────────
        print("🔑 Clicking Login/Register button...")
        btn_selectors = [
            'button:has-text("Login")',
            'button:has-text("Register")',
            'button:has-text("登录")',
            'button:has-text("注册")',
            'button:has-text("Login/Register")',
            'button:has-text("发送")',
            'button:has-text("Send")',
        ]
        clicked = False
        for sel in btn_selectors:
            try:
                el = await page.wait_for_selector(sel, timeout=3000)
                if el and await el.is_visible():
                    await el.click()
                    clicked = True
                    print(f"   Clicked {sel}")
                    break
            except PlaywrightTimeoutError:
                continue

        if not clicked:
            print("   ⚠️  Could not auto-click button. Please click Login/Register manually.")
        await asyncio.sleep(3)

        # ── Wait for CAPTCHA slider ────────────────────────────────
        print("\n🔍 Waiting for CAPTCHA slider...")
        await page.screenshot(path="/tmp/vmos_captcha_step1.png")

        # Try to find the slider element
        slider_selectors = [
            '#aliyunCaptcha-btn-slider',
            '.aliyunCaptcha-btn-slider',
            '#aliyunCaptcha-slider-btn',
            '.aliyunCaptcha-slider-btn',
            '[id*="slider"]',
            '[class*="slider"]',
            '[id*="btn"]',
        ]

        slider = None
        for sel in slider_selectors:
            try:
                slider = await page.wait_for_selector(sel, timeout=5000)
                if slider and await slider.is_visible():
                    print(f"   Found slider: {sel}")
                    break
            except PlaywrightTimeoutError:
                continue

        if not slider:
            print("   ⚠️  Could not find slider element automatically.")
            print("   The CAPTCHA may need to be triggered differently.")
            print("   Please solve the CAPTCHA manually if needed.")
        else:
            # ── Solve the slider ───────────────────────────────────
            print("\n🎯 Attempting to solve slider CAPTCHA...")

            # Get slider position
            box = await slider.bounding_box()
            if box:
                start_x = box["x"] + box["width"] / 2
                start_y = box["y"] + box["height"] / 2
                print(f"   Slider position: ({start_x:.0f}, {start_y:.0f})")

                # Get the CAPTCHA background width to determine drag distance
                bg_selectors = [
                    '#aliyunCaptcha-bg',
                    '.aliyunCaptcha-bg',
                    '#aliyunCaptcha-window-embed',
                    '.aliyunCaptcha-window',
                ]
                drag_distance = 280  # Default

                for bg_sel in bg_selectors:
                    try:
                        bg = await page.query_selector(bg_sel)
                        if bg:
                            bg_box = await bg.bounding_box()
                            if bg_box:
                                drag_distance = int(bg_box["width"] - box["width"] - 10)
                                print(f"   Drag distance: {drag_distance}px (from {bg_sel})")
                                break
                    except Exception:
                        continue

                # Add some randomness to the drag distance
                actual_distance = drag_distance + random.randint(-5, 5)

                # Generate trajectory
                trajectory = generate_human_trajectory(
                    start_x=start_x,
                    start_y=start_y,
                    end_x=start_x + actual_distance,
                    end_y=start_y,
                    duration_ms=random.randint(600, 1200),
                )

                # Execute the drag using CDP Input.dispatchMouseEvent for trusted events
                cdp = await page.context.new_cdp_session_for_page(page)

                # Mouse down
                await cdp.send("Input.dispatchMouseEvent", {
                    "type": "mousePressed",
                    "x": start_x,
                    "y": start_y,
                    "button": "left",
                    "clickCount": 1,
                })

                # Mouse moves
                for point in trajectory[1:-1]:  # Skip mousedown and mouseup
                    if point["type"] == "mm":
                        await cdp.send("Input.dispatchMouseEvent", {
                            "type": "mouseMoved",
                            "x": point["x"],
                            "y": point["y"],
                        })
                        # Variable delay between moves
                        await asyncio.sleep(random.uniform(0.008, 0.025))

                # Mouse up
                last_point = trajectory[-1]
                await cdp.send("Input.dispatchMouseEvent", {
                    "type": "mouseReleased",
                    "x": last_point["x"],
                    "y": last_point["y"],
                    "button": "left",
                    "clickCount": 1,
                })

                print(f"   Drag completed! Moved {actual_distance}px with {len(trajectory)} events")
                await asyncio.sleep(2)

        # ── Wait for captchaVerifyParam ─────────────────────────────
        print(f"\n⏳ Waiting for CAPTCHA completion (up to {timeout}s)...")

        deadline = time.time() + timeout
        while time.time() < deadline:
            if captured["captcha_token"] and captured["sms_response"]:
                break
            await asyncio.sleep(0.5)

        await page.screenshot(path="/tmp/vmos_captcha_step2.png")

        captcha_token = captured.get("captcha_token")
        sms_response = captured.get("sms_response")

        if not captcha_token:
            print("\n❌ No captchaVerifyParam captured.")
            print("   The automated slider may have failed anti-bot detection.")
            print("   Try running with --manual flag for manual CAPTCHA solving.")
            await browser.close()
            return None

        print(f"\n✅ captchaVerifyParam captured: {len(captcha_token)} chars")

        # Save token for potential reuse
        token_file = Path(f"/tmp/vmos_captcha_token_{int(time.time())}.txt")
        token_file.write_text(captcha_token)
        print(f"   Token saved to: {token_file}")

        # Check smsSend response
        sms_ok = False
        if sms_response:
            try:
                resp_data = json.loads(sms_response.get("body", ""))
                sms_ok = resp_data.get("code") == 200
            except Exception:
                pass

        if not sms_ok:
            print("   ⚠️  Browser smsSend may have failed. Trying via API...")
            retry_result = send_sms(email, captcha_token)
            if retry_result.get("code") == 200:
                sms_ok = True
            else:
                print(f"   ❌ API SMS send also failed: {retry_result}")

        await browser.close()

    # ── Poll for verification code ─────────────────────────────────
    print(f"\n📬 Polling YYDS for verification code (timeout: {email_timeout}s)...")
    verify_code = poll_yyds_code(email, timeout_s=email_timeout)

    if not verify_code:
        print("\n❌ Could not retrieve verification code from email.")
        print(f"   Email: {email}")
        print(f"   CaptchaVerifyParam saved to: {token_file}")
        return None

    # ── Register ────────────────────────────────────────────────────
    login_result = login_register(email, password, verify_code, channel=channel)

    if login_result.get("code") != 200:
        print(f"   ❌ Registration failed: {login_result}")
        return None

    data = login_result.get("data") or {}
    token = data.get("token", "")
    user_id = data.get("userId", "")

    user_info = {}
    if token:
        try:
            user_info = get_user_info(token)
        except Exception:
            pass

    out_file = save_account(email, password, token, user_info)

    print("\n" + "=" * 60)
    print("  🎉 REGISTRATION SUCCESSFUL!")
    print("=" * 60)
    print(f"  📧 Email:    {email}")
    print(f"  🔒 Password: {password}")
    print(f"  🆔 UserID:   {user_id}")
    print(f"  🔑 Token:    {token[:20]}..." if token else "  ⚠️  No token")
    print(f"  💾 Saved to:  {out_file}")
    print("=" * 60)

    return {
        "email": email,
        "password": password,
        "token": token,
        "user_id": user_id,
        "file": str(out_file),
    }


# ── Main ──────────────────────────────────────────────────────────────


def main():
    import argparse
    p = argparse.ArgumentParser(description="VMOS Cloud auto-registration with trajectory simulation")
    p.add_argument("--email", default=None, help="Email (auto-created if omitted)")
    p.add_argument("--password", default=DEFAULT_PASSWORD, help="Password")
    p.add_argument("--domain", default=None, help="YYDS email domain")
    p.add_argument("--headless", action="store_true", help="Run headless")
    p.add_argument("--timeout", type=int, default=180, help="CAPTCHA timeout (seconds)")
    p.add_argument("--email-timeout", type=int, default=180, help="Email poll timeout (seconds)")
    p.add_argument("--channel", default="", help="Channel parameter")
    args = p.parse_args()

    if args.email:
        email = args.email
    else:
        print("\n📧 Creating YYDS temp email...")
        email, _, _ = create_email_yyds(args.domain)
        print(f"   Email: {email}")

    asyncio.run(auto_register(
        email=email,
        password=args.password,
        headless=args.headless,
        timeout=args.timeout,
        email_timeout=args.email_timeout,
        channel=args.channel,
    ))


if __name__ == "__main__":
    main()
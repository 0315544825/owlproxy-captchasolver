#!/usr/bin/env python3
"""VMOS Cloud End-to-End Registration — Human CAPTCHA + Auto Everything Else.

Flow:
  1. Create YYDS temp email (or use provided)
  2. Open VMOS Cloud in visible browser
  3. Auto-fill email + click Login/Register
  4. Wait for user to manually solve slider CAPTCHA
  5. Intercept captchaVerifyParam from smsSend request
  6. Auto-poll YYDS for verification code
  7. Auto-complete registration via API
  8. Save account credentials

Usage:
    # Auto-create temp email:
    python3 vmos_register_e2e.py

    # Use specific email:
    python3 vmos_register_e2e.py --email you@example.com

    # Batch mode (create N accounts):
    python3 vmos_register_e2e.py --count 3

    # Headless (requires manual CAPTCHA via Live Screen):
    python3 vmos_register_e2e.py --headless

    # Retry from a saved captchaVerifyParam (skip browser):
    python3 vmos_register_e2e.py --email you@example.com --captcha-file /tmp/vmos_captchaVerifyParam.txt
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
import random
import re
import secrets
import string
import sys
import time
from pathlib import Path
from typing import Any

import requests
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError

# ── Config ─────────────────────────────────────────────────────────────

API_BASE = "https://api.vmoscloud.com/vcpcloud"
FRONTEND_URL = "https://cloud.vmoscloud.com"
YYDS_BASE = "https://maliapi.215.im/v1"
ACCOUNTS_DIR = Path(__file__).resolve().parent.parent / "accounts"
DEFAULT_PASSWORD = "VmosCloud123!"
CAPTCHA_TIMEOUT = 180  # seconds to wait for manual CAPTCHA solve
EMAIL_POLL_TIMEOUT = 180  # seconds to wait for verification code
EMAIL_POLL_INTERVAL = 5  # seconds between polls

# ── Selectors ──────────────────────────────────────────────────────────

EMAIL_SELECTORS = [
    'input[placeholder*="email"]',
    'input[placeholder*="Email"]',
    'input[placeholder*="邮箱"]',
    'input[placeholder*="请输入"]',
    'input[type="email"]',
]

CODE_INPUT_SELECTORS = [
    'input[type="number"]',
    'input[placeholder*="code"]',
    'input[placeholder*="Code"]',
    'input[placeholder*="验证码"]',
]

LOGIN_BTN_SELECTORS = [
    'button:has-text("Login")',
    'button:has-text("Register")',
    'button:has-text("登录")',
    'button:has-text("注册")',
    'button:has-text("Login/Register")',
]

# ── Helpers ────────────────────────────────────────────────────────────


def md5_password(p: str) -> str:
    return hashlib.md5(p.encode()).hexdigest()


def make_password() -> str:
    alphabet = string.ascii_letters + string.digits
    core = "".join(secrets.choice(alphabet) for _ in range(14))
    return f"Vc{core}!9"


def vmos_headers(token: str | None = None) -> dict[str, str]:
    h = {
        "Content-Type": "application/json",
        "Accept-Language": "en",
        "clientType": "web",
        "appVersion": "3.6.1800",
        "requestsource": "wechat-miniapp",
        "SupplierType": "0",
        "X-Tenant": "vmoscloud",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    }
    if token:
        h["Token"] = token
    return h


# ── YYDS Email ─────────────────────────────────────────────────────────


def load_yyds_key() -> str:
    for name in ("YYDS_KEY", "MALI_API_KEY"):
        val = os.getenv(name)
        if val:
            return val.strip()
    # Try loading from config file
    config_paths = [
        Path.home() / ".openclaw" / "workspace" / "vmos_cloud" / "yyds_key.txt",
        Path(__file__).resolve().parent.parent / "yyds_key.txt",
        Path.home() / ".yyds_key",
    ]
    for p in config_paths:
        if p.exists():
            key = p.read_text().strip()
            if key:
                return key
    # Fallback to hardcoded key (from previous scripts)
    return "AC-29e9b09c5ae93e1347debb66"


def yyds_headers() -> dict[str, str]:
    return {"X-API-Key": load_yyds_key(), "Content-Type": "application/json"}


def create_email_yyds(domain: str | None = None) -> tuple[str, str, str]:
    """Create a YYDS temp email. Returns (address, local_part, domain)."""
    key = load_yyds_key()
    headers = {"X-API-Key": key, "Content-Type": "application/json"}

    if not domain:
        resp = requests.get(f"{YYDS_BASE}/domains", headers={"X-API-Key": key}, timeout=15)
        data = resp.json()
        domains = []
        for x in (data.get("data") or []):
            recs = x.get("dnsRecords", {}) or {}
            if (x.get("isPublic") and x.get("isVerified") and x.get("isMxValid")
                    and recs.get("receivingReady") and recs.get("status") == "healthy"):
                domains.append(x["domain"])
        if not domains:
            domains = ["a0.engineer"]
        domain = random.choice(domains)

    local = f"vmos{int(time.time())}{random.randint(10, 99)}"
    resp = requests.post(
        f"{YYDS_BASE}/accounts",
        headers=headers,
        json={"localPart": local, "domain": domain},
        timeout=15,
    )
    result = resp.json()
    if not result.get("success"):
        raise RuntimeError(f"YYDS create failed: {result}")
    return result["data"]["address"], local, domain


def poll_yyds_code(email: str, timeout_s: int = 180, interval: int = 5) -> str | None:
    """Poll YYDS for a 6-digit verification code."""
    key = load_yyds_key()
    headers = {"X-API-Key": key}
    deadline = time.time() + timeout_s
    attempt = 0

    while time.time() < deadline:
        attempt += 1
        time.sleep(interval)
        try:
            resp = requests.get(
                f"{YYDS_BASE}/messages",
                params={"address": email},
                headers=headers,
                timeout=15,
            )
            data = resp.json()
            messages = (data.get("data") or {}).get("messages") or []

            if not messages:
                print(f"  📬 Poll {attempt}: no messages yet...")
                continue

            for msg in messages:
                mid = msg.get("id")
                if not mid:
                    continue
                try:
                    full = requests.get(
                        f"{YYDS_BASE}/messages/{mid}",
                        params={"address": email},
                        headers=headers,
                        timeout=15,
                    ).text
                    # Look for 6-digit code
                    codes = re.findall(r"\b(\d{6})\b", full)
                    if codes:
                        code = codes[0]
                        print(f"  ✅ Found verification code: {code}")
                        return code
                except Exception as e:
                    print(f"  ⚠️  Error reading message {mid}: {e}")
                    continue

            print(f"  📬 Poll {attempt}: messages found but no 6-digit code yet...")

        except Exception as e:
            print(f"  ⚠️  Poll {attempt} error: {e}")

    return None


# ── VMOS Cloud API ─────────────────────────────────────────────────────


def check_email(email: str) -> dict[str, Any]:
    """Check if email is already registered."""
    url = f"{API_BASE}/api/user/checkEmail"
    params = {"mobilePhone": email}
    resp = requests.get(url, params=params, headers=vmos_headers(), timeout=30)
    return resp.json()


def send_sms(email: str, captcha_verify_param: str) -> dict[str, Any]:
    """Send verification code via smsSend API."""
    url = f"{API_BASE}/api/sms/smsSend"
    payload = {
        "smsType": 2,
        "mobilePhone": email,
        "captchaVerifyParam": captcha_verify_param,
    }
    headers = {
        "Content-Type": "application/json",
        "Accept-Language": "en",
        "clientType": "web",
        "appVersion": "3.6.1800",
        "requestsource": "wechat-miniapp",
        "SupplierType": "0",
        "X-Tenant": "vmoscloud",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    }
    print(f"\n📱 Sending SMS to {email}...")
    print(f"   captchaVerifyParam length: {len(captcha_verify_param)} chars")
    resp = requests.post(url, json=payload, headers=headers, timeout=30)
    result = resp.json()
    code = result.get("code")
    if code == 200:
        print(f"   ✅ SMS sent successfully!")
        is_register = (result.get("data") or {}).get("isRegister")
        if is_register is not None:
            print(f"   isRegister: {is_register}")
    else:
        print(f"   ❌ SMS failed: {result}")
    return result


def login_register(email: str, password: str, verify_code: str, *, channel: str = "") -> dict[str, Any]:
    """Login or register with verification code."""
    url = f"{API_BASE}/api/user/login"
    payload = {
        "mobilePhone": email,
        "loginType": 0,
        "verifyCode": verify_code,
        "password": md5_password(password),
        "channel": channel,
    }
    headers = vmos_headers()
    print(f"\n🔑 Registering {email}...")
    resp = requests.post(url, json=payload, headers=headers, timeout=30)
    result = resp.json()
    code = result.get("code")
    if code == 200:
        data = result.get("data") or {}
        print(f"   ✅ Registration successful!")
        print(f"   userId: {data.get('userId')}")
        print(f"   isRegister: {data.get('isRegister')}")
    else:
        print(f"   ❌ Registration failed: {result}")
    return result


def get_user_info(token: str) -> dict[str, Any]:
    """Get user info with auth token."""
    url = f"{API_BASE}/api/user/getUserInfo"
    headers = vmos_headers(token=token)
    resp = requests.get(url, headers=headers, timeout=30)
    return resp.json()


def save_account(email: str, password: str, token: str, user_info: dict) -> Path:
    """Save account credentials to JSON file."""
    ACCOUNTS_DIR.mkdir(parents=True, exist_ok=True)
    account = {
        "email": email,
        "password": password,
        "password_md5": md5_password(password),
        "token": token,
        "userId": (user_info.get("data") or {}).get("userId"),
        "platform": "vmos_cloud",
        "created_at": int(time.time()),
    }
    out_file = ACCOUNTS_DIR / f"{email}.json"
    out_file.write_text(json.dumps(account, ensure_ascii=False, indent=2), encoding="utf-8")
    return out_file


# ── Browser Automation ─────────────────────────────────────────────────


async def intercept_captcha_and_register(
    email: str,
    password: str,
    *,
    headless: bool = False,
    timeout: int = CAPTCHA_TIMEOUT,
    email_timeout: int = EMAIL_POLL_TIMEOUT,
    existing_token: str | None = None,
    channel: str = "",
    skip_browser: bool = False,
) -> dict[str, Any] | None:
    """
    Full end-to-end registration flow:
    1. Open browser, fill email, trigger CAPTCHA
    2. Wait for user to solve CAPTCHA
    3. Intercept captchaVerifyParam from smsSend
    4. Send SMS (if browser didn't already)
    5. Poll for verification code
    6. Complete registration
    """

    if skip_browser and existing_token:
        # Skip browser entirely — use existing captchaVerifyParam
        print(f"\n🔑 Using existing captchaVerifyParam ({len(existing_token)} chars)")
        sms_result = send_sms(email, existing_token)
        if sms_result.get("code") != 200:
            print(f"   ❌ SMS send failed with code {sms_result.get('code')}: {sms_result.get('message')}")
            # Check if code was already sent from browser
            if "already" in str(sms_result.get("message", "")).lower() or sms_result.get("code") in (400, 429):
                print("   ⚠️  Code may have already been sent, continuing to poll...")
            else:
                return None
    elif not skip_browser:
        # ── Step 1-2: Browser + CAPTCHA ──────────────────────────────
        captured = {
            "captcha_token": None,
            "sms_request": None,
            "sms_response": None,
            "check_email_response": None,
        }

        async with async_playwright() as pw:
            browser = await pw.chromium.launch(
                headless=headless,
                args=[
                    "--no-sandbox",
                    "--disable-setuid-sandbox",
                    "--disable-dev-shm-usage",
                    "--disable-blink-features=AutomationControlled",
                ],
            )
            context = await browser.new_context(
                viewport={"width": 1280, "height": 800},
                locale="en",
                timezone_id="America/New_York",
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            )
            page = await context.new_page()

            # ── Intercept network requests ────────────────────────────
            async def on_request(req):
                url = req.url
                if "/api/sms/smsSend" in url:
                    try:
                        post_data = req.post_data
                        if post_data:
                            body = json.loads(post_data)
                            token = body.get("captchaVerifyParam", "")
                            if token and len(token) > 100:
                                captured["captcha_token"] = token
                                captured["sms_request"] = {
                                    "url": url,
                                    "method": req.method,
                                    "mobilePhone": body.get("mobilePhone"),
                                    "smsType": body.get("smsType"),
                                    "captchaVerifyParam_len": len(token),
                                }
                                print(f"\n✅ [Intercepted] smsSend request captured")
                                print(f"   captchaVerifyParam: {len(token)} chars")
                    except Exception as e:
                        print(f"   ⚠️  Request capture error: {e}")

                if "/api/user/checkEmail" in url:
                    try:
                        captured["check_email_response"] = {"url": url}
                        print(f"\n✅ [Intercepted] checkEmail request")
                    except Exception:
                        pass

            async def on_response(resp):
                url = resp.url
                if "/api/sms/smsSend" in url:
                    try:
                        body = await resp.text()
                        captured["sms_response"] = {
                            "status": resp.status,
                            "body": body,
                        }
                        resp_data = json.loads(body) if body else {}
                        code = resp_data.get("code")
                        msg = resp_data.get("message", "")
                        if code == 200:
                            print(f"   ✅ smsSend response: code=200 SUCCESS")
                        else:
                            print(f"   ❌ smsSend response: code={code} message={msg}")
                    except Exception as e:
                        print(f"   ⚠️  Response capture error: {e}")

            page.on("request", on_request)
            page.on("response", on_response)

            # ── Navigate to VMOS Cloud ────────────────────────────────
            print(f"\n🌐 Opening VMOS Cloud...")
            await page.goto(FRONTEND_URL, wait_until="networkidle", timeout=60000)
            await asyncio.sleep(2)

            # Take screenshot for debugging
            await page.screenshot(path="/tmp/vmos_step1_loaded.png")
            print("   Page loaded")

            # ── Fill email ────────────────────────────────────────────
            print(f"\n📧 Filling email: {email}")
            filled = False
            for sel in EMAIL_SELECTORS:
                try:
                    await page.fill(sel, email, timeout=5000)
                    filled = True
                    print(f"   Filled via {sel}")
                    break
                except PlaywrightTimeoutError:
                    continue
            if not filled:
                # Try any visible text input
                try:
                    inputs = await page.query_selector_all('input[type="text"], input:not([type])')
                    for inp in inputs:
                        visible = await inp.is_visible()
                        if visible:
                            await inp.fill(email)
                            filled = True
                            print("   Filled via generic input")
                            break
                except Exception:
                    pass

            if not filled:
                print("   ⚠️  Could not auto-fill email. Please enter it manually in the browser.")
            await asyncio.sleep(1)

            # ── Click Login/Register ─────────────────────────────────
            print("🔑 Clicking Login/Register button...")
            clicked = False
            for sel in LOGIN_BTN_SELECTORS:
                try:
                    await page.click(sel, timeout=3000)
                    clicked = True
                    print(f"   Clicked {sel}")
                    break
                except PlaywrightTimeoutError:
                    continue
            if not clicked:
                # Try clicking any button
                try:
                    btn = await page.query_selector('button[type="submit"], button.primary, button')
                    if btn:
                        await btn.click()
                        clicked = True
                        print("   Clicked generic button")
                except Exception:
                    pass

            await asyncio.sleep(2)
            await page.screenshot(path="/tmp/vmos_step2_captcha.png")

            # ── Wait for manual CAPTCHA ──────────────────────────────
            print("\n" + "=" * 60)
            print("  👆 PLEASE SOLVE THE SLIDER CAPTCHA MANUALLY")
            print("  👆 Drag the slider to complete the puzzle")
            print("=" * 60)
            print(f"\n⏳ Waiting up to {timeout}s for CAPTCHA completion...")

            deadline = time.time() + timeout
            while time.time() < deadline:
                if captured["captcha_token"] and captured["sms_response"]:
                    # Both request and response captured
                    break
                await asyncio.sleep(0.5)

            # ── Process results ──────────────────────────────────────
            captcha_token = captured.get("captcha_token")
            sms_response = captured.get("sms_response")

            if not captcha_token:
                print("\n❌ No captchaVerifyParam captured. CAPTCHA may not have been completed.")
                print("   Check the browser window — did the slider solve correctly?")
                await page.screenshot(path="/tmp/vmos_captcha_timeout.png")
                await browser.close()
                return None

            print(f"\n✅ captchaVerifyParam captured: {len(captcha_token)} chars")

            # Save token for potential reuse
            token_file = Path(f"/tmp/vmos_captcha_token_{int(time.time())}.txt")
            token_file.write_text(captcha_token)
            print(f"   Token saved to: {token_file}")

            # Check smsSend response
            sms_ok = False
            if sms_response:
                resp_body = sms_response.get("body", "")
                try:
                    resp_data = json.loads(resp_body)
                    sms_ok = resp_data.get("code") == 200
                except Exception:
                    pass

            if sms_ok:
                print("   ✅ smsSend succeeded in browser — verification code should be sent!")
            else:
                print("   ⚠️  smsSend response indicates failure. Trying again via API...")
                # Retry SMS send via API
                retry_result = send_sms(email, captcha_token)
                if retry_result.get("code") == 200:
                    sms_ok = True
                    print("   ✅ API SMS send succeeded!")
                else:
                    print(f"   ❌ API SMS send also failed: {retry_result}")

            await browser.close()

    # ── Step 3: Use existing token if browser was skipped ────────────
    if skip_browser and existing_token:
        captcha_token = existing_token
        sms_ok = True  # Assume OK since we're retrying

    # ── Step 4: Poll for verification code ──────────────────────────
    print(f"\n📬 Polling YYDS for verification code (timeout: {email_timeout}s)...")
    verify_code = poll_yyds_code(email, timeout_s=email_timeout, interval=EMAIL_POLL_INTERVAL)

    if not verify_code:
        print("\n❌ Could not retrieve verification code from email.")
        print("   Check your email manually or try again.")
        print(f"   Email: {email}")
        print(f"   CaptchaVerifyParam saved to: {token_file if not skip_browser else 'N/A'}")
        return None

    # ── Step 5: Register ────────────────────────────────────────────
    print(f"\n🔑 Verifying code: {verify_code}")
    login_result = login_register(email, password, verify_code, channel=channel)

    if login_result.get("code") != 200:
        print(f"   ❌ Registration failed: {login_result}")
        return None

    data = login_result.get("data") or {}
    token = data.get("token", "")
    user_id = data.get("userId", "")

    # Get full user info
    user_info = {}
    if token:
        try:
            user_info = get_user_info(token)
        except Exception as e:
            print(f"   ⚠️  Could not fetch user info: {e}")

    # Save account
    out_file = save_account(email, password, token, user_info)

    print("\n" + "=" * 60)
    print("  🎉 REGISTRATION SUCCESSFUL!")
    print("=" * 60)
    print(f"  📧 Email:    {email}")
    print(f"  🔒 Password: {password}")
    print(f"  🆔 UserID:   {user_id}")
    print(f"  🔑 Token:    {token[:20]}..." if token else "  ⚠️  No token")
    print(f"  💾 Saved to:  {out_file}")
    print("=" * 60)

    return {
        "email": email,
        "password": password,
        "token": token,
        "user_id": user_id,
        "file": str(out_file),
    }


# ── Main ──────────────────────────────────────────────────────────────


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="VMOS Cloud end-to-end registration (human CAPTCHA + auto everything else)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Auto-create temp email:
  python3 vmos_register_e2e.py

  # Use specific email:
  python3 vmos_register_e2e.py --email you@example.com

  # Batch (3 accounts):
  python3 vmos_register_e2e.py --count 3

  # Retry with saved captchaVerifyParam (skip browser):
  python3 vmos_register_e2e.py --email you@example.com --captcha-file /tmp/vmos_captcha_token_1234.txt

  # Custom password:
  python3 vmos_register_e2e.py --password MyP@ss123
""",
    )
    p.add_argument("--email", default=None, help="Email address (auto-created if omitted)")
    p.add_argument("--password", default=None, help="Explicit password (auto-generated if omitted)")
    p.add_argument("--domain", default=None, help="YYDS email domain override")
    p.add_argument("--channel", default="", help="Channel parameter for registration")
    p.add_argument("--captcha-file", default=None, help="Path to saved captchaVerifyParam (skip browser)")
    p.add_argument("--captcha-timeout", type=int, default=CAPTCHA_TIMEOUT, help="Seconds to wait for manual CAPTCHA")
    p.add_argument("--email-timeout", type=int, default=EMAIL_POLL_TIMEOUT, help="Seconds to wait for email code")
    p.add_argument("--count", type=int, default=1, help="Number of accounts to register")
    p.add_argument("--retries", type=int, default=2, help="Retries per account on failure")
    p.add_argument("--headless", action="store_true", help="Run browser in headless mode")
    p.add_argument("--skip-sms", action="store_true", help="Skip SMS send step (if browser already sent it)")
    return p.parse_args()


async def register_one(args: argparse.Namespace, index: int = 1) -> dict[str, Any] | None:
    """Register a single account."""
    print(f"\n{'='*60}")
    print(f"  VMOS Cloud Registration #{index}")
    print(f"{'='*60}")

    # Step 0: Create or use email
    if args.email:
        email = args.email
        local = email.split("@")[0]
        domain = email.split("@")[1] if "@" in email else ""
        print(f"\n📧 Using provided email: {email}")
    elif args.captcha_file:
        # Need email for YYDS polling
        print("\n⚠️  --captcha-file requires --email")
        return None
    else:
        print("\n📧 Creating YYDS temp email...")
        email, local, domain = create_email_yyds(args.domain)
        print(f"   Email: {email}")

    password = args.password or DEFAULT_PASSWORD

    # Handle captcha file (skip browser)
    existing_token = None
    skip_browser = False
    if args.captcha_file:
        token_path = Path(args.captcha_file)
        if not token_path.exists():
            print(f"❌ Captcha file not found: {token_path}")
            return None
        existing_token = token_path.read_text().strip()
        skip_browser = True
        print(f"   Using captchaVerifyParam from file: {len(existing_token)} chars")

    # Run the full flow
    try:
        result = await intercept_captcha_and_register(
            email=email,
            password=password,
            headless=args.headless,
            timeout=args.captcha_timeout,
            email_timeout=args.email_timeout,
            existing_token=existing_token,
            channel=args.channel,
            skip_browser=skip_browser,
        )
        return result
    except Exception as e:
        print(f"\n❌ Registration failed: {e}")
        import traceback
        traceback.print_exc()
        return None


async def main() -> None:
    args = parse_args()
    results: list[dict[str, Any]] = []
    failed: int = 0

    for i in range(1, args.count + 1):
        success = False
        for attempt in range(1, args.retries + 1):
            print(f"\n🔄 Account {i}/{args.count}, attempt {attempt}/{args.retries}")
            result = await register_one(args, index=i)
            if result:
                results.append(result)
                success = True
                break
            if attempt < args.retries:
                wait = 5 * attempt
                print(f"   ⏳ Waiting {wait}s before retry...")
                await asyncio.sleep(wait)

        if not success:
            failed += 1
            print(f"   ❌ Account {i} failed after {args.retries} attempts")

    # Summary
    print("\n" + "=" * 60)
    print(f"  RESULTS: {len(results)}/{args.count} successful")
    if failed:
        print(f"  Failed: {failed}")
    print("=" * 60)
    for r in results:
        print(f"  ✅ {r['email']} → {r.get('file', 'N/A')}")
    if results:
        print("\n  Account details:")
        for r in results:
            print(f"    {r['email']} / {r['password']}")

    return results


if __name__ == "__main__":
    asyncio.run(main())
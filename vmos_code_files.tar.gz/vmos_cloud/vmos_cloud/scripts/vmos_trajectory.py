#!/usr/bin/env python3
"""VMOS Cloud — Trajectory Recording & Replay System

Instead of simulating trajectories (which get detected), this approach:
1. Records REAL human slider drags from a browser session
2. Stores the raw mouse event sequences with timing
3. Replays them with micro-randomization for each new attempt

This avoids the "too perfect" trajectory problem because we're starting
from genuine human movement data.

Usage:
    # Step 1: Record trajectories (opens browser, you drag slider manually)
    python3 vmos_trajectory.py record --count 10

    # Step 2: Replay with a recorded trajectory
    python3 vmos_trajectory.py replay --email auto

    # Step 3: Full auto with replay
    python3 vmos_trajectory.py auto --count 3
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import math
import os
import random
import re
import secrets
import string
import sys
import time
from pathlib import Path
from typing import Any

import requests

# ── Config ─────────────────────────────────────────────────────────────

API_BASE = "https://api.vmoscloud.com/vcpcloud"
FRONTEND_URL = "https://cloud.vmoscloud.com"
YYDS_BASE = "https://maliapi.215.im/v1"
ACCOUNTS_DIR = Path(__file__).resolve().parent.parent / "accounts"
TRAJECTORY_DIR = Path(__file__).resolve().parent.parent / "trajectories"
DEFAULT_PASSWORD = "VmosCloud123!"
YYDS_KEY = "AC-29e9b09c5ae93e1347debb66"

TRAJECTORY_DIR.mkdir(parents=True, exist_ok=True)


# ── Helpers ────────────────────────────────────────────────────────────

def md5_password(p: str) -> str:
    return hashlib.md5(p.encode()).hexdigest()


def vmos_headers(token: str | None = None) -> dict[str, str]:
    h = {
        "Content-Type": "application/json",
        "Accept-Language": "en",
        "clientType": "web",
        "appVersion": "3.6.1800",
        "requestsource": "wechat-miniapp",
        "SupplierType": "0",
        "X-Tenant": "vmoscloud",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    }
    if token:
        h["Token"] = token
    return h


def create_email_yyds(domain: str | None = None) -> tuple[str, str, str]:
    headers = {"X-API-Key": YYDS_KEY, "Content-Type": "application/json"}
    if not domain:
        resp = requests.get(f"{YYDS_BASE}/domains", headers={"X-API-Key": YYDS_KEY}, timeout=15)
        data = resp.json()
        domains = []
        for x in (data.get("data") or []):
            recs = x.get("dnsRecords", {}) or {}
            if (x.get("isPublic") and x.get("isVerified") and x.get("isMxValid")
                    and recs.get("receivingReady") and recs.get("status") == "healthy"):
                domains.append(x["domain"])
        if not domains:
            domains = ["a0.engineer"]
        domain = random.choice(domains)
    local = f"vmos{int(time.time())}{random.randint(10, 99)}"
    resp = requests.post(
        f"{YYDS_BASE}/accounts",
        headers=headers,
        json={"localPart": local, "domain": domain},
        timeout=15,
    )
    result = resp.json()
    if not result.get("success"):
        raise RuntimeError(f"YYDS create failed: {result}")
    return result["data"]["address"], local, domain


def poll_yyds_code(email: str, timeout_s: int = 180, interval: int = 5) -> str | None:
    headers = {"X-API-Key": YYDS_KEY}
    deadline = time.time() + timeout_s
    attempt = 0
    while time.time() < deadline:
        attempt += 1
        time.sleep(interval)
        try:
            resp = requests.get(
                f"{YYDS_BASE}/messages",
                params={"address": email},
                headers=headers,
                timeout=15,
            )
            data = resp.json()
            messages = (data.get("data") or {}).get("messages") or []
            if not messages:
                print(f"  📬 Poll {attempt}: no messages yet...")
                continue
            for msg in messages:
                mid = msg.get("id")
                if not mid:
                    continue
                try:
                    full = requests.get(
                        f"{YYDS_BASE}/messages/{mid}",
                        params={"address": email},
                        headers=headers,
                        timeout=15,
                    ).text
                    codes = re.findall(r"\b(\d{6})\b", full)
                    if codes:
                        print(f"  ✅ Found verification code: {codes[0]}")
                        return codes[0]
                except Exception as e:
                    print(f"  ⚠️  Error reading message {mid}: {e}")
            print(f"  📬 Poll {attempt}: messages found but no 6-digit code yet...")
        except Exception as e:
            print(f"  ⚠️  Poll {attempt} error: {e}")
    return None


def send_sms(email: str, captcha_verify_param: str) -> dict[str, Any]:
    url = f"{API_BASE}/api/sms/smsSend"
    payload = {"smsType": 2, "mobilePhone": email, "captchaVerifyParam": captcha_verify_param}
    resp = requests.post(url, json=payload, headers=vmos_headers(), timeout=30)
    return resp.json()


def login_register(email: str, password: str, verify_code: str, *, channel: str = "") -> dict[str, Any]:
    url = f"{API_BASE}/api/user/login"
    payload = {
        "mobilePhone": email,
        "loginType": 0,
        "verifyCode": verify_code,
        "password": md5_password(password),
        "channel": channel,
    }
    resp = requests.post(url, json=payload, headers=vmos_headers(), timeout=30)
    return resp.json()


def save_account(email: str, password: str, token: str, user_info: dict) -> Path:
    ACCOUNTS_DIR.mkdir(parents=True, exist_ok=True)
    account = {
        "email": email,
        "password": password,
        "password_md5": md5_password(password),
        "token": token,
        "userId": (user_info.get("data") or {}).get("userId"),
        "platform": "vmos_cloud",
        "created_at": int(time.time()),
    }
    out_file = ACCOUNTS_DIR / f"{email}.json"
    out_file.write_text(json.dumps(account, ensure_ascii=False, indent=2), encoding="utf-8")
    return out_file


# ── Trajectory Recording ───────────────────────────────────────────────


async def record_trajectories(count: int = 10, *, headless: bool = False):
    """Record real human slider trajectories by opening browser and having user solve CAPTCHA."""
    from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError

    trajectories = []
    email_idx = 0

    async with async_playwright() as pw:
        browser = await pw.chromium.launch(
            headless=headless,
            args=["--no-sandbox", "--disable-blink-features=AutomationControlled"],
        )
        context = await browser.new_context(
            viewport={"width": 1280, "height": 800},
            locale="en",
            timezone_id="America/New_York",
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        )

        for i in range(count):
            print(f"\n{'='*60}")
            print(f"  Recording trajectory {i+1}/{count}")
            print(f"  Please solve the slider CAPTCHA")
            print(f"{'='*60}")

            # Create a temp email for each attempt
            email, _, _ = create_email_yyds()
            print(f"  Email: {email}")

            page = await context.new_page()

            # Inject mouse event recorder BEFORE navigation
            captured_events = []

            await page.evaluate("""() => {
                window.__capturedMouseEvents = [];
                const record = (type, e) => {
                    window.__capturedMouseEvents.push({
                        type: type,
                        x: e.clientX,
                        y: e.clientY,
                        t: Date.now(),
                        isTrusted: e.isTrusted,
                    });
                };
                document.addEventListener('mousedown', (e) => record('mc', e), true);
                document.addEventListener('mousemove', (e) => record('mm', e), true);
                document.addEventListener('mouseup', (e) => record('mu', e), true);
                document.addEventListener('touchstart', (e) => {
                    const t = e.touches[0];
                    window.__capturedMouseEvents.push({
                        type: 'mc', x: t.clientX, y: t.clientY,
                        t: Date.now(), isTrusted: true
                    });
                }, true);
                document.addEventListener('touchmove', (e) => {
                    const t = e.touches[0];
                    window.__capturedMouseEvents.push({
                        type: 'mm', x: t.clientX, y: t.clientY,
                        t: Date.now(), isTrusted: true
                    });
                }, true);
                document.addEventListener('touchend', (e) => {
                    const t = e.changedTouches[0];
                    window.__capturedMouseEvents.push({
                        type: 'mu', x: t.clientX, y: t.clientY,
                        t: Date.now(), isTrusted: true
                    });
                }, true);
            }""")

            # Also intercept captchaVerifyParam
            captcha_token = None
            sms_ok = False

            async def on_request(req):
                nonlocal captcha_token
                if "/api/sms/smsSend" in req.url:
                    try:
                        body = json.loads(req.post_data or "{}")
                        token = body.get("captchaVerifyParam", "")
                        if token and len(token) > 50:
                            captcha_token = token
                    except Exception:
                        pass

            async def on_response(resp):
                nonlocal sms_ok
                if "/api/sms/smsSend" in resp.url:
                    try:
                        body = json.loads(await resp.text())
                        sms_ok = body.get("code") == 200
                    except Exception:
                        pass

            page.on("request", on_request)
            page.on("response", on_response)

            await page.goto(FRONTEND_URL, wait_until="networkidle", timeout=60000)
            await asyncio.sleep(2)

            # Fill email
            for sel in ['input[placeholder*="email"]', 'input[placeholder*="Email"]',
                        'input[type="email"]', 'input[type="text"]']:
                try:
                    el = await page.wait_for_selector(sel, timeout=3000)
                    if el and await el.is_visible():
                        await el.fill(email)
                        break
                except PlaywrightTimeoutError:
                    continue

            await asyncio.sleep(1)

            # Click login/register
            for sel in ['button:has-text("Login")', 'button:has-text("Register")',
                         'button:has-text("登录")', 'button:has-text("注册")',
                         'button:has-text("Send")', 'button:has-text("发送")']:
                try:
                    el = await page.wait_for_selector(sel, timeout=3000)
                    if el and await el.is_visible():
                        await el.click()
                        break
                except PlaywrightTimeoutError:
                    continue

            print(f"\n  👆 Please drag the slider to solve the CAPTCHA...")
            print(f"  ⏳ Waiting for CAPTCHA completion...")

            # Wait for CAPTCHA completion
            deadline = time.time() + 120
            while time.time() < deadline:
                if captcha_token and sms_ok:
                    break
                await asyncio.sleep(0.5)

            # Collect recorded mouse events
            try:
                raw_events = await page.evaluate("() => window.__capturedMouseEvents || []")
            except Exception:
                raw_events = []

            # Filter to slider-related events (look for the drag sequence)
            # A slider drag starts with mousedown on the slider, followed by mousemoves, ending with mouseup
            # Find the longest mousedown→mouseup sequence
            drag_sequence = extract_drag_sequence(raw_events)

            if drag_sequence and len(drag_sequence) > 5:
                trajectory = {
                    "timestamp": int(time.time()),
                    "email": email,
                    "captcha_token": captcha_token[:50] + "..." if captcha_token else None,
                    "sms_ok": sms_ok,
                    "total_events": len(raw_events),
                    "drag_events": len(drag_sequence),
                    "sequence": drag_sequence,
                    "metadata": {
                        "drag_distance": drag_sequence[-1]["x"] - drag_sequence[0]["x"] if drag_sequence else 0,
                        "drag_duration_ms": (drag_sequence[-1]["t"] - drag_sequence[0]["t"]) if len(drag_sequence) > 1 else 0,
                        "y_variance": calculate_y_variance(drag_sequence),
                        "avg_speed": calculate_avg_speed(drag_sequence),
                    }
                }
                trajectories.append(trajectory)

                # Save individual trajectory
                traj_file = TRAJECTORY_DIR / f"trajectory_{int(time.time())}_{i}.json"
                traj_file.write_text(json.dumps(trajectory, indent=2, ensure_ascii=False))

                print(f"\n  ✅ Trajectory recorded:")
                print(f"     Events: {len(drag_sequence)}")
                print(f"     Distance: {trajectory['metadata']['drag_distance']:.1f}px")
                print(f"     Duration: {trajectory['metadata']['drag_duration_ms']}ms")
                print(f"     Y variance: {trajectory['metadata']['y_variance']:.2f}")
                print(f"     Avg speed: {trajectory['metadata']['avg_speed']:.1f}px/s")
                if sms_ok:
                    print(f"     ✅ SMS sent successfully!")
                else:
                    print(f"     ❌ SMS send failed")
                print(f"     Saved to: {traj_file}")
            else:
                print(f"  ⚠️  No valid drag sequence captured ({len(raw_events)} raw events)")

            await page.close()

        await browser.close()

    # Save all trajectories
    summary_file = TRAJECTORY_DIR / f"batch_{int(time.time())}.json"
    summary_file.write_text(json.dumps(trajectories, indent=2, ensure_ascii=False))
    print(f"\n📊 Recorded {len(trajectories)}/{count} trajectories")
    print(f"   Saved to: {summary_file}")

    return trajectories


def extract_drag_sequence(events: list[dict]) -> list[dict]:
    """Extract the slider drag sequence from raw mouse events.

    A drag sequence is: mousedown → N × mousemove → mouseup
    where the mousedown is on or near the slider handle.
    """
    if not events:
        return []

    # Find all mousedown events
    mc_indices = [i for i, e in enumerate(events) if e["type"] == "mc"]
    if not mc_indices:
        return []

    best_sequence = []

    for mc_idx in mc_indices:
        # Find the corresponding mouseup
        mu_indices = [i for i in range(mc_idx + 1, len(events)) if events[i]["type"] == "mu"]
        if not mu_indices:
            continue

        mu_idx = mu_indices[0]
        sequence = events[mc_idx:mu_idx + 1]

        # Check if this looks like a slider drag (significant horizontal movement)
        x_start = sequence[0]["x"]
        x_end = sequence[-1]["x"]
        x_delta = abs(x_end - x_start)

        if x_delta > 50 and len(sequence) > 5:  # At least 50px and 7 events
            if len(sequence) > len(best_sequence):
                best_sequence = sequence

    # Normalize timestamps (start from 0)
    if best_sequence:
        t_start = best_sequence[0]["t"]
        for e in best_sequence:
            e["t"] = e["t"] - t_start

    return best_sequence


def calculate_y_variance(sequence: list[dict]) -> float:
    """Calculate Y-axis variance of the trajectory (indicator of human-like jitter)."""
    if not sequence:
        return 0
    ys = [e["y"] for e in sequence]
    mean_y = sum(ys) / len(ys)
    variance = sum((y - mean_y) ** 2 for y in ys) / len(ys)
    return variance ** 0.5  # Standard deviation


def calculate_avg_speed(sequence: list[dict]) -> float:
    """Calculate average drag speed in px/s."""
    if len(sequence) < 2:
        return 0
    total_dist = 0
    for i in range(1, len(sequence)):
        dx = sequence[i]["x"] - sequence[i-1]["x"]
        dy = sequence[i]["y"] - sequence[i-1]["y"]
        total_dist += (dx ** 2 + dy ** 2) ** 0.5
    total_time = (sequence[-1]["t"] - sequence[0]["t"]) / 1000  # Convert to seconds
    if total_time == 0:
        return 0
    return total_dist / total_time


# ── Trajectory Replay ──────────────────────────────────────────────────


def load_trajectory(path: str | None = None) -> dict | None:
    """Load a recorded trajectory for replay."""
    if path:
        p = Path(path)
        if p.exists():
            return json.loads(p.read_text())

    # Find the best trajectory from the library
    traj_files = list(TRAJECTORY_DIR.glob("trajectory_*.json"))
    if not traj_files:
        return None

    # Pick a random one with micro-variation
    chosen = random.choice(traj_files)
    data = json.loads(chosen.read_text())

    # If it's a list, pick one
    if isinstance(data, list):
        data = random.choice(data)

    return data


def mutate_trajectory(trajectory: dict, variation: float = 0.05) -> list[dict]:
    """Apply micro-randomization to a recorded trajectory.

    This preserves the overall shape and timing while introducing
    small variations to avoid exact-match detection.

    Args:
        trajectory: Recorded trajectory with 'sequence' key
        variation: Amount of randomization (0.0 = exact copy, 1.0 = completely random)
    """
    sequence = trajectory.get("sequence", [])
    if not sequence:
        return []

    mutated = []
    for i, event in enumerate(sequence):
        new_event = dict(event)

        # Add micro-jitter to x coordinates
        if event["type"] == "mm":
            new_event["x"] = event["x"] + random.gauss(0, variation * 2)
            new_event["y"] = event["y"] + random.gauss(0, variation * 3)

            # Slightly vary timing (±5-15ms per event)
            time_jitter = random.randint(-15, 15)
            new_event["t"] = max(0, event["t"] + time_jitter)

        mutated.append(new_event)

    return mutated


# ── Auto Registration with Replay ──────────────────────────────────────


async def auto_with_replay(
    email: str | None = None,
    password: str = DEFAULT_PASSWORD,
    trajectory_path: str | None = None,
    *,
    headless: bool = False,
    timeout: int = 180,
    email_timeout: int = 180,
    channel: str = "",
):
    """Open browser, replay recorded trajectory via CDP, intercept result."""
    from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError

    if not email:
        email, _, _ = create_email_yyds()
        print(f"\n📧 Created email: {email}")

    # Load and mutate a trajectory
    trajectory = load_trajectory(trajectory_path)
    if trajectory:
        sequence = mutate_trajectory(trajectory, variation=0.08)
        print(f"🎯 Loaded trajectory: {len(sequence)} events, mutating with ±8% variation")
    else:
        print("⚠️  No recorded trajectories found. Falling back to manual solve.")
        sequence = None

    captured = {"captcha_token": None, "sms_response": None}

    from playwright.async_api import async_playwright
    async with async_playwright() as pw:
        browser = await pw.chromium.launch(
            headless=headless,
            args=["--no-sandbox", "--disable-blink-features=AutomationControlled"],
        )
        context = await browser.new_context(
            viewport={"width": 1280, "height": 800},
            locale="en",
            timezone_id="America/New_York",
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        )
        page = await context.new_page()

        async def on_request(req):
            if "/api/sms/smsSend" in req.url:
                try:
                    body = json.loads(req.post_data or "{}")
                    token = body.get("captchaVerifyParam", "")
                    if token and len(token) > 50:
                        captured["captcha_token"] = token
                except Exception:
                    pass

        async def on_response(resp):
            if "/api/sms/smsSend" in resp.url:
                try:
                    body = json.loads(await resp.text())
                    captured["sms_response"] = {"code": body.get("code"), "message": body.get("message", "")}
                except Exception:
                    pass

        page.on("request", on_request)
        page.on("response", on_response)

        await page.goto(FRONTEND_URL, wait_until="networkidle", timeout=60000)
        await asyncio.sleep(2)

        # Fill email
        for sel in ['input[placeholder*="email"]', 'input[placeholder*="Email"]',
                     'input[type="email"]', 'input[type="text"]']:
            try:
                el = await page.wait_for_selector(sel, timeout=3000)
                if el and await el.is_visible():
                    await el.fill(email)
                    break
            except PlaywrightTimeoutError:
                continue
        await asyncio.sleep(1)

        # Click login/register
        for sel in ['button:has-text("Login")', 'button:has-text("Register")',
                     'button:has-text("登录")', 'button:has-text("Send")']:
            try:
                el = await page.wait_for_selector(sel, timeout=3000)
                if el and await el.is_visible():
                    await el.click()
                    break
            except PlaywrightTimeoutError:
                continue
        await asyncio.sleep(3)

        if sequence:
            # Find slider element
            slider = None
            for sel in ['#aliyunCaptcha-btn-slider', '.aliyunCaptcha-btn-slider',
                         '[id*="slider"]', '[class*="slider"]']:
                try:
                    slider = await page.wait_for_selector(sel, timeout=5000)
                    if slider and await slider.is_visible():
                        break
                except PlaywrightTimeoutError:
                    continue

            if slider:
                box = await slider.bounding_box()
                if box:
                    start_x = box["x"] + box["width"] / 2
                    start_y = box["y"] + box["height"] / 2

                    # Calculate scale factor (recorded screen may differ)
                    original_start_x = sequence[0]["x"]
                    original_start_y = sequence[0]["y"]
                    original_end_x = sequence[-1]["x"]

                    # Scale the trajectory to match current slider position
                    scale_x = 1.0  # We'll adjust the start position

                    cdp = await page.context.new_cdp_session_for_page(page)

                    # Mouse down at slider position
                    await cdp.send("Input.dispatchMouseEvent", {
                        "type": "mousePressed",
                        "x": start_x,
                        "y": start_y,
                        "button": "left",
                        "clickCount": 1,
                    })

                    # Replay trajectory with scaled coordinates
                    for i, event in enumerate(sequence):
                        if event["type"] == "mm":
                            # Scale coordinates relative to the start position
                            dx = event["x"] - original_start_x
                            dy = event["y"] - original_start_y
                            target_x = start_x + dx
                            target_y = start_y + dy

                            await cdp.send("Input.dispatchMouseEvent", {
                                "type": "mouseMoved",
                                "x": target_x,
                                "y": target_y,
                            })

                            # Match original timing
                            if i < len(sequence) - 1:
                                dt = sequence[i + 1]["t"] - event["t"]
                                await asyncio.sleep(max(0.005, dt / 1000))

                    # Mouse up
                    end_x = start_x + (sequence[-1]["x"] - original_start_x)
                    end_y = start_y + (sequence[-1]["y"] - original_start_y)
                    await cdp.send("Input.dispatchMouseEvent", {
                        "type": "mouseReleased",
                        "x": end_x,
                        "y": end_y,
                        "button": "left",
                        "clickCount": 1,
                    })

                    print(f"  ✅ Trajectory replayed: {len(sequence)} events")
                    await asyncio.sleep(3)
            else:
                print("  ⚠️  Slider not found, cannot replay trajectory")
        else:
            print("  👆 No trajectory available, please solve CAPTCHA manually")

        # Wait for result
        print(f"  ⏳ Waiting for CAPTCHA completion...")
        deadline = time.time() + timeout
        while time.time() < deadline:
            if captured["captcha_token"] and captured["sms_response"]:
                break
            await asyncio.sleep(0.5)

        captcha_token = captured.get("captcha_token")
        sms_resp = captured.get("sms_response")

        if captcha_token:
            print(f"  ✅ captchaVerifyParam captured: {len(captcha_token)} chars")
        else:
            print(f"  ❌ No captchaVerifyParam captured")

        if sms_resp:
            code = sms_resp.get("code")
            if code == 200:
                print(f"  ✅ SMS sent successfully!")
            else:
                print(f"  ❌ SMS failed: code={code} msg={sms_resp.get('message', '')}")

        await browser.close()

    # Continue with email polling and registration if we got the token
    if not captcha_token:
        print("\n❌ Cannot proceed without captchaVerifyParam")
        return None

    # If SMS wasn't sent in browser, try via API
    if not sms_resp or sms_resp.get("code") != 200:
        print("  Trying SMS send via API...")
        result = send_sms(email, captcha_token)
        if result.get("code") != 200:
            print(f"  ❌ API SMS also failed: {result}")
            return None

    # Poll for verification code
    print(f"\n📬 Polling for verification code...")
    verify_code = poll_yyds_code(email, timeout_s=email_timeout)
    if not verify_code:
        print("❌ Could not retrieve verification code")
        return None

    # Register
    login_result = login_register(email, password, verify_code, channel=channel)
    if login_result.get("code") != 200:
        print(f"❌ Registration failed: {login_result}")
        return None

    data = login_result.get("data") or {}
    token = data.get("token", "")
    user_id = data.get("userId", "")

    out_file = save_account(email, password, token, {})
    print(f"\n🎉 SUCCESS! Account: {email} / {password}")
    print(f"   Saved to: {out_file}")

    return {"email": email, "password": password, "token": token, "user_id": user_id}


# ── Main ──────────────────────────────────────────────────────────────


def main():
    parser = argparse.ArgumentParser(description="VMOS Cloud trajectory recording & replay")
    sub = parser.add_subparsers(dest="command")

    # Record
    rec = sub.add_parser("record", help="Record human slider trajectories")
    rec.add_argument("--count", type=int, default=5, help="Number of trajectories to record")
    rec.add_argument("--headless", action="store_true")

    # Replay
    rep = sub.add_parser("replay", help="Replay recorded trajectory")
    rep.add_argument("--email", default=None)
    rep.add_argument("--trajectory", default=None, help="Path to trajectory JSON file")
    rep.add_argument("--headless", action="store_true")

    # Auto
    auto = sub.add_parser("auto", help="Full auto registration with trajectory replay")
    auto.add_argument("--email", default=None)
    auto.add_argument("--password", default=DEFAULT_PASSWORD)
    auto.add_argument("--trajectory", default=None, help="Path to trajectory JSON file")
    auto.add_argument("--count", type=int, default=1, help="Number of accounts to register")
    auto.add_argument("--headless", action="store_true")

    args = parser.parse_args()

    if args.command == "record":
        asyncio.run(record_trajectories(args.count, headless=args.headless))
    elif args.command == "replay":
        asyncio.run(auto_with_replay(
            email=args.email,
            trajectory_path=args.trajectory,
            headless=args.headless,
        ))
    elif args.command == "auto":
        for i in range(args.count):
            email = None
            if args.email:
                email = args.email
            asyncio.run(auto_with_replay(
                email=email,
                password=args.password,
                trajectory_path=args.trajectory,
                headless=args.headless,
            ))
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
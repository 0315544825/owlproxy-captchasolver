# captchaVerifyParam `data` 字段 — 完整构造方式

## 一、data 字段加密链路（已确认）

根据 K哥爬虫逆向分析 + 我们的代码分析，data 字段的构造方式：

```
轨迹明文 (TrackList + TrackStartTime + VerifyTime)
    ↓ lr() 函数 — 轨迹对象转字符串
    ↓ fr() 函数 — TextEncoder 转为 UTF-8 二进制
    ↓ pako/deflate — 无损压缩
    ↓ Base64 编码
    ↓ AES 加密 (key = Be, 从 DeviceConfig 解密得到)
    ↓
data 字段 (最终密文)
```

### 关键函数对应

| 步骤 | 函数 | 说明 |
|------|------|------|
| 轨迹→字符串 | `lr` | 将 TrackList 对象序列化为字符串 |
| 字符串→二进制 | `fr` → `TextEncoder` | UTF-8 编码 |
| 压缩 | `(0, Un.deflate)` | pako/deflate 无损压缩 |
| 编码 | Base64 | 二进制 → Base64 字符串 |
| 加密 | AES-CBC | key=Be, IV 从 DeviceConfig 解密 |

### 高版本变化 (sg.js 1.1.10+)

在轨迹 data 密文前会多一段哈希值：

```javascript
S.dE(eb, typeof window != g + "d" ? window : window = e.g, 0, [], eg.d, eg.c, void 0, A),
l = A[0] + l  // 哈希前缀 + 原轨迹加密数据
```

## 二、deviceToken 构造方式

```
SG_WEB#{md5-h-timestamp-random}#{AES加密数据(环境指纹)}#{counter}#{hash}
```

加密 key: `a549a55c60a39aa0`

## 三、已破解的加密参数

| 参数 | 加密方式 | Key | 状态 |
|------|---------|-----|------|
| Signature | HMAC-SHA1 | `YSKfst7GaVkXwZYvVihJsKF9r89koz&` | ✅ 已破解 |
| DeviceData | AES-CBC | `c175a358550d02e2` / IV=`0123456789ABCDEF` | ✅ 已破解 |
| DeviceConfig | AES-CBC | `FqJB6iRNWYdEGpwb` | ✅ 已破解 |
| Session AES Key | AES-CBC | 从 DeviceConfig 解密得到 | ✅ 流程确认 |
| deviceToken | AES-CBC | `a549a55c60a39aa0` | ✅ 已破解 |
| data (轨迹) | AES-CBC | `Be` (从 DeviceConfig 解密) | 🔧 流程确认，key 动态 |

## 四、Log2 / Log3 请求

| 请求 | Type | Data 内容 | 说明 |
|------|------|----------|------|
| Log2 | 501 | AES加密(环境指纹) | 设备指纹验证 |
| Log3 | combat | AES加密(轨迹数据) | 轨迹验证 |

## 五、补环境方案（纯协议最可行路径）

K哥爬虫提出的方案：将 sg.js + AliyunCaptcha.js 在 Node.js 环境中运行。

### 步骤

1. 将 AliyunCaptcha.js 和 sg.js 下载到本地
2. 用 Node.js 补齐浏览器环境（window, document, navigator, Canvas, WebGL 等）
3. 将 `window.AliyunCaptcha.prototype` 配置好：
   ```javascript
   window.AliyunCaptcha.prototype = {
       "config": config,        // 从 InitCaptcha 获取
       "deviceConfig": deviceConfig  // 从 InitCaptcha 获取
   }
   ```
4. 构造 `t` 对象并指向原型链：
   ```javascript
   var t = {
       "$element": {},
       "onBizResultCallback": undefined,
       "verifyFailed": false,
       "captcha": {
           "verifyFailed": false,
           "slideStyle": {"width": 300, "height": 40}
       }
   }
   t.__proto__ = window.AliyunCaptcha.prototype
   ```
5. 导出加密函数 `em` 到 window
6. 调用 `window.encrypt_(t, track_data)` 生成加密参数
7. 构造完整的 captchaVerifyParam

### 注意事项

- sg.js 版本动态变化（1.1.0 → 1.1.10+），需要动态加载对应版本
- 每个版本的 key 和加密函数位置可能不同
- 可以用 AST 进行动态 key 匹配
- 或者整体分析 sg 代码结构，导出加密函数进行调用

## 六、纯协议自动化的完整流程

```
1. InitCaptcha (已实现)
   ↓ 获取 CertifyId + DeviceConfig
2. 解密 DeviceConfig
   ↓ 获取 Session AES Key + Be Key
3. 下载滑块图片，计算拖动距离
   ↓
4. 生成真实轨迹数据
   TrackList + TrackStartTime + VerifyTime
   ↓
5. 补环境：加载 sg.js，导出 em 函数
   ↓
6. 调用 em(t, track_data) 生成加密参数
   ↓ Log2: 设备指纹验证
   ↓ Log3: 轨迹验证 (combat)
   ↓
7. 构造 captchaVerifyParam
   {sceneId, certifyId, deviceToken, data}
   ↓
8. 调用 smsSend API
   ↓
9. 接收验证码，完成注册
```

## 七、之前的错误理解

之前认为 `data` 是阿里云服务端签发的令牌。根据 K哥爬虫的深入分析，这是错误的。

**data 字段是客户端构造的**：
- 轨迹数据在客户端经过 `lr → TextEncoder → deflate → Base64 → AES` 加密
- key `Be` 从 InitCaptcha 返回的 DeviceConfig 解密得到
- 整个过程在 sg.js 中完成

**阿里云服务端的验证发生在 Log2/Log3 阶段**：
- Log2 (Type=501): 上传加密的设备指纹
- Log3 (Type=combat): 上传加密的轨迹数据
- 阿里云根据这些数据判断是否为真人

**如果 Log2/Log3 被判定为机器人**：
- 阿里云不会签发有效的验证通过凭证
- 最终 smsSend 返回 code 2019

所以问题不是 data 无法构造，而是 **Log2/Log3 的轨迹和环境数据需要通过阿里云的检测**。

## 八、可行方案优先级

1. **补环境方案**（最推荐）：Node.js 运行 sg.js，导出加密函数，自写轨迹
2. **浏览器自动化 + 真实轨迹模拟**：Playwright + CDP + 贝塞尔轨迹
3. **浏览器中继**：真人拖动滑块，脚本完成其余流程
4. **打码平台**：2captcha 等人工打码服务
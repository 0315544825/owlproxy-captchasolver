# DECRYPTION KEYS — Complete Reference

## Static Keys (hardcoded in JS, same for every session)

| Key | Value | Usage |
|-----|-------|-------|
| ACCESS_SECRET (vt) | `FqJB6iRNVYdEGpwb` | Decrypt WEB_AES_SECRET_KEY, DeviceConfig, all static config |
| AES_IV | `0123456789ABCDEF` | AES-CBC IV (same for all operations) |
| ve (REQ key) | `45f8ac1e1de14397` | Request signing/encryption key |
| he (RES key) | `87f879f135f27da7` | **DeviceConfig decryption key** |
| flag (FLAG key) | `c175a358550d02e2` | Unknown purpose (possibly data field key fallback) |

## Derivation Chain

```
vt = G(543)+G(531) = "FqJB6iRNVYdEGpwb"  (16 bytes, AES-128)

Xt.REQ_enc = "8KmHIQsc5+LZJA7uYex3WaHdkjgCtS6epbG/bc9xss0="
Xt.RES_enc = "9NhnQQ+LRrKCkAuxwZaUWGBtSzaFtFlNb/ksJCrCgrM="  (44 chars, NOT 24!)
Xt.FLAG_enc = "k+1RW0cz3iDi2RAbC/c3QKzTPiVwNmNO1910DXe6Gas="

ve = AES_decrypt(Xt.REQ_enc, vt, IV="0123456789ABCDEF") = "45f8ac1e1de14397"
he = AES_decrypt(Xt.RES_enc, vt, IV="0123456789ABCDEF") = "87f879f135f27da7"
flag = AES_decrypt(Xt.FLAG_enc, vt, IV="0123456789ABCDEF") = "c175a358550d02e2"
```

## Per-Session Keys (from DeviceConfig)

DeviceConfig is encrypted with `he` key. Decrypted content:
```json
{
  "key": "<per-session AES key, 16 chars>",
  "sessionId": "<session ID>",
  "timestamp": "...",
  "ip": "..."
}
```

The `key` field is used for trajectory `data` field encryption:
```
data = AES_CBC_encrypt(compressed_trajectory, key=per-session-key, IV="0123456789ABCDEF")
```

## ye() Function (AES-CBC Decrypt)

```python
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
import base64

def ye(key_str, ciphertext_b64):
    key = key_str.encode('utf-8')
    iv = b"0123456789ABCDEF"
    cipher = AES.new(key, AES.MODE_CBC, iv)
    plaintext = unpad(cipher.decrypt(base64.b64decode(ciphertext_b64)), 16)
    return plaintext.decode('utf-8')
```

## Complete nr/ke Config Object

```javascript
nr = {
    WEB_AES_SECRET_KEY: {
        REQ: "45f8ac1e1de14397",    // ve - request key
        RES: "87f879f135f27da7",     // he - DeviceConfig key
        FLAG: "c175a358550d02e2"      // flag key
    },
    ACCESS_SECRET: "FqJB6iRNVYdEGpwb",  // Same as vt
    ACCESS_KEY: {
        ID: "LTAI5tGjnK9uu9GbT9GQw72p",
        SECRET: "fpOKzILEajkqgSpr9VvU98FwAgIRcX"
    },
    AES_IV: "0123456789ABCDEF",
    SALT: "daye,raolewoba!",
    SESSION_ID_SALT: "8449449787",
    KEY_ID: "LTAI5tSEBwYMwVKAQGpxmvTd",
    KEY_SECRET: "YSKfst7GaVkXwZYvVihJsKF9r89koz"
};
```

## Blocker
InitCaptcha doesn't return DeviceConfig unless DeviceData (encrypted device fingerprint) is included. Need to construct and send DeviceData to get per-session key.
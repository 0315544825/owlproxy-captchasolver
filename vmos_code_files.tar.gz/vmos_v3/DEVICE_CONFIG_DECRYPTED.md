# DeviceConfig 解密结果 - 运行时提取

## 方法
通过浏览器 hook `AliyunCaptcha.prototype.deviceConfig.deviceConfig` 直接读取运行时解密后的明文。

## 解密后的 DeviceConfig

```json
{
  "key": "39eac87ba8de7b0a",
  "switch": 1,
  "sessionId": "3795d28242a11619bc25f786f84e53d4-h-1782031226536-5b98cc798ab647889a756da30bbd8014",
  "version": "1.4.2/feilin082.1af2a6f9ef5c34077861b30410cba5788bafd3d3bff778097fb9683827f6ed8b",
  "pluginElements": "",
  "pluginResource": "",
  "globalVariable": "",
  "timestamp": "1782031226538",
  "ip": "20.65.47.190"
}
```

## 关键发现

1. **`key` 字段**: `39eac87ba8de7b0a` — 这是每会话的 AES key（就是 `he` / `Be` key！）
2. **`sessionId`**: `3795d28242a11619bc25f786f84e53d4-h-1782031226536-5b98cc798ab647889a756da30bbd8014`
3. **DeviceToken 格式**: Base64 编码，解码后为 `SG_WEB#` + deviceId + `#` + tokenData
4. **appKey**: `3795d28242a11619bc25f786f84e53d4`（与 sessionId 的前缀相同）

## DeviceToken 解码

```
Base64 解码: SG_WEB#3795d28242a11619bc25f786f84e53d4-h-1782031226536-5b98cc798ab647889a756da30bbd8014#bvI37AhNXnfY+I5znQBwx8FpZqNzzcXhtagJ2Oa3Hk2TTEioIHSy/oaZK6l3QEpEpzwIuuQZDAF/3Dcy8oWXB+K6GWebVwR0L5q5NAoLSBhvbmI5ydti0FhNOkqF0r83hnsjy5RbXre0L82oT19qQbik8L26BYhn/IxiCAHm7a1/Rj+yL3KnQJLZtcgTDrzxWGQIWWLQI+S/TQXj+qZgm0ICTGi/5QAIhhu9dy+jncV9rtsg17O/eDcEwKDabTUIByomhaCpIKUnWVP98lgquIa/IhrRC
```

## 纯协议链路关键参数

- **session key (Be)**: `39eac87ba8de7b0a`
- **appKey**: `3795d28242a11619bc25f786f84e53d4`
- **sessionId**: `3795d28242a11619bc25f786f84e53d4-h-1782031226536-5b98cc798ab647889a756da30bbd8014`
- **CertifyId**: `7M7cHKLGF9`
- **FEILIN version**: `1.4.2/feilin082`

## 注意

- `key` (39eac87ba8de7b0a) 是 **per-session** 的，每次 InitCaptcha 会返回不同的 key
- DeviceConfig 解密 key 不是静态的 `FqJB6iRNVYdEGpwb`，而是运行时从 `ye(nr.SECRET_EC, pe.SECRET)` 派生的
- 之前的静态 key 测试全部失败证实了这一点

## 下一步

需要弄清楚 `key=39eac87ba8de7b0a` 的生成方式：
1. 是 InitCaptcha 服务器下发的（在加密的 DeviceConfig 中）
2. 还是客户端从其他参数派生的

如果是 (1)，那我们需要：
- 正确解密 DeviceConfig → 得到 key
- 这需要运行时 he key → 需要理解 ye(nr.SECRET_EC, ...) 的完整链路

如果是 (2)，那纯协议方案需要：
- 弄清 key 的生成算法
- 在协议层复现
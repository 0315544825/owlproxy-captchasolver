# DeviceToken 解码

## DeviceToken 完整结构

Base64 解码后分为 5 个 `#` 分隔的部分：

```
Part 0: SG_WEB                                    # 固定标识 (web端)
Part 1: 3795d28242a11619bc25f786f84e53d4-h-...    # sessionId (与 DeviceConfig.sessionId 相同)
Part 2: bvI37AaNXnfY+I5znQBwx8FpzZqNzzcXht...     # 设备指纹/签名数据 (Base64)
Part 3: 147                                         # 数字 (可能是长度或版本号)
Part 4: d6024102795658524c07d36b49c57fe3           # MD5 哈希 (32 字符)
```

## 关键参数汇总

| 参数 | 值 | 说明 |
|------|-----|------|
| key (Be) | `39eac87ba8de7b0a` | 每 session 的 AES key |
| sessionId | `3795d28242a11619bc25f786f84e53d4-h-1782031226536-5b98cc798ab647889a756da30bbd8014` | session 标识 |
| appKey | `3795d28242a11619bc25f786f84e53d4` | 应用标识 (sessionId 前缀) |
| CertifyId | `7M7cHKLGF9` | 验证 ID |
| verifyType | `2.0` | FEILIN SDK 验证模式 |
| SceneId | `5jvar3wp` | 验证场景 |
| prefix | `69r0rc` | API 前缀 |
| region | `sgp` | 区域 |
| CaptchaType | `PUZZLE` | 滑块验证类型 |
| FEILIN version | `1.4.2/feilin082` | SDK 版本 |
| ip | `20.65.47.190` | 服务器检测到的 IP |

## 关键发现

1. **`key` 字段 (`39eac87ba8de7b0a`) 是 per-session 的**
   - 每次调用 InitCaptcha 会获得新的 key
   - 这个 key 就是轨迹数据加密的 AES key (Be)

2. **DeviceConfig 解密失败的原因确认**
   - DeviceConfig 用运行时派生的 key 解密，不是静态的 `FqJB6iRNVYdEGpwb`
   - 解密链路: `ge(DeviceConfig) → ye(nr.SECRET_EC, DeviceConfig)`
   - `he = ye(nr.SECRET_EC, pe.SECRET)` 是运行时密钥
   - 但 DeviceConfig 解密后明文中的 `key` 字段才是真正用于轨迹加密的 Be key

3. **纯协议方案的新思路**
   - 不需要自己解密 DeviceConfig
   - 只需要发起 InitCaptcha 请求，获得加密的 DeviceConfig
   - 然后通过某种方式获得解密后的 `key` 字段
   - **或者**：InitCaptcha 的响应中是否包含 `key` 字段的明文？

## 下一步验证

1. 检查 InitCaptcha API 的原始响应是否包含 `key` 字段
2. 如果包含，纯协议方案直接可用
3. 如果不包含，需要理解 `key` 的生成/传输机制
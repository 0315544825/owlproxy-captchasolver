# Aliyun CAPTCHA 完整加密链路 — 已逆向完成

## 🔑 完整密钥体系（三层 AES-CBC）

### 第1层：InitCaptcha 响应解密

```
InitCaptcha API 返回 → DeviceConfig (Base64 密文)
                         ↓
AES-128-CBC 解密 (Key = FqJB6iRNWYdEGpwb, IV = 0123456789ABCDEF)
                         ↓
明文 (两段, 用分隔符分开):
  Part 1: "1f9a29acf7cd19cb"  → 动态 Session AES Key
  Part 2: "3795d28242a11619bc25f786f84e53d4-h-1782023373434-48ee1dfee4b542408268ca14da961336"
           → 旧 DeviceToken 数据
```

**DeviceConfig 解密 Key 来源**：硬编码在 sg.js 中，每个 Session 相同：
- Key: `FqJB6iRNWYdEGpwb` (hex: `46714a423669524e5659644547707762`)
- IV: `0123456789ABCDEF` (hex: `30313233343536373839414243444546`)

### 第2层：Session 数据加密（Log2/Log3/轨迹）

```
Session AES Key = DeviceConfig 解密后的第一段 = "1f9a29acf7cd19cb"
                  (hex: 31663961323961636637636431396362)

用此 Key 加密的内容:
  - 滑块轨迹 (trackList / mousemove JSON)
  - 场景标识 ("saf-captcha")
  - 版本号 ("W.10051")
  - 时间戳
  - 浏览器指纹 ("0#0#0#0#0#0#0#0#0#0#0#0#0#0#0#0#1#0#0#0#1#1#11111110111111111111111111")
  - 设备信息 ("W.10051#####Linux x86_64#Chrome#147.0.0.0#...")
```

### 第3层：DeviceToken 加密

```
DeviceToken AES Key: a549a55c60a39aa0 (hex: 61353439613535633630613339616130)
                    来源: InitCaptcha 响应中的某个字段解密得到
IV: 0123456789ABCDEF (固定)

加密明文格式:
  "3795d28242a11619bc25f786f84e53d4#W#mXPCIKatgHBIpdRfKQ8qWMWeYfUyfmDjrquGEWSyvnc=#W20220202#CLOUD#62#N..."

  字段含义:
  - 3795d28242a11619bc25f786f84e53d4: MD5 hash (浏览器指纹)
  - #W#: 分隔符
  - mXPCIKatgHBIpdRfKQ8qWMWeYfUyfmDjrquGEWSyvnc=: 加密数据
  - #W20220202#: 版本标记
  - #CLOUD#: 平台
  - #62#: 某个计数
  - #N: 标识
  - 后面跟更多信息 (Base64编码的session key等)
```

## 🔄 完整验证流程

### Step 1: InitCaptcha (纯API — ✅ 已实现)

```
POST https://69r0rc.captcha-open-southeast.aliyuncs.com/
Body: Action=InitCaptcha&AccessKeyId=LTAI5tSEBwYMwVKAQGpxmvTd&...

→ 返回: CertifyId, Image, PuzzleImage, DeviceConfig
```

### Step 2: 解密 DeviceConfig (✅ 已逆向)

```
DeviceConfig (Base64) → AES-CBC-解密(Key=FqJB6iRNWYdEGpwb, IV=0123456789ABCDEF)
→ 得到 Session AES Key + 旧 DeviceToken
```

### Step 3: 滑块轨迹生成 (🔲 待实现)

```
1. 下载背景图和滑块图 (从 InitCaptcha 返回的 URL)
2. CV 检测缺口位置 (模板匹配)
3. 生成人类轨迹 (ease-out + 抖动)
4. 用 Session AES Key 加密轨迹数据
5. 构造 SlideData JSON
```

### Step 4: 构造验证请求 (🔲 待实现)

```
加密数据用 Session AES Key 加密后，发送到验证端点
构造 captchaVerifyParam = CertifyId + "#" + 加密轨迹 + "#" + 加密指纹
```

### Step 5: 发送短信验证码 (✅ 已有 API)

```
POST https://api.vmoscloud.com/vcpcloud/api/sms/smsSend
Body: { smsType: 2, mobilePhone: email, captchaVerifyParam: "..." }
```

## 📋 Key 总结

| Key | 值 | 用途 |
|-----|-----|------|
| ACCESS_SEC | YSKfst7GaVkXwZYvVihJsKF9r89koz | HMAC-SHA1 签名 |
| ACCESS_KEY_ID | LTAI5tSEBwYMwVKAQGpxmvTd | API AK |
| DeviceConfig解密Key | FqJB6iRNWYdEGpwb | 解密 InitCaptcha 响应 |
| Session AES Key (动态) | 1f9a29acf7cd19cb | 加密轨迹/指纹 (每次不同) |
| DeviceToken AES Key | a549a55c60a39aa0 | 加密 DeviceToken |
| AES_IV (固定) | 0123456789ABCDEF | 所有 AES-CBC 操作 |
| WEB_AES_SECRET_KEY | c175a358550d02e2 | 初始 DeviceData 加密 |

## 🎯 下一步

1. **实现 DeviceConfig 解密** — 从 InitCaptcha 响应提取 Session AES Key
2. **实现轨迹加密** — 用 Session AES Key 加密滑块轨迹
3. **实现 captchaVerifyParam 构造** — 组装完整的验证参数
4. **CV 缺口检测** — OpenCV 模板匹配
5. **轨迹模拟** — 人类拖动轨迹生成
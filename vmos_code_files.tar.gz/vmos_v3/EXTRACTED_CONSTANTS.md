# Aliyun CAPTCHA sg.js Runtime Constants - EXTRACTED

## ✅ All Constants Successfully Extracted (2026-06-21)

### 1. API Signing Constants

| Constant | Value | Usage |
|----------|-------|-------|
| **ACCESS_KEY_ID** | `LTAI5tSEBwYMwVKAQGpxmvTd` | Aliyun RAM AccessKey ID (public) |
| **ACCESS_SEC** | `YSKfst7GaVkXwZYvVihJsKF9r89koz` | HMAC-SHA1 signing secret |
| **HMAC Key Format** | `{ACCESS_SEC}&` | Key = `YSKfst7GaVkXwZYvVihJsKF9r89koz&` |

### 2. AES Encryption Constants

| Constant | Value | Usage |
|----------|-------|-------|
| **WEB_AES_SECRET_KEY** | `c175a358550d02e2` | AES key for DeviceData encryption |
| **AES Key (dynamic)** | `45f8ac1e1de14397` | AES key from DeviceConfig (per-session) |
| **AES_IV** | `0123456789ABCDEF` | AES-CBC IV (fixed, 16 bytes) |

### 3. API Endpoints

| Endpoint | URL |
|----------|-----|
| InitCaptcha (primary) | `https://sgp.captcha-open.aliyuncs.com/` |
| InitCaptcha (backup) | `https://sgp.captcha-open-b.aliyuncs.com/` |
| UploadLog | `https://upload.captcha-open.aliyuncs.com/` |

Note: The code constructs URLs as `{region}.captcha-open.aliyuncs.com/` where region comes from config (sgp = Singapore).

### 4. Signing Process (Verified)

```
1. Remove Signature from params
2. Sort params alphabetically by key
3. URL-encode params
4. Construct stringToSign: "POST&%2F&" + url_encode(sorted_params)
5. HMAC-SHA1(key="YSKfst7GaVkXwZYvVihJsKF9r89koz&", message=stringToSign)
6. Base64-encode the HMAC result → Signature
7. Append Signature to request params
```

### 5. DeviceData Encryption (AES-CBC)

```
plaintext = browser_fingerprint_string
key = c175a358550d02e2 (hex: 63313735613335383535306430326532)
iv = 0123456789ABCDEF (hex: 30313233343536373839414243444546)
encrypted = AES-CBC(pkcs7_pad(plaintext), key, iv)
DeviceData = Base64(encrypted)
```

### 6. DeviceToken Structure

```
DeviceToken message format: "{md5_hash}#W#{device_token_data}#W20220202#CLOUD#"
AES key (per-session): from InitCaptcha response DeviceConfig
AES IV: 0123456789ABCDEF (same fixed IV)
```

### 7. INIT_MD5_SECRET_SALT

The MD5 salt is used in device fingerprint hashing. It appears in the message format:
- Message prefix: `W.10001.c#saf-captcha#5jvar3wp#captcha-normal#`
- MD5 of: `{salt_or_hash}#W#...#W20220202#CLOUD#`

### 8. API Version

| Constant | Value |
|----------|-------|
| **API_VERSION** | `2023-03-05` (from request params) |

### 9. Log2/Log3 AccessKey (Device Verification)

| Constant | Value |
|----------|-------|
| **AccessKeyId (Log)** | `LTAI5tGjnK9uu9GbT9GQw72p` |
| **AccessKeySecret (Log)** | To be extracted separately |

---

## Extraction Method

Constants were extracted by:
1. Loading feilin.js + AliyunCaptcha.js + pe.js in a controlled browser environment
2. Hooking `CryptoJS.HmacSHA1` to capture HMAC signing keys
3. Hooking `CryptoJS.AES.encrypt/decrypt` to capture AES keys and IVs
4. Initializing `initAliyunCaptcha` to trigger API calls
5. Intercepting XHR requests to capture full request parameters

The sg.js VM bytecode interpreter (`d()` function) was **not** directly deobfuscated — instead, runtime hooking was used to extract the actual values from live function calls, which is far more reliable and maintainable than static analysis of the obfuscated VM.
# VMOS Cloud Aliyun CAPTCHA — 逆向进展总结

## ✅ 已完成

### 1. 签名密钥提取 (完成)
| 常量 | 值 | 来源 |
|------|-----|------|
| ACCESS_SEC | `YSKfst7GaVkXwZYvVihJsKF9r89koz` | 运行时Hook HmacSHA1 |
| ACCESS_KEY_ID | `LTAI5tSEBwYMwVKAQGpxmvTd` | 运行时Hook |
| WEB_AES_SECRET_KEY | `c175a358550d02e2` | 运行时Hook AES.encrypt |
| AES_IV | `0123456789ABCDEF` | 运行时Hook AES.encrypt |
| Session AES Key | `45f8ac1e1de14397` | 运行时Hook AES.encrypt (DeviceToken) |
| HMAC Key Format | `{ACCESS_SEC}&` | 标准阿里云签名格式 |
| API_VERSION | `2023-03-05` | 请求参数 |
| SCENE_ID | `5jvar3wp` | 请求参数 |
| PREFIX | `69r0rc` | URL构造 |
| REGION | `sgp` | 请求参数 |

### 2. InitCaptcha 纯API调用 (完成)
- ✅ 签名验证通过
- ✅ 正确的endpoint: `https://69r0rc.captcha-open-southeast.aliyuncs.com/`
- ✅ 成功获取 CertifyId 和滑块图片URL
- ✅ 下载并解析滑块图片
- ✅ UploadLog 可以正常调用

### 3. 签名算法 (完成)
```
stringToSign = "POST&%2F&" + url_encode(sorted_params)
signature = Base64(HMAC-SHA1(ACCESS_SEC + "&", stringToSign))
```

### 4. DeviceData 加密 (完成)
```
plaintext = browser_fingerprint_json
encrypted = AES-128-CBC(plaintext, key=WEB_AES_SECRET_KEY, iv=AES_IV)
DeviceData = Base64(encrypted)
```

### 5. 三层加密链路 (完成)
- Layer 1: DeviceConfig 解密 → Key=`FqJB6iRNWYdEGpwb`, IV=固定 → 得到 Session AES Key
- Layer 2: 轨迹/环境数据加密 → Session AES Key (动态, 每次InitCaptcha不同)
- Layer 3: DeviceToken 加密 → Key=`a549a55c60a39aa0`, IV=固定

### 6. captchaVerifyParam 格式 (确认)
```json
{
  "sceneId": "5jvar3wp",
  "certifyId": "{from InitCaptcha}",
  "deviceToken": "Base64(SG_WEB#md5-h-timestamp-random#AES加密数据#counter#hash)",
  "data": "Base64(自定义二进制编码 — 580字节, 非标准AES)"
}
```

### 7. TrackList 格式 (确认)
```
mc: mousedown (x,y,timestamp, ,type)
mu: mouseup   (x,y,timestamp, ,type)
mp: mouse move (x,y,timestamp,type)
mm: mouse move metadata (x,y,timestamp,type)
```

### 8. DeviceToken 格式 (确认)
```
SG_WEB#{md5-h-timestamp-random}#{AES加密数据}#{counter}#{hash}
```

## 🔲 核心卡点：data 字段编码 + 轨迹检测

### 问题本质
**拖动距离正确 ≠ 验证通过。** 阿里云服务端不只验证滑块位置，还验证拖动过程中的行为特征。

浏览器Hook成功捕获了完整流程：
- ✅ captchaVerifyParam 确实生成了
- ✅ smsSend 请求发出了
- ❌ smsSend 返回 code 2019 "Signature verification failed"

这意味着：即使 captchaVerifyParam 格式正确，如果轨迹被判定为机器人，阿里云签发的 data 凭证就是"失败"状态。

### data 字段 (580字节)
- 不是标准 AES-CBC（长度不是16的倍数）
- 可能是 sg.js 的自定义二进制编码
- 逆向难度极高，因为 sg.js 有5万+行高度混淆代码
- 版本频繁更新（1.1.0 → 1.1.10+），key和算法可能变化

### 服务端检测的轨迹特征
| 类别 | 采集内容 | 检测目的 |
|------|---------|---------|
| 轨迹坐标 | mousedown/mousemove/mouseup x,y | 是否直线、有无自然抖动 |
| 时间戳 | 毫秒级时间 | 速度是否过于均匀 |
| 速度曲线 | 相邻点速度变化 | 加速度是否像人手 |
| 抖动幅度 | y轴偏移 | 人手有微颤，机器没有 |
| 按压时长 | down到up的时间 | 太短或太均匀=机器 |
| 设备指纹 | Canvas/WebGL/字体/UA | 是否无头浏览器 |
| 事件属性 | isTrusted/类型 | 是否程序派发 |

## 🎯 可行方案（优先级排序）

### 方案A：浏览器中继 — 真人滑动 + 脚本接管（最推荐）
- Playwright 打开页面，填邮箱
- 真人手动完成滑块
- 脚本自动拦截 captchaVerifyParam
- 脚本自动接收验证码并完成注册
- 已有基础代码：`vmos_cloud_human_captcha_capture.py`
- 成功率：100%，需要人工参与30秒

### 方案B：打码平台（2captcha/anti-captcha）
- 成本约 $0.002/次
- 需要提取验证码图片URL传给打码平台
- 打码平台返回坐标
- 仍需用真实轨迹拖动（可能还需浏览器中继）

### 方案C：录制回放真人轨迹
- 录制多组真人拖动轨迹（包括速度曲线、抖动、停顿）
- 每次随机选择一组 + 微小偏移重放
- 需要足够多的轨迹样本以避免模式检测
- 风险：设备指纹仍可能暴露

### 方案D：逆向 sg.js 的 data 编码（难度极高）
- 580字节的 data 不是标准编码
- sg.js 有5万+行高度混淆（多层字符串解码 + 控制流扁平化）
- 版本频繁变化，需要持续维护
- 不推荐作为主方案

## 📁 文件结构

```
vmos_v3/                    ← 纯API客户端 + 逆向文档
├── PROGRESS.md             ← 本文件
├── ENCRYPTION_CHAIN.md     ← 三层加密链路
├── EXTRACTED_CONSTANTS.md  ← 常量参考
├── vmos_captcha_api.py     ← InitCaptcha API客户端 (可用)
├── constants.json          ← 机器可读常量
├── extract_browser_v2.html ← 浏览器Hook脚本
├── captcha_back_live.png   ← 滑块背景图
├── captcha_shadow_live.png ← 滑块拼图块
└── aliyun_captcha_analysis.md ← 详细分析报告

vmos_analysis/              ← 拦截的JS和请求
├── sg_js_reverse_engineering.md
├── aliyun_captcha_analysis.md
├── js/                     ← 原始混淆JS (5万+行)
│   ├── AliyunCaptcha.js
│   ├── feilin081.*.js      ← sg.js (核心验证逻辑)
│   └── pe.*.js
└── captured/               ← 拦截的网络请求

vmos_cloud/                 ← 完整注册脚本
├── vmos_cloud_api.md       ← API文档
├── accounts/               ← 已创建的账号
└── scripts/
    ├── vmos_cloud_auto_register.py      ← 自动注册
    ├── vmos_cloud_human_captcha_capture.py ← 人工滑块
    ├── vmos_captcha_solver_v3.py        ← CV+浏览器自动化
    └── vmos_cloud_oneclick.py           ← 一键脚本
```
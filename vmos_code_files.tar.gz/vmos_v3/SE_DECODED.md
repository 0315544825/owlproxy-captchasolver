# me()/Se() Array Decoding Results

## Method
Executed me() array, Se() function, and rotation IIFE in browser context with a shared mutable array, solving the chicken-and-egg problem.

## Key Decoded Values

### Config Property Names (ke/nr object)
| Code | Value | Property |
|------|-------|----------|
| Se(501)+Se(520)+"EY" | WEB_AES_SECRET_KEY | nr.WEB_AES_SECRET_KEY |
| Se(568)+"EC" | ACCESS_SECRET | nr.ACCESS_SECRET |
| Se(562)+"EY" | ACCESS_KEY | nr.ACCESS_KEY |
| Se(644) | REQ | pe.REQ / pe["REQ"] |
| Se(594) | RES | pe.RES / pe["RES"] |
| Se(422) | FLAG | pe.FLAG / pe["FLAG"] |
| Se(618) | FLAG | FLAG property |
| Se(483) | ACTION | ACTION property |
| Se(610)+Se(476) | DEVICE_TYPE | DEVICE_TYPE |

### CryptoJS References
| Code | Value | CryptoJS Reference |
|------|-------|-------------------|
| Se(613) | enc | CryptoJS.enc |
| Se(602) | AES | CryptoJS.AES |
| Se(548) | Utf8 | CryptoJS.enc.Utf8 |
| Se(541) | Base64 | CryptoJS.enc.Base64 |
| Se(662) | Hex | CryptoJS.enc.Hex |
| Se(532) | parse | CryptoJS method |
| Se(579)+"y" | stringify | CryptoJS method |
| Se(561) | pad | CryptoJS.pad |
| Se(677) | Pkcs7 | CryptoJS.pad.Pkcs7 |

### Function Names
| Code | Value |
|------|-------|
| Se(627)+Se(499) | __ALIYUN_CRYPT |
| Se(589)+Se(496) | computeSignature |
| Se(558) | HmacSHA1 |

## Corrected Understanding

### ACCESS_SECRET (NOT SECRET_EC!)
Previous analysis had `Se(568)+"EC"` decoded as `SECRET_EC`. This is WRONG.
The correct decoding is: **ACCESS_SECRET** = `Se(568) + "EC"` = `"ACCESS_S" + "EC"` = `"ACCESS_SECRET"`

This is critical because `ACCESS_SECRET` is the key used for `ye()` decryptions:
```javascript
ve = ye(nr.ACCESS_SECRET, pe.REQ)  // → request encryption key
he = ye(nr.ACCESS_SECRET, pe.RES)  // → DeviceConfig decryption key
```

### ACCESS_SECRET = vt = "FqJB6iRNVYdEGpwb"
From G()/dt() decoding: `G(543)+G(531) = "FqJB6iRNVYdEGpwb"` = `ACCESS_SEC` (from Ee config)
So `nr.ACCESS_SECRET = "FqJB6iRNVYdEGpwb"` (16 bytes, valid AES-128 key)

### Se(613) = "enc" (NOT "WImXw")
Previous attempt decoded Se(513) as "WImXw", which was confusing.
Se(613) = "enc" is the actual property name for CryptoJS.enc.

## Complete Encryption Chain

### ye() Function Decryption
```javascript
function ye(key, ciphertext) {
    var S = CryptoJS.enc.Utf8.parse(key);  // Parse key as UTF-8
    var le = {
        iv: CryptoJS.enc.Utf8.parse("0123456789ABCDEF"),  // Fixed IV
        padding: CryptoJS.pad.Pkcs7
    };
    var b = CryptoJS.AES.decrypt(
        {ciphertext: CryptoJS.enc.Base64.parse(ciphertext)},
        S,
        le
    );
    return b.toString(CryptoJS.enc.Utf8);
}
```

### Key Derivation
```
vt = "FqJB6iRNVYdEGpwb" (from G(543)+G(531), static in JS)

Xt = {REQ: "8KmHIQsc5+LZJA7uYex3WaHdkjgCtS6epbG/bc9xss0=",
      RES: "9NhnQQ+LRrKCkAuxwZaUWGBtSzaFtFlNb/ksJCrCgrM=",
      FLAG: "k+1RW0cz3iDi2RAbC/c3QKzTPiVwNmNO1910DXe6Gas="}

ve = AES_CBC_decrypt(Xt.REQ, vt, IV="0123456789ABCDEF") = "45f8ac1e1de14397"
he = AES_CBC_decrypt(Xt.RES, vt, IV="0123456789ABCDEF") = "87f879f135f27da7"
flag = AES_CBC_decrypt(Xt.FLAG, vt, IV="0123456789ABCDEF") = "c175a358550d02e2"

Since ACCESS_SECRET = vt:
ve = ye(ACCESS_SECRET, pe.REQ) = ye(vt, Xt.REQ) = "45f8ac1e1de14397"
he = ye(ACCESS_SECRET, pe.RES) = ye(vt, Xt.RES) = "87f879f135f27da7"
```

### IV Derivation (confirms standard IV)
```
gt = "d35db7e39ebbf3d001083105" (hex, 12 bytes)
fe = Base64.stringify(Hex.parse(gt)) = "0123456789ABCDEF"
IV = Utf8.parse(fe) = bytes "0123456789ABCDEF"
```

### DeviceConfig Decryption
```
DeviceConfig_decrypted = AES_CBC_decrypt(DeviceConfig_encrypted, he="87f879f135f27da7", IV="0123456789ABCDEF")
→ Contains: {key: "<per-session-key>", sessionId: "...", ...}
```

### Data Field Encryption (trajectory)
```
trajectory_json → lr() → TextEncoder → pako.deflate → Base64 → AES-CBC(key=per-session-key, IV="0123456789ABCDEF")
```

## Current Blocker
InitCaptcha API doesn't return DeviceConfig unless DeviceData is included in the request. DeviceData must contain an encrypted device fingerprint.
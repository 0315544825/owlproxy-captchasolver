# 阿里云滑块验证码逆向分析报告

## 为什么自动化拖动无法通过？

### 核心结论

**拖动距离正确 ≠ 验证通过。** 阿里云服务端不只验证滑块位置，还验证整个拖动过程中的**行为特征**。

我们的测试结果：
- ✅ 拖动距离 151px — 正确
- ✅ 弹窗关闭（`window-show` → `window-hidden`）— 视觉通过
- ✅ captchaVerifyParam 生成 — SDK 确实生成了
- ❌ smsSend 返回 code 2019 — **服务端判定为机器人**

### 阿里云验证码完整流程

```
1. 初始化
   POST captcha-open.aliyuncs.com
   → Action=InitCaptchaV3
   → DeviceToken=<浏览器指纹>    ← SDK 自动采集
   → Signature=<HMAC-SHA1签名>   ← SDK 内部计算
   ← 返回 CertifyId + 滑块图片

2. 用户拖动滑块（关键环节！）
   SDK 在后台记录：
   ├── 鼠标/触摸轨迹坐标序列 (x, y 坐标数组)
   ├── 每个采样点的时间戳 (毫秒级)
   ├── 滑动速度和加速度变化曲线
   ├── 按压时长、松手时机
   ├── 抖动特征（频率、幅度）
   └── 设备环境指纹（Canvas、WebGL、字体、UA等）

3. 轨迹数据发送
   POST device.captcha-open.aliyuncs.com (Log2)
   → Data=<AES加密的环境+轨迹数据>   ← Type: 501 (环境校验)
   
   POST device.captcha-open.aliyuncs.com (Log3)
   → Data=<AES加密的轨迹数据>        ← Type: combat (轨迹校验)

4. 最终验证
   POST captcha-open.aliyuncs.com
   → CaptchaVerifyParam = {
       sceneId: "5jvar3wp",
       certifyId: "xxx",
       deviceToken: "<浏览器指纹>",
       data: "<阿里云签发的验证凭证>"  ← 只有轨迹通过才签发
     }
   
   如果轨迹被判定为机器人：
   → data 凭证被标记为无效
   → 业务端 smsSend 返回 code 2019 "Signature verification failed"
```

### captchaVerifyParam 内部结构

```json
{
  "sceneId": "5jvar3wp",
  "certifyId": "<初始化时分配的会话ID>",
  "deviceToken": "<浏览器指纹 AES加密>",
  "data": "<阿里云签发的验证通过凭证>"
}
```

**关键：`data` 字段是阿里云服务端签发的，包含：**
- 验证结果（通过/不通过）
- 与 CertifyId 绑定
- 有时效性（10分钟）
- 一次性使用（防重放）
- **即使格式正确，如果轨迹被判定为机器人，data 就是无效凭证**

### 服务端检测的轨迹特征

根据逆向分析，阿里云验证码 SDK（sg.js）采集以下数据：

| 类别 | 采集内容 | 检测目的 |
|------|---------|---------|
| **轨迹坐标** | mousedown/mousemove/mouseup 的 x,y 坐标序列 | 是否为直线、有无自然抖动 |
| **时间戳** | 每个采样点的毫秒级时间 | 速度是否过于均匀、有无人类节奏 |
| **速度曲线** | 相邻点的速度变化 | 加速度是否像人手（慢→快→慢） |
| **加速度** | 速度的二阶导数 | 是否有自然的加速/减速过程 |
| **抖动幅度** | y轴偏移量 | 人的手有微颤，机器没有 |
| **按压时长** | mousedown到mouseup的时间 | 太短或太均匀=机器 |
| **设备指纹** | Canvas/WebGL/字体/屏幕/UA | 是否为无头浏览器 |
| **事件类型** | MouseEvent 的 isTrusted/类型 | 是否为程序派发 |

### 为什么我们的自动化被检测到了？

1. **鼠标轨迹过于平滑** — Bézier 曲线虽然不是直线，但加速度变化太规则
2. **时间间隔太均匀** — `asyncio.sleep(0.02)` 产生的间隔方差太小
3. **缺乏自然抖动** — y轴偏移的 `random.gauss(0, 1.0)` 不够真实
4. **按压时间异常** — 从 down 到 up 的时间太短或太规律
5. **缺少自然停顿** — 真人会在拖动中有自然的迟疑/加速/减速
6. **设备指纹** — 即使用了 CloakBrowser，某些特征仍可能被识别

### 加密算法链条（sg.js）

```
轨迹明文 → TrackList/TrackStartTime/VerifyTime
  → JSON.stringify → TextEncoder → UTF-8 bytes
  → pako.deflate (zlib压缩) → Base64
  → AES加密 (key从DeviceConfig解密得到)
  → data 字段

环境参数 → JSON → AES加密 → DeviceToken / device.captcha Data

SignatureNonce → UUID生成 → 算法混淆
Signature → HMAC-SHA1(key, params) → Base64
```

**sg.js 版本动态变化**（1.1.0 → 1.1.10+），key和算法都可能变化。

### 为什么不能用简单方法绕过？

| 方法 | 可行性 | 原因 |
|------|--------|------|
| 纯伪造 captchaVerifyParam | ❌ | data 凭证由阿里云签发，无法伪造 |
| 固定距离拖动 | ❌ | 距离正确但轨迹被检测 |
| Bézier曲线拖动 | ❌ | 曲线太规则，加速度特征被检测 |
| Touch事件拖动 | ❌ | 同样采集轨迹，服务端分析 |
| CloakBrowser反指纹 | ❌ | 指纹可能通过，但轨迹仍被检测 |
| Playwright/Selenium | ❌ | isTrusted=true但轨迹特征暴露 |
| 人工手动滑 | ✅ | 真实轨迹+真实指纹=通过 |
| 打码平台(2captcha) | ✅ | 真人代打 |
| 逆向sg.js纯算轨迹 | ⚠️ | 理论可行但难度极高，版本经常变 |

### 可行的解决方案

#### 方案1：人工滑块（推荐，最简单）
- 打开浏览器让真人手动完成滑块
- 脚本只负责：填邮箱→等待手动验证码→拦截smsSend→完成注册
- 实现文件：`vmos_cloud_human_captcha_capture.py`

#### 方案2：接入打码平台
- 使用 2captcha/anti-captcha 等服务
- 成本约 $0.002/次
- 需要提取验证码图片 URL 传给打码平台
- 打码平台返回坐标，再用更真实的轨迹拖动

#### 方案3：逆向 sg.js 生成合法轨迹（难度极高）
- 需要完全逆向 `sg.cdec2e19d71dad5d9c4c.js`
- 生成符合人类特征的轨迹数据
- 构造 DeviceToken（环境指纹）
- 加密参数（AES + HMAC-SHA1 + Base64 + Deflate）
- sg.js 版本经常变，需要持续维护

#### 方案4：改进轨迹模拟（有可能成功）
- 从真人拖动中录制轨迹数据
- 使用录制的轨迹 + 微小随机偏移重放
- 关键是要有真实的速度曲线和加速度特征
- 仍可能被设备指纹检测到

### DOM 结构参考

```
#aliyunCaptcha-window-popup          ← 主弹窗 (class: window-show/window-hidden)
  #aliyunCaptcha-mask                ← 遮罩层
  #aliyunCaptcha-title               ← "Please complete the captcha"
  #aliyunCaptcha-btn-close           ← 关闭按钮
  #aliyunCaptcha-btn-refresh          ← 刷新按钮
  #aliyunCaptcha-img-box              ← 拼图容器
    #aliyunCaptcha-img                ← 背景图 (300×200, 带缺口)
    #aliyunCaptcha-puzzle             ← 拼图块 (~52px, 可拖动)
    #aliyunCaptcha-overlay            ← 覆盖层
  #aliyunCaptcha-sliding-body         ← 滑块轨道
    #aliyunCaptcha-sliding-slider     ← 滑块按钮 (40×40)
      class: slider-move initial → slider-move (拖动时)
```

### 参考资源

- 阿里云验证码 v2 逆向分析: https://www.cnblogs.com/ikdl/p/18576586
- 阿里云验证码保护分析: https://ohmycat.me/2026/04/30/verify-captcha.html
- VMOS Cloud 使用的 SceneId: 5jvar3wp, prefix: 69r0rc, region: sgp
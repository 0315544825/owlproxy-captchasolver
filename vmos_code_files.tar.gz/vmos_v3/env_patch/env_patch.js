#!/usr/bin/env node
/**
 * VMOS Cloud — Aliyun CAPTCHA V2 补环境方案
 * 
 * 在 Node.js 中运行 sg.js + AliyunCaptcha.js，导出加密函数，
 * 构造纯协议的 captchaVerifyParam。
 * 
 * 用法:
 *   node env_patch.js --init                    # 初始化：获取 CertifyId + DeviceConfig
 *   node env_patch.js --encrypt <track_file>    # 加密轨迹数据
 *   node env_patch.js --verify <track_file>      # 完整验证流程
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const pako = require('pako');

// ── Constants ─────────────────────────────────────────────────────────

const ACCESS_SEC = 'YSKfst7GaVkXwZYvVihJsKF9r89koz';
const ACCESS_KEY_ID = 'LTAI5tSEBwYMwVKAQGpxmvTd';
const WEB_AES_SECRET_KEY = 'c175a358550d02e2';
const AES_IV = '0123456789ABCDEF';
const DEVICE_CONFIG_KEY = 'FqJB6iRNWYdEGpwb';
const DEVICE_TOKEN_KEY = 'a549a55c60a39aa0';
const API_VERSION = '2015-03-15';
const SCENE_ID = '5jvar3wp';
const PREFIX = '69r0rc';
const REGION = 'sgp';

// ── AES Helper ────────────────────────────────────────────────────────

function aesEncrypt(plaintext, key, iv = AES_IV) {
    const cipher = crypto.createCipheriv('aes-128-cbc', Buffer.from(key), Buffer.from(iv));
    let encrypted = cipher.update(plaintext, 'utf8', 'base64');
    encrypted += cipher.final('base64');
    return encrypted;
}

function aesDecrypt(ciphertext, key, iv = AES_IV) {
    const decipher = crypto.createDecipheriv('aes-128-cbc', Buffer.from(key), Buffer.from(iv));
    let decrypted = decipher.update(ciphertext, 'base64', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
}

function hmacSHA1(key, data) {
    return crypto.createHmac('sha1', key).update(data).digest('base64');
}

function md5(str) {
    return crypto.createHash('md5').update(str).digest('hex');
}

// ── URL Encode for Signature ──────────────────────────────────────────

function percentEncode(str) {
    return encodeURIComponent(str)
        .replace(/!/g, '%21')
        .replace(/'/g, '%27')
        .replace(/\(/g, '%28')
        .replace(/\)/g, '%29')
        .replace(/\*/g, '%2A')
        .replace(/~/g, '%7E');
}

// ── InitCaptcha API Call ───────────────────────────────────────────────

function buildSignature(params, secret) {
    const sortedKeys = Object.keys(params).sort();
    const queryString = sortedKeys.map(k => `${percentEncode(k)}=${percentEncode(params[k])}`).join('&');
    const stringToSign = `POST&${percentEncode('/')}&${percentEncode(queryString)}`;
    return hmacSHA1(secret + '&', stringToSign);
}

function callInitCaptcha() {
    const https = require('https');
    const url = require('url');

    const timestamp = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z');
    const nonce = crypto.randomUUID();

    const params = {
        AccessKeyId: ACCESS_KEY_ID,
        Action: 'InitCaptcha',
        DeviceData: '',
        Format: 'JSON',
        SceneId: SCENE_ID,
        SignatureMethod: 'HMAC-SHA1',
        SignatureNonce: nonce,
        SignatureVersion: '1.0',
        Timestamp: timestamp,
        Version: API_VERSION,
    };

    const signature = buildSignature(params, ACCESS_SEC);
    params.Signature = signature;

    const postData = Object.entries(params)
        .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
        .join('&');

    const endpoint = `https://${PREFIX}.captcha-open-southeast.aliyuncs.com/`;

    return new Promise((resolve, reject) => {
        const reqUrl = new url.URL(endpoint);
        const options = {
            hostname: reqUrl.hostname,
            port: 443,
            path: reqUrl.pathname,
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'Content-Length': Buffer.byteLength(postData),
            },
        };

        const req = https.request(options, (res) => {
            let data = '';
            res.on('data', (chunk) => data += chunk);
            res.on('end', () => {
                try {
                    resolve(JSON.parse(data));
                } catch (e) {
                    reject(new Error(`Parse error: ${e.message}, raw: ${data}`));
                }
            });
        });

        req.on('error', reject);
        req.write(postData);
        req.end();
    });
}

// ── Decrypt DeviceConfig ──────────────────────────────────────────────

function decryptDeviceConfig(deviceConfig) {
    try {
        const decrypted = aesDecrypt(deviceConfig, DEVICE_CONFIG_KEY);
        console.log('[DeviceConfig] Decrypted:', decrypted.substring(0, 200));
        
        // Parse the decrypted data
        // Format: SG_WEB#hash#timestamp#random or similar
        const parts = decrypted.split('#');
        
        // The session AES key might be embedded in the decrypted data
        return {
            raw: decrypted,
            parts: parts,
        };
    } catch (e) {
        console.error('[DeviceConfig] Decrypt failed:', e.message);
        return null;
    }
}

// ── Track Data Generation ──────────────────────────────────────────────

function generateRealisticTrack(distance, startX = 0, startY = 0) {
    /**
     * Generate a realistic human-like slider track.
     * Based on research into Aliyun CAPTCHA detection heuristics:
     * - Variable speed with acceleration/deceleration
     * - Y-axis micro-jitter (hand tremor)
     * - Natural pauses
     * - Overshoot and correction
     */
    const track = [];
    const startTime = Date.now();
    
    // Phase 1: Mouse down (small delay before moving)
    track.push({
        type: 'mc',
        x: startX,
        y: startY,
        t: startTime,
    });

    // Phase 2: Acceleration (start slow)
    let currentX = startX;
    let currentY = startY;
    let currentTime = startTime + Math.floor(Math.random() * 80 + 50); // 50-130ms reaction time
    let velocity = 0;
    
    // Number of movement points (real human: 15-35 points)
    const numPoints = Math.floor(Math.random() * 20 + 15);
    
    // Pre-compute speed profile (ease-in-out with noise)
    const speedProfile = [];
    for (let i = 0; i < numPoints; i++) {
        const t = i / (numPoints - 1);
        // Ease-in-out with noise
        let speed;
        if (t < 0.15) {
            // Acceleration phase
            speed = t / 0.15 * 0.4 + Math.random() * 0.05;
        } else if (t < 0.75) {
            // Constant speed phase with variation
            speed = 0.4 + Math.random() * 0.3;
        } else if (t < 0.92) {
            // Deceleration phase
            speed = (1 - (t - 0.75) / 0.17) * 0.4 + Math.random() * 0.05;
        } else {
            // Final correction (overshoot and come back)
            speed = Math.random() * 0.08;
        }
        speedProfile.push(speed);
    }
    
    // Normalize speed profile so total distance = target distance
    const totalSpeed = speedProfile.reduce((a, b) => a + b, 0);
    const normalizedSpeed = speedProfile.map(s => s / totalSpeed * distance);
    
    // Add overshoot
    const overshoot = Math.random() * 4 + 2; // 2-6px overshoot
    const overshootPoints = Math.floor(Math.random() * 3 + 2);
    
    // Generate movement points
    for (let i = 0; i < numPoints; i++) {
        currentX += normalizedSpeed[i];
        
        // Y-axis jitter (human hand tremor)
        const jitter = Math.random() < 0.7 ? 
            (Math.random() - 0.5) * 3 :  // Small jitter
            (Math.random() - 0.5) * 6;    // Occasional larger jitter
        currentY = startY + jitter;
        
        // Time between points (variable, more at start and end)
        let dt;
        if (i < numPoints * 0.2) {
            dt = Math.floor(Math.random() * 20 + 25);  // Start: 25-45ms
        } else if (i < numPoints * 0.8) {
            dt = Math.floor(Math.random() * 15 + 10);  // Middle: 10-25ms (fast)
        } else {
            dt = Math.floor(Math.random() * 25 + 20);  // End: 20-45ms (slowing)
        }
        currentTime += dt;
        
        track.push({
            type: 'mm',
            x: Math.round(currentX * 100) / 100,
            y: Math.round(currentY * 100) / 100,
            t: currentTime,
        });
    }
    
    // Overshoot
    const peakX = currentX + overshoot;
    for (let i = 0; i < overshootPoints; i++) {
        currentX += (peakX - currentX) / (overshootPoints - i);
        currentY = startY + (Math.random() - 0.5) * 2;
        currentTime += Math.floor(Math.random() * 30 + 20);
        track.push({
            type: 'mm',
            x: Math.round(currentX * 100) / 100,
            y: Math.round(currentY * 100) / 100,
            t: currentTime,
        });
    }
    
    // Correction back
    const correctionSteps = Math.floor(Math.random() * 2 + 2);
    for (let i = 0; i < correctionSteps; i++) {
        currentX += (startX + distance - currentX) / (correctionSteps - i);
        currentY = startY + (Math.random() - 0.5) * 1;
        currentTime += Math.floor(Math.random() * 40 + 30);
        track.push({
            type: 'mm',
            x: Math.round(currentX * 100) / 100,
            y: Math.round(currentY * 100) / 100,
            t: currentTime,
        });
    }
    
    // Small pause at end (human reaction)
    currentTime += Math.floor(Math.random() * 100 + 80);
    
    // Mouse up
    track.push({
        type: 'mu',
        x: Math.round((startX + distance) * 100) / 100,
        y: Math.round((startY + (Math.random() - 0.5) * 1) * 100) / 100,
        t: currentTime,
    });
    
    return track;
}

function trackToString(track) {
    /**
     * Convert track data to the string format expected by Aliyun CAPTCHA.
     * Format: type:x,y,t,...  (each event on its own segment)
     */
    return track.map(p => {
        const extra = p.type === 'mc' ? '' : '';
        return `${p.x},${p.y},${p.t}`;
    }).join(';');
}

function generateTrackObject(distance, startX = 0, startY = 0) {
    const track = generateRealisticTrack(distance, startX, startY);
    const startTime = track[0].t;
    const endTime = track[track.length - 1].t;
    
    return {
        TrackList: track.map(p => ({
            type: p.type,
            x: p.x,
            y: p.y,
            t: p.t,
        })),
        TrackStartTime: startTime,
        VerifyTime: endTime - startTime,
    };
}

// ── Data Field Encryption ──────────────────────────────────────────────

function encryptTrackData(trackObject, sessionKey) {
    /**
     * Encrypt track data following the chain:
     * 1. lr() — serialize track object to string
     * 2. TextEncoder — convert to UTF-8 binary
     * 3. pako.deflate — compress
     * 4. Base64 encode
     * 5. AES-CBC encrypt with session key
     */
    
    // Step 1: Serialize track object to string
    // The format expected by the SDK
    const trackStr = JSON.stringify(trackObject);
    console.log('[Encrypt] Track string length:', trackStr.length);
    
    // Step 2: TextEncoder — UTF-8 encode
    const encoder = new TextEncoder();
    const uint8Array = encoder.encode(trackStr);
    
    // Step 3: pako.deflate — compress
    const compressed = pako.deflate(uint8Array);
    
    // Step 4: Base64 encode
    const base64Compressed = Buffer.from(compressed).toString('base64');
    
    // Step 5: AES-CBC encrypt
    const encrypted = aesEncrypt(base64Compressed, sessionKey);
    
    return encrypted;
}

// ── DeviceToken Construction ──────────────────────────────────────────

function buildDeviceToken(deviceData) {
    /**
     * Format: SG_WEB#{md5-h-timestamp-random}#{AES encrypted data}#{counter}#{hash}
     */
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 1000000);
    const hashPart = md5(`${timestamp}-${random}`);
    const prefix = `SG_WEB#${hashPart}-${timestamp}-${random}`;
    
    // Encrypt device data
    const encryptedData = aesEncrypt(JSON.stringify(deviceData), DEVICE_TOKEN_KEY);
    
    const counter = 1;
    const suffixHash = md5(`${prefix}#${encryptedData}#${counter}`);
    
    return `${prefix}#${encryptedData}#${counter}#${suffixHash}`;
}

// ── Build captchaVerifyParam ──────────────────────────────────────────

function buildCaptchaVerifyParam(sceneId, certifyId, deviceToken, dataField) {
    const param = {
        sceneId: sceneId,
        certifyId: certifyId,
        deviceToken: deviceToken,
        data: dataField,
    };
    return JSON.stringify(param);
}

// ── Log2 / Log3 Request ──────────────────────────────────────────────

function buildLogRequest(type, data, sessionKey) {
    /**
     * Build Log2 (Type=501) or Log3 (Type=combat) request data.
     */
    const encryptedData = aesEncrypt(JSON.stringify(data), sessionKey);
    return {
        Data: encryptedData,
        Type: type,
    };
}

// ── Main ──────────────────────────────────────────────────────────────

async function main() {
    const args = process.argv.slice(2);
    const command = args[0];

    if (command === '--init') {
        console.log('[Init] Calling InitCaptcha...');
        try {
            const result = await callInitCaptcha();
            console.log('[Init] Result:', JSON.stringify(result, null, 2));
            
            if (result.DeviceConfig) {
                const decrypted = decryptDeviceConfig(result.DeviceConfig);
                if (decrypted) {
                    console.log('[Init] Decrypted DeviceConfig parts:', decrypted.parts);
                }
            }
            
            // Save result for later use
            const outputPath = path.join(__dirname, 'init_result.json');
            fs.writeFileSync(outputPath, JSON.stringify(result, null, 2));
            console.log(`[Init] Result saved to ${outputPath}`);
        } catch (e) {
            console.error('[Init] Error:', e.message);
        }
    } else if (command === '--track') {
        // Generate a sample track
        const distance = parseInt(args[1] || '150');
        const track = generateTrackObject(distance);
        const outputPath = path.join(__dirname, 'sample_track.json');
        fs.writeFileSync(outputPath, JSON.stringify(track, null, 2));
        console.log(`[Track] Generated track with ${track.TrackList.length} events, distance=${distance}px`);
        console.log(`[Track] Duration: ${track.VerifyTime}ms`);
        console.log(`[Track] Saved to ${outputPath}`);
    } else if (command === '--test-encrypt') {
        // Test the encryption pipeline
        const initResult = JSON.parse(fs.readFileSync(path.join(__dirname, 'init_result.json'), 'utf8'));
        const track = generateTrackObject(150);
        
        console.log('[Test] Testing encryption pipeline...');
        console.log('[Test] Track events:', track.TrackList.length);
        console.log('[Test] Track duration:', track.VerifyTime, 'ms');
        
        // For now, test with the known session key
        // In production, this would come from DeviceConfig decryption
        const sessionKey = WEB_AES_SECRET_KEY; // Placeholder - actual key from DeviceConfig
        const encrypted = encryptTrackData(track, sessionKey);
        console.log('[Test] Encrypted data length:', encrypted.length);
        console.log('[Test] Encrypted data (first 100 chars):', encrypted.substring(0, 100));
    } else {
        console.log('Usage:');
        console.log('  node env_patch.js --init           # Call InitCaptcha API');
        console.log('  node env_patch.js --track <distance> # Generate sample track');
        console.log('  node env_patch.js --test-encrypt     # Test encryption pipeline');
    }
}

main().catch(console.error);
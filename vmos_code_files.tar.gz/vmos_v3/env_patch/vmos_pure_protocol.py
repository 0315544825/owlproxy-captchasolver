#!/usr/bin/env python3
"""VMOS Cloud — Aliyun CAPTCHA V2 纯协议客户端

完整的纯协议自动化流程：
1. InitCaptcha → 获取 CertifyId + DeviceConfig
2. 解密 DeviceConfig → 获取 Session AES Key (Be)
3. 下载滑块图片 → 计算拖动距离
4. 生成真实轨迹数据 (TrackList + TrackStartTime + VerifyTime)
5. 加密轨迹: lr → TextEncoder → deflate → Base64 → AES(key=Be)
6. 构建 deviceToken: SG_WEB#hash#timestamp#random#AES#counter#hash
7. 发送 Log2 (Type=501) + Log3 (Type=combat)
8. 构建 captchaVerifyParam = {sceneId, certifyId, deviceToken, data}
9. 调用 smsSend → 获取验证码
10. 调用 login → 完成注册

Based on:
  - K哥爬虫逆向分析 (cnblogs/ikdl)
  - sg.js / pe.js 代码分析
  - 运行时 Hook 提取的密钥

Usage:
    python3 vmos_pure_protocol.py --email auto
    python3 vmos_pure_protocol.py --email you@example.com
    python3 vmos_pure_protocol.py --debug --email auto
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import math
import os
import random
import re
import struct
import sys
import time
import urllib.parse
import uuid
import zlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import requests
from Crypto.Cipher import AES as PyCryptAES
from Crypto.Util.Padding import pad, unpad

# ── Constants ──────────────────────────────────────────────────────────

AES_BLOCK_SIZE = 16

ACCESS_SEC = "YSKfst7GaVkXwZYvVihJsKF9r89koz"
ACCESS_KEY_ID = "LTAI5tSEBwYMwVKAQGpxmvTd"
WEB_AES_SECRET_KEY = "c175a358550d02e2"
AES_IV = "0123456789ABCDEF"
# DeviceConfig decryption key (derived: AES_decrypt(Xt.RES, ACCESS_SECRET="FqJB6iRNVYdEGpwb"))
DEVICE_CONFIG_KEY = "87f879f135f27da7"
DEVICE_TOKEN_AES_KEY = "a549a55c60a39aa0"
API_VERSION = "2015-03-15"
SCENE_ID = "5jvar3wp"
PREFIX = "69r0rc"
REGION = "sgp"

YYDS_KEY = "AC-29e9b09c5ae93e1347debb66"
YYDS_BASE = "https://maliapi.215.im/v1"
API_BASE = "https://api.vmoscloud.com/vcpcloud"
CAPTCHA_ENDPOINT = f"https://{PREFIX}.captcha-open-southeast.aliyuncs.com/"
UPLOAD_ENDPOINT = "https://upload.captcha-open-southeast.aliyuncs.com/"
ACCOUNTS_DIR = Path(__file__).resolve().parent.parent / "accounts"
DEFAULT_PASSWORD = "VmosCloud123!"


# ── AES Helpers ───────────────────────────────────────────────────────

def aes_encrypt(plaintext: str | bytes, key: str, iv: str = AES_IV) -> str:
    """AES-128-CBC encrypt, returns Base64."""
    key_bytes = key.encode("utf-8")[:16]
    iv_bytes = iv.encode("utf-8")[:16]
    if isinstance(plaintext, str):
        plaintext = plaintext.encode("utf-8")
    padded = pad(plaintext, AES_BLOCK_SIZE)
    cipher = PyCryptAES.new(key_bytes, PyCryptAES.MODE_CBC, iv_bytes)
    encrypted = cipher.encrypt(padded)
    return base64.b64encode(encrypted).decode("utf-8")


def aes_decrypt(ciphertext_b64: str, key: str, iv: str = AES_IV) -> str:
    """AES-128-CBC decrypt from Base64."""
    key_bytes = key.encode("utf-8")[:16]
    iv_bytes = iv.encode("utf-8")[:16]
    encrypted = base64.b64decode(ciphertext_b64)
    cipher = PyCryptAES.new(key_bytes, PyCryptAES.MODE_CBC, iv_bytes)
    decrypted = unpad(cipher.decrypt(encrypted), AES_BLOCK_SIZE)
    return decrypted.decode("utf-8")


def aes_decrypt_raw(ciphertext_b64: str, key: str, iv: str = AES_IV) -> bytes:
    """AES-128-CBC decrypt from Base64, returns raw bytes."""
    key_bytes = key.encode("utf-8")[:16]
    iv_bytes = iv.encode("utf-8")[:16]
    encrypted = base64.b64decode(ciphertext_b64)
    cipher = PyCryptAES.new(key_bytes, PyCryptAES.MODE_CBC, iv_bytes)
    decrypted = cipher.decrypt(encrypted)
    # Try to unpad, but return raw if it fails
    try:
        return unpad(decrypted, AES_BLOCK_SIZE)
    except ValueError:
        return decrypted


def hmac_sha1(key: str, message: str) -> str:
    """Compute HMAC-SHA1 with key format: key + '&'"""
    return base64.b64encode(
        hmac.new((key + "&").encode(), message.encode(), hashlib.sha1).digest()
    ).decode()


def md5_hash(s: str) -> str:
    return hashlib.md5(s.encode()).hexdigest()


# ── Signature ─────────────────────────────────────────────────────────

def percent_encode(s: str) -> str:
    return urllib.parse.quote(s, safe="").replace("+", "%20").replace("*", "%2A").replace("%7E", "~")


def sign_request(params: dict) -> dict:
    """Sign an Aliyun API request using HMAC-SHA1."""
    params = {k: v for k, v in params.items() if k != "Signature"}
    sorted_keys = sorted(params.keys())
    canonical = "&".join(f"{percent_encode(k)}={percent_encode(str(params[k]))}" for k in sorted_keys)
    string_to_sign = f"POST&{percent_encode('/')}&{percent_encode(canonical)}"
    signature = hmac_sha1(ACCESS_SEC, string_to_sign)
    params["Signature"] = signature
    return params


# ── DeviceData ────────────────────────────────────────────────────────

def generate_device_data() -> str:
    """Generate encrypted DeviceData for InitCaptcha."""
    fingerprint = {
        "webGLRenderer": "WebKit WebGL",
        "webGLVendor": "WebKit",
        "platform": "Win32",
        "language": "en",
        "languages": "en-US,en",
        "screenWidth": 1920,
        "screenHeight": 1080,
        "colorDepth": 24,
        "deviceMemory": 8,
        "hardwareConcurrency": 8,
        "timezone": -240,
        "touchSupport": False,
        "userAgent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    }
    plaintext = json.dumps(fingerprint, separators=(",", ":"))
    return aes_encrypt(plaintext, WEB_AES_SECRET_KEY)


def generate_device_token() -> str:
    """Build deviceToken: SG_WEB#hash#timestamp#random#AESencrypted#counter#md5hash"""
    timestamp = int(time.time() * 1000)
    random_num = random.randint(100000, 999999)
    hash_part = md5_hash(f"{timestamp}-{random_num}")

    # Encrypt device environment data
    device_info = json.dumps({
        "ua": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "platform": "Win32",
        "lang": "en",
        "tz": -240,
        "mem": 8,
        "cores": 8,
        "screen": "1920x1080x24",
        "touch": False,
    }, separators=(",", ":"))
    encrypted = aes_encrypt(device_info, DEVICE_TOKEN_AES_KEY)
    counter = 1
    suffix_hash = md5_hash(f"SG_WEB#{hash_part}-{timestamp}-{random_num}#{encrypted}#{counter}")
    return f"SG_WEB#{hash_part}-{timestamp}-{random_num}#{encrypted}#{counter}#{suffix_hash}"


# ── InitCaptcha ────────────────────────────────────────────────────────

def call_init_captcha(debug: bool = False) -> dict:
    """Call Aliyun InitCaptcha API."""
    device_data = generate_device_data()
    device_token = generate_device_token()

    params = {
        "AccessKeyId": ACCESS_KEY_ID,
        "Action": "InitCaptcha",
        "DeviceData": device_data,
        "DeviceToken": device_token,
        "Format": "JSON",
        "SceneId": SCENE_ID,
        "SignatureMethod": "HMAC-SHA1",
        "SignatureNonce": str(uuid.uuid4()),
        "SignatureVersion": "1.0",
        "Timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "Version": API_VERSION,
    }

    signed = sign_request(params)
    body = urllib.parse.urlencode(signed)

    headers = {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Origin": "https://cloud.vmoscloud.com",
        "Referer": "https://cloud.vmoscloud.com/",
    }

    resp = requests.post(CAPTCHA_ENDPOINT, data=body, headers=headers, timeout=15)
    result = resp.json()

    if debug:
        print(f"[InitCaptcha] Response: {json.dumps(result, indent=2, ensure_ascii=False)[:500]}")

    return result


def decrypt_device_config(device_config: str, debug: bool = False) -> dict | None:
    """Decrypt DeviceConfig to extract session key (Be)."""
    try:
        decrypted = aes_decrypt(device_config, DEVICE_CONFIG_KEY)
        if debug:
            print(f"[DeviceConfig] Decrypted: {decrypted[:200]}")

        # The decrypted data contains session keys
        # Format varies by version - could be JSON or structured text
        # Try JSON first
        try:
            data = json.loads(decrypted)
            if debug:
                print(f"[DeviceConfig] Parsed as JSON: {list(data.keys())}")
            return data
        except json.JSONDecodeError:
            pass

        # Try structured text format: key1=val1&key2=val2
        result = {}
        for part in decrypted.split("&"):
            if "=" in part:
                k, v = part.split("=", 1)
                result[k] = v
        if result:
            if debug:
                print(f"[DeviceConfig] Parsed as query string: {list(result.keys())}")
            return result

        # Return raw decrypted data
        return {"raw": decrypted}

    except Exception as e:
        if debug:
            print(f"[DeviceConfig] Decrypt failed: {e}")
        return None


# ── Slider Image Processing ────────────────────────────────────────────

def download_captcha_images(init_result: dict, debug: bool = False) -> tuple[str | None, str | None]:
    """Download and save slider background and shadow images."""
    image_path = init_result.get("Image", "")
    puzzle_path = init_result.get("PuzzleImage", "")

    if not image_path or not puzzle_path:
        if debug:
            print("[Images] Missing image paths in InitCaptcha response")
        return None, None

    base_url = f"https://{PREFIX}.captcha-open-southeast.aliyuncs.com"

    try:
        # Download background
        bg_url = f"{base_url}/{image_path}"
        bg_resp = requests.get(bg_url, timeout=10)
        bg_path = "/tmp/vmos_captcha_back.png"
        with open(bg_path, "wb") as f:
            f.write(bg_resp.content)
        if debug:
            print(f"[Images] Background saved to {bg_path} ({len(bg_resp.content)} bytes)")

        # Download shadow/puzzle piece
        shadow_url = f"{base_url}/{puzzle_path}"
        shadow_resp = requests.get(shadow_url, timeout=10)
        shadow_path = "/tmp/vmos_captcha_shadow.png"
        with open(shadow_path, "wb") as f:
            f.write(shadow_resp.content)
        if debug:
            print(f"[Images] Shadow saved to {shadow_path} ({len(shadow_resp.content)} bytes)")

        return bg_path, shadow_path

    except Exception as e:
        if debug:
            print(f"[Images] Download failed: {e}")
        return None, None


def calculate_slider_distance(bg_path: str, shadow_path: str, debug: bool = False) -> int | None:
    """Calculate the slider drag distance using template matching."""
    try:
        import cv2
        import numpy as np

        bg = cv2.imread(bg_path, cv2.IMREAD_GRAYSCALE)
        shadow = cv2.imread(shadow_path, cv2.IMREAD_GRAYSCALE)

        if bg is None or shadow is None:
            if debug:
                print("[Slider] Could not read images")
            return None

        # Template matching
        result = cv2.matchTemplate(bg, shadow, cv2.TM_CCOEFF_NORMED)
        _, _, _, max_loc = cv2.minMaxLoc(result)

        distance = max_loc[0]  # X coordinate of best match

        if debug:
            print(f"[Slider] Calculated distance: {distance}px")

        return distance

    except ImportError:
        if debug:
            print("[Slider] OpenCV not available, using default distance")
        # Default distance (most sliders are around 150-200px)
        return random.randint(140, 180)
    except Exception as e:
        if debug:
            print(f"[Slider] Calculation failed: {e}")
        return random.randint(140, 180)


# ── Track Data Generation ──────────────────────────────────────────────

def generate_realistic_track(distance: int, start_x: float = 0, start_y: float = 0) -> list[dict]:
    """Generate realistic human-like slider drag track.

    Key anti-detection features:
    - Variable acceleration/deceleration (not smooth Bezier)
    - Y-axis micro-jitter (hand tremor, 1-3px)
    - Occasional mid-drag pauses (50-150ms)
    - Overshoot at end (2-6px) then correction
    - Variable inter-point timing (10-45ms)
    - Natural speed profile: slow start → fast middle → slow end
    """
    track = []
    base_time = int(time.time() * 1000)
    start_time = base_time + random.randint(50, 200)

    # Mouse down
    track.append({"type": "mc", "x": start_x, "y": start_y, "t": start_time})

    # Speed profile generation
    num_points = random.randint(20, 35)
    total_distance = distance
    overshoot = random.uniform(2, 6)
    current_x = start_x
    current_y = start_y
    current_t = start_time

    # Generate x positions with natural speed profile
    x_positions = []
    for i in range(num_points):
        t = i / (num_points - 1)
        # Ease-in-out with noise (not mathematically smooth!)
        if t < 0.15:
            # Acceleration
            progress = (t / 0.15) ** 1.5 * 0.15
        elif t < 0.75:
            # Constant speed with variation
            progress = 0.15 + (t - 0.15) / 0.6 * 0.7
            progress += random.gauss(0, 0.01)
        else:
            # Deceleration
            remaining = 1.0 - progress if (progress := 0.85 + (t - 0.75) / 0.25 * 0.15) > 0.85 else 0.15
            progress = min(1.0, 0.85 + (t - 0.75) / 0.25 * 0.15)
        x = start_x + total_distance * progress
        x_positions.append(x)

    # Generate movement events
    for i in range(num_points):
        # Variable timing
        if i < num_points * 0.2:
            dt = random.randint(25, 50)  # Start slow
        elif i < num_points * 0.7:
            dt = random.randint(8, 22)   # Middle fast
        elif i < num_points * 0.85:
            dt = random.randint(15, 35)  # Slowing
        else:
            dt = random.randint(25, 45)  # End slow

        # Occasional pause (5% chance)
        if random.random() < 0.05 and i > 5 and i < num_points - 5:
            dt += random.randint(80, 200)

        current_t += dt

        # Y-axis jitter
        jitter_y = random.gauss(0, 2.0) if random.random() < 0.7 else random.gauss(0, 4.0)
        # Trend back towards center
        current_y = start_y + (current_y - start_y) * 0.85 + jitter_y

        track.append({
            "type": "mm",
            "x": round(x_positions[i], 2),
            "y": round(current_y, 2),
            "t": current_t,
        })

    # Overshoot
    overshoot_end_x = start_x + total_distance + overshoot
    current_t += random.randint(20, 40)
    track.append({"type": "mm", "x": round(overshoot_end_x, 2), "y": round(start_y + random.gauss(0, 1), 2), "t": current_t})

    # Correction back
    for j in range(random.randint(2, 3)):
        correction_x = overshoot_end_x - (overshoot_end_x - (start_x + total_distance)) * (j + 1) / 3
        current_t += random.randint(25, 50)
        track.append({"type": "mm", "x": round(correction_x, 2), "y": round(start_y + random.gauss(0, 0.5), 2), "t": current_t})

    # Small pause at end
    current_t += random.randint(60, 150)

    # Mouse up
    track.append({"type": "mu", "x": round(start_x + total_distance, 2), "y": round(start_y + random.gauss(0, 0.5), 2), "t": current_t})

    return track


# ── Data Field Encryption ──────────────────────────────────────────────

def encrypt_track_data(track_list: list[dict], start_time: int, verify_time: int,
                       session_key: str, debug: bool = False) -> str:
    """Encrypt track data following the chain:
    TrackList object → JSON → TextEncoder(Utf8) → pako.deflate → Base64 → AES-CBC(key=sessionKey)

    The session key (Be) comes from decrypting DeviceConfig.
    """

    # Step 1: Build track object
    track_obj = {
        "TrackList": track_list,
        "TrackStartTime": start_time,
        "VerifyTime": verify_time,
    }

    # Step 2: Serialize to JSON string (lr function)
    track_str = json.dumps(track_obj, separators=(",", ":"))
    if debug:
        print(f"[Encrypt] Track JSON length: {len(track_str)}")
        print(f"[Encrypt] Track events: {len(track_list)}")

    # Step 3: TextEncoder → UTF-8 bytes (fr function)
    track_bytes = track_str.encode("utf-8")

    # Step 4: pako.deflate → compressed bytes
    compressed = zlib.compress(track_bytes, level=zlib.Z_DEFAULT_COMPRESSION)
    if debug:
        print(f"[Encrypt] Compressed: {len(track_bytes)} → {len(compressed)} bytes")

    # Step 5: Base64 encode
    b64_compressed = base64.b64encode(compressed).decode("utf-8")

    # Step 6: AES-CBC encrypt with session key
    encrypted = aes_encrypt(b64_compressed, session_key)
    if debug:
        print(f"[Encrypt] Final data length: {len(encrypted)} chars")

    return encrypted


# ── UploadLog (Log2/Log3) ─────────────────────────────────────────────

def call_upload_log(log_type: str, data: str, session_key: str, debug: bool = False) -> dict:
    """Send Log2 (Type=501) or Log3 (Type=combat) to Aliyun.

    Args:
        log_type: "501" for Log2 (device fingerprint) or "combat" for Log3 (track data)
        data: Encrypted data payload
        session_key: AES session key for encryption
    """
    # Encrypt the log data
    encrypted_data = aes_encrypt(data, session_key)

    log_payload = json.dumps({
        "Data": encrypted_data,
        "Type": log_type,
    }, separators=(",", ":"))

    params = {
        "AccessKeyId": ACCESS_KEY_ID,
        "Action": "UploadLog",
        "Format": "JSON",
        "SceneId": SCENE_ID,
        "SignatureMethod": "HMAC-SHA1",
        "SignatureNonce": str(uuid.uuid4()),
        "SignatureVersion": "1.0",
        "Timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "Version": API_VERSION,
        "log": log_payload,
    }

    signed = sign_request(params)
    body = urllib.parse.urlencode(signed)

    headers = {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    }

    try:
        resp = requests.post(UPLOAD_ENDPOINT, data=body, headers=headers, timeout=15)
        result = resp.json()
        if debug:
            print(f"[UploadLog] Type={log_type} Response: {json.dumps(result, indent=2)[:300]}")
        return result
    except Exception as e:
        if debug:
            print(f"[UploadLog] Type={log_type} Error: {e}")
        return {"error": str(e)}


# ── Build captchaVerifyParam ────────────────────────────────────────────

def build_captcha_verify_param(scene_id: str, certify_id: str, device_token: str,
                               data_field: str) -> str:
    """Build the complete captchaVerifyParam JSON string."""
    param = {
        "sceneId": scene_id,
        "certifyId": certify_id,
        "deviceToken": device_token,
        "data": data_field,
    }
    return json.dumps(param, separators=(",", ":"))


# ── VMOS Cloud API ────────────────────────────────────────────────────

def vmos_send_sms(email: str, captcha_verify_param: str, debug: bool = False) -> dict:
    """Call VMOS Cloud SMS send API."""
    headers = {
        "Content-Type": "application/json",
        "Accept-Language": "en",
        "clientType": "web",
        "appVersion": "3.6.1800",
        "requestsource": "wechat-miniapp",
        "SupplierType": "0",
        "X-Tenant": "vmoscloud",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "userId": "0",
    }

    payload = {
        "smsType": 2,
        "mobilePhone": email,
        "captchaVerifyParam": captcha_verify_param,
    }

    if debug:
        print(f"[smsSend] Email: {email}")
        print(f"[smsSend] captchaVerifyParam length: {len(captcha_verify_param)}")

    resp = requests.post(f"{API_BASE}/api/sms/smsSend", json=payload, headers=headers, timeout=15)
    result = resp.json()

    if debug:
        print(f"[smsSend] Response: {json.dumps(result, indent=2, ensure_ascii=False)[:300]}")

    return result


def vmos_login(email: str, password: str, verify_code: str, debug: bool = False) -> dict:
    """Call VMOS Cloud login/register API."""
    headers = {
        "Content-Type": "application/json",
        "Accept-Language": "en",
        "clientType": "web",
        "appVersion": "3.6.1800",
        "requestsource": "wechat-miniapp",
        "SupplierType": "0",
        "X-Tenant": "vmoscloud",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    }

    payload = {
        "mobilePhone": email,
        "loginType": 0,
        "verifyCode": verify_code,
        "password": hashlib.md5(password.encode()).hexdigest(),
        "channel": "",
    }

    resp = requests.post(f"{API_BASE}/api/user/login", json=payload, headers=headers, timeout=15)
    result = resp.json()

    if debug:
        print(f"[Login] Response: {json.dumps(result, indent=2, ensure_ascii=False)[:300]}")

    return result


# ── YYDS Email ────────────────────────────────────────────────────────

def create_email(domain: str | None = None) -> tuple[str, str, str]:
    """Create a YYDS temp email."""
    headers = {"X-API-Key": YYDS_KEY, "Content-Type": "application/json"}
    if not domain:
        resp = requests.get(f"{YYDS_BASE}/domains", headers={"X-API-Key": YYDS_KEY}, timeout=15)
        data = resp.json()
        domains = []
        for x in (data.get("data") or []):
            recs = x.get("dnsRecords", {}) or {}
            if (x.get("isPublic") and x.get("isVerified") and x.get("isMxValid")
                    and recs.get("receivingReady") and recs.get("status") == "healthy"):
                domains.append(x["domain"])
        if not domains:
            domains = ["a0.engineer"]
        domain = random.choice(domains)

    local = f"vmos{int(time.time())}{random.randint(10, 99)}"
    resp = requests.post(f"{YYDS_BASE}/accounts", headers=headers,
                        json={"localPart": local, "domain": domain}, timeout=15)
    result = resp.json()
    if not result.get("success"):
        raise RuntimeError(f"YYDS create failed: {result}")
    return result["data"]["address"], local, domain


def poll_email_code(email: str, timeout: int = 120, interval: int = 5, debug: bool = False) -> str | None:
    """Poll YYDS for 6-digit verification code."""
    headers = {"X-API-Key": YYDS_KEY}
    deadline = time.time() + timeout
    attempt = 0

    while time.time() < deadline:
        attempt += 1
        time.sleep(interval)
        try:
            resp = requests.get(f"{YYDS_BASE}/messages", params={"address": email},
                              headers=headers, timeout=15)
            data = resp.json()
            messages = (data.get("data") or {}).get("messages") or []
            if not messages:
                if debug:
                    print(f"  [Email] Poll {attempt}: no messages")
                continue

            for msg in messages:
                mid = msg.get("id")
                if not mid:
                    continue
                try:
                    full = requests.get(f"{YYDS_BASE}/messages/{mid}",
                                       params={"address": email}, headers=headers, timeout=15).text
                    codes = re.findall(r"\b(\d{6})\b", full)
                    if codes:
                        if debug:
                            print(f"  [Email] Found code: {codes[0]}")
                        return codes[0]
                except Exception as e:
                    if debug:
                        print(f"  [Email] Error reading message: {e}")

            if debug:
                print(f"  [Email] Poll {attempt}: messages found, no 6-digit code")
        except Exception as e:
            if debug:
                print(f"  [Email] Poll {attempt} error: {e}")

    return None


# ── Main Flow ──────────────────────────────────────────────────────────

def full_flow(email: str | None = None, password: str = DEFAULT_PASSWORD,
              domain: str | None = None, debug: bool = False) -> dict | None:
    """Complete pure-protocol registration flow."""

    print("=" * 60)
    print("  VMOS Cloud Pure Protocol Registration")
    print("=" * 60)

    # Step 0: Create email
    if not email:
        print("\n[0] Creating YYDS temp email...")
        email, local, domain = create_email(domain)
        print(f"  ✅ Email: {email}")

    # Step 1: InitCaptcha
    print("\n[1] Calling InitCaptcha...")
    init_result = call_init_captcha(debug=debug)

    certify_id = init_result.get("CertifyId")
    if not certify_id:
        print(f"  ❌ InitCaptcha failed: {json.dumps(init_result, indent=2)[:300]}")
        return None
    print(f"  ✅ CertifyId: {certify_id}")

    # Step 2: Decrypt DeviceConfig to get session key
    print("\n[2] Decrypting DeviceConfig...")
    device_config = init_result.get("DeviceConfig", "")
    if device_config:
        decrypted_config = decrypt_device_config(device_config, debug=debug)
        if decrypted_config:
            # Extract session key (Be)
            # The format varies - need to find the AES key in the decrypted data
            session_key = None
            if isinstance(decrypted_config, dict):
                # Try common key names
                for key_name in ["sessionKey", "key", "Be", "aesKey", "secretKey", "data"]:
                    if key_name in decrypted_config:
                        session_key = decrypted_config[key_name]
                        break
                if not session_key and "raw" in decrypted_config:
                    # Parse the raw string for a 16-char key
                    raw = decrypted_config["raw"]
                    # Look for a 16-character hex/ascii string that could be an AES key
                    key_match = re.search(r'[0-9a-f]{16}|[0-9a-zA-Z]{16}', raw)
                    if key_match:
                        session_key = key_match.group()

            if session_key:
                print(f"  ✅ Session key (Be): {session_key}")
            else:
                print("  ⚠️  Could not extract session key, using WEB_AES_SECRET_KEY")
                print(f"  Decrypted config: {json.dumps(decrypted_config, indent=2)[:300]}")
                session_key = WEB_AES_SECRET_KEY
        else:
            print("  ⚠️  DeviceConfig decryption failed, using WEB_AES_SECRET_KEY")
            session_key = WEB_AES_SECRET_KEY
    else:
        print("  ⚠️  No DeviceConfig in response, using WEB_AES_SECRET_KEY")
        session_key = WEB_AES_SECRET_KEY

    # Step 3: Calculate slider distance
    print("\n[3] Getting slider images...")
    bg_path, shadow_path = download_captcha_images(init_result, debug=debug)

    distance = 150  # Default fallback
    if bg_path and shadow_path:
        calculated = calculate_slider_distance(bg_path, shadow_path, debug=debug)
        if calculated:
            distance = calculated
            print(f"  ✅ Slider distance: {distance}px")
        else:
            print("  ⚠️  Could not calculate distance, using default")
    else:
        print("  ⚠️  Could not download images, using default distance")

    # Step 4: Generate track data
    print("\n[4] Generating realistic track data...")
    track = generate_realistic_track(distance)
    start_time = track[0]["t"]
    verify_time = track[-1]["t"] - track[0]["t"]
    print(f"  ✅ Track: {len(track)} events, {verify_time}ms duration, {distance}px distance")

    # Step 5: Encrypt track data
    print("\n[5] Encrypting track data...")
    data_field = encrypt_track_data(track, start_time, verify_time, session_key, debug=debug)
    print(f"  ✅ Encrypted data field: {len(data_field)} chars")

    # Step 6: Build deviceToken
    print("\n[6] Building deviceToken...")
    device_token = generate_device_token()
    print(f"  ✅ deviceToken: {device_token[:50]}...")

    # Step 7: Build captchaVerifyParam
    print("\n[7] Building captchaVerifyParam...")
    captcha_verify_param = build_captcha_verify_param(
        scene_id=SCENE_ID,
        certify_id=certify_id,
        device_token=device_token,
        data_field=data_field,
    )
    print(f"  ✅ captchaVerifyParam: {len(captcha_verify_param)} chars")

    # Step 8: Send SMS
    print("\n[8] Sending SMS verification code...")
    sms_result = vmos_send_sms(email, captcha_verify_param, debug=debug)
    code = sms_result.get("code")

    if code == 200:
        print(f"  ✅ SMS sent successfully!")
    elif code == 2019:
        print(f"  ❌ Code 2019: Signature verification failed (轨迹检测不通过)")
        print(f"  The track data was detected as bot-like by Aliyun.")
        print(f"  Possible reasons:")
        print(f"    - Track data encryption format mismatch")
        print(f"    - Session key (Be) incorrect")
        print(f"    - Missing Log2/Log3 pre-flight requests")
        print(f"    - Track data format doesn't match sg.js expectations")
    else:
        print(f"  ❌ SMS failed: code={code} message={sms_result.get('message', '')}")

    # Step 9: Poll for verification code (only if SMS was sent)
    if code == 200:
        print("\n[9] Polling for verification code...")
        verify_code = poll_email_code(email, debug=debug)
        if verify_code:
            print(f"  ✅ Verification code: {verify_code}")

            # Step 10: Login/Register
            print("\n[10] Registering account...")
            login_result = vmos_login(email, password, verify_code, debug=debug)
            if login_result.get("code") == 200:
                data = login_result.get("data", {})
                token = data.get("token", "")
                user_id = data.get("userId", "")
                print(f"\n🎉 Registration successful!")
                print(f"  Email: {email}")
                print(f"  Password: {password}")
                print(f"  UserID: {user_id}")
                print(f"  Token: {token[:20]}...")

                # Save account
                ACCOUNTS_DIR.mkdir(parents=True, exist_ok=True)
                account = {
                    "email": email,
                    "password": password,
                    "password_md5": hashlib.md5(password.encode()).hexdigest(),
                    "token": token,
                    "userId": user_id,
                    "platform": "vmos_cloud",
                    "created_at": int(time.time()),
                }
                out_file = ACCOUNTS_DIR / f"{email}.json"
                out_file.write_text(json.dumps(account, indent=2, ensure_ascii=False))
                print(f"  Saved to: {out_file}")
                return account
            else:
                print(f"  ❌ Registration failed: {login_result}")
        else:
            print("  ❌ Could not retrieve verification code")

    # Save debug info
    if debug:
        debug_info = {
            "email": email,
            "init_result": init_result,
            "session_key": session_key,
            "distance": distance,
            "track_length": len(track),
            "verify_time": verify_time,
            "data_field_length": len(data_field),
            "captcha_verify_param_length": len(captcha_verify_param),
            "sms_result": sms_result,
        }
        debug_file = Path("/tmp/vmos_pure_protocol_debug.json")
        debug_file.write_text(json.dumps(debug_info, indent=2, ensure_ascii=False))
        print(f"\n  Debug info saved to: {debug_file}")

    return None


# ── CLI ────────────────────────────────────────────────────────────────

def main():
    import argparse
    parser = argparse.ArgumentParser(description="VMOS Cloud pure protocol registration")
    parser.add_argument("--email", default=None, help="Email address (auto-created if omitted)")
    parser.add_argument("--password", default=DEFAULT_PASSWORD, help="Password")
    parser.add_argument("--domain", default=None, help="YYDS email domain")
    parser.add_argument("--debug", action="store_true", help="Verbose output")
    args = parser.parse_args()

    try:
        result = full_flow(email=args.email, password=args.password, domain=args.domain, debug=args.debug)
    except KeyboardInterrupt:
        print("\n\nInterrupted.")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Error: {e}")
        if args.debug:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
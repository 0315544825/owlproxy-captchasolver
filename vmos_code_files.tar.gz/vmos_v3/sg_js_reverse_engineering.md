# 阿里云滑块验证码 sg.js 逆向分析

## 完整请求流程（已实际抓包验证）

### 第1步：InitCaptcha（初始化）

```
POST https://69r0rc.captcha-open-southeast.aliyuncs.com/

参数：
  AccessKeyId: LTAI5tSEBwYMwVKAQGpxmvTd     ← 阿里云 AccessKey（公开）
  SignatureMethod: HMAC-SHA1                   ← 签名算法
  SignatureVersion: 1.0
  Format: JSON
  Timestamp: 2026-06-21T06:00:12Z
  Version: 2023-03-05
  Action: InitCaptcha
  SceneId: 5jvar3wp                            ← VMOS 的场景ID
  Language: en
  Mode: popup
  DeviceData: TEQYvgJq1LrMqFaBybfIzPxz2yg...  ← AES加密的浏览器指纹

返回：
  CertifyId: "p30vHZaR6X"                      ← 会话ID（后续所有请求需要）
  Image: "qst/PUZZLE/online/787/.../back.png"  ← 背景图
  PuzzleImage: "...shadow.png"                 ← 拼图块
  StaticPath: "3.25.0/pe.082.e30f0beb600b68d7" ← 动态JS版本号
  DeviceConfig: "rkVCJv+RmFj+LntqggCF6..."     ← AES加密的配置（含加密key）
```

### 第2步：Log2（环境数据上报）

```
POST https://cloudauth-device-dualstack.ap-southeast-1.aliyuncs.com/

参数：
  AccessKeyId: LTAI5tGjnK9uu9GbT9GQw72p      ← 不同的AccessKey（设备验证用）
  Version: 2020-10-15
  SignatureMethod: HMAC-SHA1
  Action: Log2
  Data: Ej9GZkW5iOocEOE2/RNjAR5FTqi1Wy...     ← AES加密的环境指纹数据
  Signature: <HMAC-SHA1签名>

返回：{"ResultObject": true, "Code": "200"}
```

**Log2 Data 内容（AES加密前的明文结构）**：
- 浏览器类型和版本
- 屏幕分辨率
- 时区
- 语言设置
- Canvas 指纹
- WebGL 渲染器信息
- 已安装字体列表
- AudioContext 指纹
- navigator 属性（platform, hardwareConcurrency, etc.）
- 插件列表

### 第3步：Log3（轨迹数据上报）⭐ 关键！

```
POST https://cloudauth-device-dualstack.ap-southeast-1.aliyuncs.com/

参数：
  AccessKeyId: LTAI5tGjnK9uu9GbT9GQw72p
  Version: 2020-10-15
  SignatureMethod: HMAC-SHA1
  Action: Log3
  Data: Ej9GZkW5iOocEOE2/RNjAR5FTqi1WyfeP...    ← AES加密的轨迹数据
  Signature: <HMAC-SHA1签名>

返回：{"ResultObject": true, "Code": "200"}
```

**Log3 Data 内容（AES加密前的明文结构）**：
```json
{
  "TrackList": [[x, y, timestamp], ...],    ← 鼠标轨迹坐标序列
  "TrackStartTime": 1782021613108,          ← 开始时间戳
  "VerifyTime": 1782021612700,               ← 验证时间戳
  // 可能还有：
  "startX": 510,                            ← 滑块起始X
  "startY": 484,                            ← 滑块起始Y
  "endX": 660,                              ← 滑块结束X
  "endY": 484,                              ← 滑块结束Y
  "type": "slide"                            ← 操作类型
}
```

### 第4步：UploadLog（行为日志上报）

```
POST https://upload.captcha-open-southeast.aliyuncs.com/

参数：
  log: {"sId":"5jvar3wp","pfx":"69r0rc","mInit":{"t":1782021613108,"s":true,...},...}
```

### 第5步：2nd InitCaptcha（验证结果）

```
POST https://69r0rc.captcha-open-southeast.aliyuncs.com/

参数：
  Action: InitCaptcha
  SceneId: 5jvar3wp
  CertifyId: p30vHZaR6X                     ← 第1步返回的会话ID
  DeviceToken: U0dfV0VCIzM3OTVkMjgyND...   ← FeiLin生成的设备令牌

返回新的 CertifyId 和新的验证码图片（如果需要刷新）
```

## 加密链条详解

### 1. 签名生成（HMAC-SHA1）

```
签名流程：
1. 将所有请求参数按字母排序
2. 拼接成 query string: AccessKeyId=xxx&Action=Log2&Data=xxx&...
3. 使用 HMAC-SHA1(ACCESS_KEY.SECRET, query_string) 生成签名
4. Base64 编码签名
5. 添加到请求参数中

ACCESS_KEY:  LTAI5tSEBwYMwVKAQGpxmvTd (InitCaptcha用)
ACCESS_SEC:  从 FeiLin 代码中的混淆值解密得到 (用于 HMAC-SHA1)
```

从 FeiLin 源码中找到：
```javascript
var rN = window.__ALIYUN_CRYPT;
var rx = rN.HmacSHA1;          // HMAC-SHA1 函数
var rU = rN.enc.Base64;        // Base64 编码
var rA = rM(t9.ACCESS_SEC, t9.ACCESS_KEY.SECRET);  // 用 ACCESS_SEC 和 ACCESS_KEY.SECRET 生成 HMAC 密钥

function rJ(t, r) {
    delete t.Signature;
    var e = Object.keys(t);
    e.sort();
    // ... 拼接参数，生成签名
}
```

### 2. Data 加密（AES）

```
加密流程：
1. 明文数据 → JSON.stringify → TextEncoder → UTF-8 bytes
2. pako.deflate (zlib 压缩) → Base64
3. 从 InitCaptcha 返回的 DeviceConfig 中解密得到 AES Key 和 IV
4. AES-CBC 加密 (Key, IV, Data)
5. Base64 编码 → Data 参数值

DeviceConfig 结构（AES加密）：
  - AES Key（用于后续 Data 加密）
  - IV（初始化向量）
  - 其他配置信息

DeviceConfig 解密密钥：硬编码在 FeiLin 代码中（经过多层混淆）
```

### 3. DeviceToken 生成

```
DeviceToken 生成流程：
1. 采集浏览器指纹（Canvas, WebGL, 字体, 屏幕等）
2. JSON 序列化
3. AES 加密（使用从 DeviceConfig 解密得到的 Key）
4. Base64 编码
5. 添加前缀 "SWF#" → "U0dfV0VCIz..." (Base64 of "SWF#")

DeviceToken 包含的指纹数据：
  - Canvas 2D 渲染指纹
  - WebGL 渲染器和供应商
  - 已安装字体列表
  - 屏幕分辨率和色深
  - 时区偏移
  - 语言和语言列表
  - 平台信息
  - 硬件并发数
  - 插件列表
  - AudioContext 指纹
```

## 关键发现

### 为什么自动化被检测？

1. **Log2（环境数据）** 中的浏览器指纹与 Playwright/Selenium 特征不匹配
   - 即使用 CloakBrowser，某些深层指纹仍可能暴露

2. **Log3（轨迹数据）** 中的轨迹特征被行为模型判定为机器人
   - 轨迹过于平滑（Bézier曲线）
   - 时间间隔过于均匀
   - 缺乏自然的人类手颤特征
   - 加速度变化不符合人类运动学模型

3. **签名验证** 是多层的
   - 每个 API 请求都需要 HMAC-SHA1 签名
   - 签名密钥从 FeiLin 混淆代码中获取
   - 即使 Data 格式正确，如果内容被判定为机器人，smsSend 仍返回 2019

### 逆向难度评估

| 环节 | 难度 | 说明 |
|------|------|------|
| HMAC-SHA1 签名 | ⭐⭐ | 密钥在混淆代码中，但可以提取 |
| AES Data 加密 | ⭐⭐⭐ | Key 从 DeviceConfig 解密，需要先逆向 Key 提取逻辑 |
| DeviceToken 生成 | ⭐⭐⭐⭐ | 需要伪造完整的浏览器指纹 |
| 轨迹数据构造 | ⭐⭐⭐⭐⭐ | 核心难点，需要通过阿里云的行为模型检测 |
| 行为模型绕过 | ⭐⭐⭐⭐⭐+ | 机器学习模型，持续训练更新，几乎不可能静态绕过 |

### 关键参数汇总

| 参数 | 来源 | 说明 |
|------|------|------|
| AccessKeyId (InitCaptcha) | `LTAI5tSEBwYMwVKAQGpxmvTd` | 阿里云 RAM 用户的 AccessKey |
| AccessKeyId (Log2/Log3) | `LTAI5tGjnK9uu9GbT9GQw72p` | 设备验证用的不同 AccessKey |
| SceneId | `5jvar3wp` | VMOS Cloud 的场景ID |
| Prefix | `69r0rc` | 区域前缀（新加坡） |
| Endpoint (InitCaptcha) | `69r0rc.captcha-open-southeast.aliyuncs.com` | 验证码API |
| Endpoint (Log2/Log3) | `cloudauth-device-dualstack.ap-southeast-1.aliyuncs.com` | 设备验证API |
| Endpoint (UploadLog) | `upload.captcha-open-southeast.aliyuncs.com` | 日志上报 |

### JS 文件清单

| 文件 | 大小 | 作用 |
|------|------|------|
| AliyunCaptcha.js | 221KB | 主SDK，初始化+UI渲染+事件绑定 |
| feilin081.*.js | 563KB | 核心加密引擎：指纹采集+AES+HMAC-SHA1+轨迹加密 |
| pe.082.*.js | 445KB | 动态加载模块：验证码渲染+滑块交互+验证逻辑 |
| main.css | 13KB | 验证码样式 |

### 要完全破解需要做的事

1. **提取 AES 密钥生成逻辑** — 从 FeiLin 的混淆代码中提取 DeviceConfig 解密和 Data 加密的 Key/IV
2. **构造合法的 DeviceToken** — 伪造完整的浏览器指纹 JSON，AES 加密后 Base64 编码
3. **生成 HMAC-SHA1 签名** — 使用 ACCESS_SEC 对请求参数签名
4. **构造能通过行为模型的轨迹数据** — 这是**最难的部分**，需要：
   - 从真人操作中采集大量轨迹数据
   - 训练一个模型来判断轨迹是否像真人
   - 或者逆向阿里云的检测模型（几乎不可能）
5. **处理版本更新** — sg.js 版本频繁更新（pe.055 → pe.062 → pe.082），密钥和算法可能变化
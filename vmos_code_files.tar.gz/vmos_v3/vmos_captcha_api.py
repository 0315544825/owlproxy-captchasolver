#!/usr/bin/env python3
"""VMOS Cloud Aliyun CAPTCHA — Pure API client (no browser needed for InitCaptcha).

Extracted constants from sg.js runtime hooking:
  - ACCESS_SEC: YSKfst7GaVkXwZYvVihJsKF9r89koz
  - ACCESS_KEY_ID: LTAI5tSEBwYMwVKAQGpxmvTd
  - WEB_AES_SECRET_KEY: c175a358550d02e2
  - AES_IV: 0123456789ABCDEF

This script can:
  1. Call InitCaptcha with proper HMAC-SHA1 signing
  2. Encrypt DeviceData with AES-CBC
  3. Parse the response to get slider config
  4. (Future) Solve the slider and call verification

Usage:
    python3 vmos_captcha_api.py init          # Call InitCaptcha
    python3 vmos_captcha_api.py init --debug   # Debug mode with verbose output
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import random
import string
import sys
import time
import urllib.parse
import uuid
from datetime import datetime, timezone
from pathlib import Path

import pako
import requests
from Crypto.Cipher import AES as PyCryptAES
from Crypto.Util.Padding import pad, unpad

AES_BLOCK_SIZE = 16

# ── Extracted Constants ──────────────────────────────────────────────

ACCESS_KEY_ID = "LTAI5tSEBwYMwVKAQGpxmvTd"
ACCESS_SEC = "YSKfst7GaVkXwZYvVihJsKF9r89koz"
WEB_AES_SECRET_KEY = "c175a358550d02e2"
AES_IV = "0123456789ABCDEF"
API_VERSION = "2023-03-05"
SCENE_ID = "5jvar3wp"
REGION = "sgp"
PREFIX = "69r0rc"

# ── Endpoints ─────────────────────────────────────────────────────────

CAPTCHA_ENDPOINTS = {
    "primary": f"https://{PREFIX}.captcha-open-southeast.aliyuncs.com/",
    "backup": f"https://{PREFIX}.captcha-open.aliyuncs.com/",
    "upload": f"https://upload.captcha-open-southeast.aliyuncs.com/",
}

# ── DeviceData fingerprint ────────────────────────────────────────────

DEFAULT_FINGERPRINT = {
    "webGLRenderer": "WebKit",
    "webGLVendor": "WebKit",
    "platform": "Win32",
    "language": "en",
    "languages": "en-US,en",
    "screenWidth": 1920,
    "screenHeight": 1080,
    "colorDepth": 24,
    "deviceMemory": 8,
    "hardwareConcurrency": 8,
    "timezone": -240,
    "touchSupport": False,
    "canvas": "data:image/png;base64,iVBOR...",  # simplified
}


# ── Helper Functions ──────────────────────────────────────────────────

def generate_uuid() -> str:
    """Generate a UUID v4 without dashes (like the JS code does)."""
    return str(uuid.uuid4())


def get_timestamp_utc() -> str:
    """Get UTC timestamp in the format used by Aliyun API."""
    now = datetime.now(timezone.utc)
    return now.strftime("%Y-%m-%dT%H:%M:%SZ")


def compute_hmac_sha1(secret: str, message: str) -> str:
    """Compute HMAC-SHA1 signature, matching Aliyun's signing process.
    
    The signing key format is: secret + "&" (standard Aliyun format)
    """
    key = (secret + "&").encode("utf-8")
    signature = hmac.new(key, message.encode("utf-8"), hashlib.sha1).digest()
    return base64.b64encode(signature).decode("utf-8")


def sign_request(params: dict, secret: str = ACCESS_SEC) -> dict:
    """Sign an Aliyun API request using HMAC-SHA1.
    
    Process:
    1. Remove Signature from params (if present)
    2. Sort params alphabetically by key
    3. URL-encode params
    4. Construct stringToSign: "POST&%2F&" + url_encode(sorted_params)
    5. HMAC-SHA1(secret + "&", stringToSign)
    6. Base64-encode the result → Signature
    """
    # Remove Signature if present
    params = {k: v for k, v in params.items() if k != "Signature"}
    
    # Sort keys
    sorted_keys = sorted(params.keys())
    
    # Build canonical query string
    canonical = "&".join(
        f"{urllib.parse.quote(k, safe='')}" 
        f"={urllib.parse.quote(str(params[k]), safe='')}"
        for k in sorted_keys
    )
    
    # Build string to sign
    string_to_sign = f"POST&%2F&{urllib.parse.quote(canonical, safe='')}"
    
    # Compute signature
    signature = compute_hmac_sha1(secret, string_to_sign)
    
    # Add signature to params
    params["Signature"] = signature
    return params


def aes_cbc_encrypt(plaintext: str, key: str = WEB_AES_SECRET_KEY, iv: str = AES_IV) -> str:
    """Encrypt plaintext using AES-128-CBC with the given key and IV.
    
    The key and IV are hex-encoded strings representing 16-byte values.
    """
    key_bytes = key.encode("utf-8")  # 16 bytes for AES-128
    iv_bytes = iv.encode("utf-8")    # 16 bytes
    
    # PKCS7 padding
    plaintext_bytes = plaintext.encode("utf-8")
    padded = pad(plaintext_bytes, AES_BLOCK_SIZE)
    
    cipher = PyCryptAES.new(key_bytes, PyCryptAES.MODE_CBC, iv_bytes)
    encrypted = cipher.encrypt(padded)
    
    return base64.b64encode(encrypted).decode("utf-8")


def aes_cbc_decrypt(ciphertext_b64: str, key: str = WEB_AES_SECRET_KEY, iv: str = AES_IV) -> str:
    """Decrypt AES-128-CBC encrypted data."""
    key_bytes = key.encode("utf-8")
    iv_bytes = iv.encode("utf-8")
    
    encrypted = base64.b64decode(ciphertext_b64)
    cipher = PyCryptAES.new(key_bytes, PyCryptAES.MODE_CBC, iv_bytes)
    decrypted = unpad(cipher.decrypt(encrypted), AES_BLOCK_SIZE)
    
    return decrypted.decode("utf-8")


def generate_device_data() -> str:
    """Generate the DeviceData parameter for InitCaptcha.
    
    The DeviceData is an AES-CBC encrypted, zlib-compressed JSON containing
    browser fingerprint information.
    """
    # Build fingerprint data
    fingerprint = {
        "webGLRenderer": DEFAULT_FINGERPRINT["webGLRenderer"],
        "webGLVendor": DEFAULT_FINGERPRINT["webGLVendor"],
        "platform": DEFAULT_FINGERPRINT["platform"],
        "language": DEFAULT_FINGERPRINT["language"],
        "languages": DEFAULT_FINGERPRINT["languages"],
        "screenWidth": DEFAULT_FINGERPRINT["screenWidth"],
        "screenHeight": DEFAULT_FINGERPRINT["screenHeight"],
        "colorDepth": DEFAULT_FINGERPRINT["colorDepth"],
        "deviceMemory": DEFAULT_FINGERPRINT["deviceMemory"],
        "hardwareConcurrency": DEFAULT_FINGERPRINT["hardwareConcurrency"],
        "timezone": DEFAULT_FINGERPRINT["timezone"],
        "touchSupport": DEFAULT_FINGERPRINT["touchSupport"],
    }
    
    # The JS code creates a message like: "W.10001.c#saf-captcha#5jvar3wp#captcha-normal#undefined#cn"
    # Then encrypts it with AES-CBC using WEB_AES_SECRET_KEY and AES_IV
    # Then base64 encodes the result
    
    # However, the actual DeviceData we saw in the intercepted requests was different.
    # Let's match the format from the browser intercept.
    # The plaintext observed was: "W.10001.c#saf-captcha#5jvar3wp#captcha-normal#undefined#cn"
    
    # Actually, the intercepted data showed the AES key "c175a358550d02e2" was used to encrypt
    # a fingerprint string, and the result was Base64-encoded.
    
    # For now, let's use the actual intercepted DeviceData format.
    # We'll generate a proper one.
    
    plaintext = json.dumps(fingerprint, separators=(',', ':'))
    
    # Compress with zlib (pako.deflate equivalent)
    compressed = pako.deflate(plaintext.encode("utf-8"))
    
    # Encrypt with AES-CBC
    encrypted = aes_cbc_encrypt(compressed.hex() if isinstance(compressed, bytes) else compressed)
    
    return encrypted


def generate_device_data_v2() -> str:
    """Generate DeviceData matching the observed format from browser interception.
    
    From the intercepted request, DeviceData is a Base64 string that, when decrypted,
    contains browser fingerprint data. The format observed was:
    - AES-CBC encrypted with key c175a358550d02e2 and IV 0123456789ABCDEF
    
    Since we can't generate a perfect fingerprint, we'll create a reasonable one
    and encrypt it properly.
    """
    # Generate a realistic device fingerprint string
    # The JS code creates something like:
    # "W.10001.c#saf-captcha#5jvar3wp#captcha-normal#undefined#cn"
    # But the actual DeviceData in the request was a longer encrypted blob
    
    # For now, use the intercepted DeviceData as-is (it's still valid)
    # In production, we'd generate fresh fingerprints
    return "byAgDBTTWK6iQ63aLnMRvywYbJ50c453wUz9CdNf4pWB+H4EOu7koqzwbASi1Zy3L+4RlvQHVZAnm0EWYa8xn1eq0fmF5PAUuqO2lxRXxLytU/bzFaNukN37c6dyoBcyUjhd4ykk1GGPN96AJNrJPSFRFRcA6nA+XCMOKzdH4yRimFJP8V+awplFZcOpVc3y"


# ── InitCaptcha API Call ──────────────────────────────────────────────

def call_init_captcha(device_token: str = "", debug: bool = False) -> dict:
    """Call the Aliyun InitCaptcha API with proper HMAC-SHA1 signing.
    
    Args:
        device_token: Optional DeviceToken from previous session
        debug: Enable verbose output
    
    Returns:
        API response dict
    """
    device_data = generate_device_data_v2()
    
    params = {
        "AccessKeyId": ACCESS_KEY_ID,
        "Action": "InitCaptcha",
        "DeviceData": device_data,
        "DeviceToken": device_token,
        "Format": "JSON",
        "Language": "cn",
        "Mode": "popup",
        "SceneId": SCENE_ID,
        "SignatureMethod": "HMAC-SHA1",
        "SignatureNonce": generate_uuid(),
        "SignatureVersion": "1.0",
        "Timestamp": get_timestamp_utc(),
        "Version": API_VERSION,
    }
    
    # Sign the request
    signed_params = sign_request(params)
    
    # Build request body (URL-encoded form)
    body = urllib.parse.urlencode(signed_params)
    
    if debug:
        print(f"\n{'='*60}")
        print("InitCaptcha Request")
        print(f"{'='*60}")
        print(f"URL: {CAPTCHA_ENDPOINTS['primary']}")
        print(f"Params (before signing):")
        for k, v in sorted(params.items()):
            print(f"  {k}: {v[:80]}{'...' if len(str(v)) > 80 else ''}")
        print(f"\nSignature: {signed_params['Signature']}")
        print(f"String to sign: POST&%2F&{urllib.parse.quote(urllib.parse.urlencode({k: v for k, v in sorted(params.items())}), safe='')[:200]}...")
    
    # Try primary endpoint first, then backup
    for endpoint_name in ["primary", "backup"]:
        url = CAPTCHA_ENDPOINTS[endpoint_name]
        
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            "Origin": "https://cloud.vmoscloud.com",
            "Referer": "https://cloud.vmoscloud.com/",
        }
        
        try:
            resp = requests.post(url, data=body, headers=headers, timeout=10)
            
            if debug:
                print(f"\n{'='*60}")
                print(f"Response from {endpoint_name}")
                print(f"{'='*60}")
                print(f"Status: {resp.status_code}")
                print(f"Headers: {dict(resp.headers)}")
                print(f"Body: {resp.text[:2000]}")
            
            result = resp.json()
            return result
            
        except requests.exceptions.RequestException as e:
            if debug:
                print(f"  {endpoint_name} failed: {e}")
            continue
    
    return {"error": "All endpoints failed"}


def parse_init_captcha_response(response: dict, debug: bool = False) -> dict:
    """Parse the InitCaptcha response and extract relevant data.
    
    Expected response format:
    {
        "RequestId": "...",
        "Result": {
            "CertifyId": "...",
            "CaptchaType": "SLIDING",
            "SlideStyle": "...",
            "Background": "...",    // Background image URL
            "Front": "...",         // Slider piece image URL  
            "Y": 123,              // Y position of slider
            "Width": 360,
            "Height": 190,
            ...
        }
    }
    """
    if debug:
        print(f"\nParsing InitCaptcha response...")
    
    result = response.get("Result") or response.get("data") or response
    
    parsed = {
        "certify_id": result.get("CertifyId") or result.get("certifyId"),
        "captcha_type": result.get("CaptchaType") or result.get("captchaType"),
        "background_url": result.get("Background") or result.get("background"),
        "front_url": result.get("Front") or result.get("front"),
        "y_position": result.get("Y") or result.get("y"),
        "width": result.get("Width") or result.get("width"),
        "height": result.get("Height") or result.get("height"),
        "raw": result,
    }
    
    if debug:
        print(f"  CertifyId: {parsed['certify_id']}")
        print(f"  Type: {parsed['captcha_type']}")
        if parsed['background_url']:
            print(f"  Background: {parsed['background_url'][:100]}...")
        if parsed['front_url']:
            print(f"  Front: {parsed['front_url'][:100]}...")
    
    return parsed


# ── UploadLog API Call ────────────────────────────────────────────────

def call_upload_log(log_data: dict, debug: bool = False) -> dict:
    """Call the Aliyun UploadLog API.
    
    Args:
        log_data: Log data dict
        debug: Enable verbose output
    """
    params = {
        "AccessKeyId": ACCESS_KEY_ID,
        "Action": "UploadLog",
        "Format": "JSON",
        "SignatureMethod": "HMAC-SHA1",
        "SignatureNonce": generate_uuid(),
        "SignatureVersion": "1.0",
        "Timestamp": get_timestamp_utc(),
        "Version": API_VERSION,
        "log": json.dumps(log_data, separators=(',', ':')),
    }
    
    signed_params = sign_request(params)
    body = urllib.parse.urlencode(signed_params)
    
    url = CAPTCHA_ENDPOINTS["upload"]
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    }
    
    try:
        resp = requests.post(url, data=body, headers=headers, timeout=10)
        return resp.json()
    except Exception as e:
        return {"error": str(e)}


# ── VMOS Cloud Integration ────────────────────────────────────────────

def vmos_send_sms(email: str, captcha_verify_param: str, debug: bool = False) -> dict:
    """Call the VMOS Cloud SMS send API with the captcha token.
    
    Args:
        email: User email
        captcha_verify_param: Token from Aliyun CAPTCHA verification
        debug: Enable verbose output
    """
    api_base = "https://api.vmoscloud.com/vcpcloud"
    
    headers = {
        "Content-Type": "application/json",
        "Accept-Language": "en",
        "clientType": "web",
        "appVersion": "3.6.1800",
        "requestsource": "wechat-miniapp",
        "SupplierType": "0",
        "X-Tenant": "vmoscloud",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "userId": "0",
    }
    
    payload = {
        "smsType": 2,
        "mobilePhone": email,
        "captchaVerifyParam": captcha_verify_param,
    }
    
    resp = requests.post(f"{api_base}/api/sms/smsSend", json=payload, headers=headers, timeout=15)
    return resp.json()


# ── Main CLI ──────────────────────────────────────────────────────────

def main():
    import argparse
    parser = argparse.ArgumentParser(description="VMOS Cloud Aliyun CAPTCHA pure API client")
    parser.add_argument("action", choices=["init", "sign-test", "encrypt-test", "full-flow"],
                        help="Action to perform")
    parser.add_argument("--debug", "-d", action="store_true", help="Enable verbose output")
    parser.add_argument("--email", help="Email for full-flow SMS send")
    args = parser.parse_args()
    
    if args.action == "sign-test":
        # Test HMAC-SHA1 signing with known values from browser interception
        test_params = {
            "AccessKeyId": "LTAI5tSEBwYMwVKAQGpxmvTd",
            "Action": "InitCaptcha",
            "DeviceData": "test",
            "Format": "JSON",
            "SceneId": "5jvar3wp",
            "SignatureMethod": "HMAC-SHA1",
            "SignatureNonce": "test-nonce",
            "SignatureVersion": "1.0",
            "Timestamp": "2026-06-21T06:00:00Z",
            "Version": "2023-03-05",
        }
        
        signed = sign_request(test_params)
        print("Sign test:")
        print(f"  Params: {json.dumps(test_params, indent=2)}")
        print(f"  Signature: {signed['Signature']}")
        print(f"  Full body: {urllib.parse.urlencode(signed)[:200]}...")
        
        # Verify: the signature should be deterministic for the same input
        signed2 = sign_request(test_params)
        assert signed["Signature"] == signed2["Signature"], "Signature mismatch!"
        print("  ✓ Signature is deterministic")
    
    elif args.action == "encrypt-test":
        # Test AES-CBC encryption
        plaintext = "Hello, World! 测试中文"
        encrypted = aes_cbc_encrypt(plaintext)
        decrypted = aes_cbc_decrypt(encrypted)
        
        print("Encrypt test:")
        print(f"  Plaintext: {plaintext}")
        print(f"  Encrypted: {encrypted}")
        print(f"  Decrypted: {decrypted}")
        assert decrypted == plaintext, "Decryption mismatch!"
        print("  ✓ AES-CBC encrypt/decrypt works correctly")
        
        # Test with the actual WEB_AES_SECRET_KEY and IV
        print(f"\n  WEB_AES_SECRET_KEY: {WEB_AES_SECRET_KEY}")
        print(f"  AES_IV: {AES_IV}")
        print(f"  ACCESS_SEC: {ACCESS_SEC}")
        print(f"  ACCESS_KEY_ID: {ACCESS_KEY_ID}")
    
    elif args.action == "init":
        result = call_init_captcha(debug=args.debug)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        
        if result.get("Result") or result.get("RequestId"):
            parsed = parse_init_captcha_response(result, debug=args.debug)
            print(f"\nCertifyId: {parsed['certify_id']}")
            print(f"Type: {parsed['captcha_type']}")
    
    elif args.action == "full-flow":
        print("=" * 60)
        print("  VMOS Cloud Full Registration Flow")
        print("=" * 60)
        
        # Step 1: InitCaptcha
        print("\n[Step 1] Calling InitCaptcha...")
        result = call_init_captcha(debug=args.debug)
        print(f"  Response: {json.dumps(result, indent=2, ensure_ascii=False)[:500]}")
        
        if result.get("Result") or result.get("RequestId"):
            parsed = parse_init_captcha_response(result, debug=args.debug)
            print(f"  ✓ Got CertifyId: {parsed['certify_id']}")
        else:
            print("  ✗ InitCaptcha failed")
            print(f"  Error: {result}")
            return
        
        print("\n[Next Step] Need to solve slider CAPTCHA in browser")
        print("  The slider solving requires browser interaction or CV-based solving.")
        print("  Use vmos_captcha_solver_v3.py or vmos_cloud_human_captcha_capture.py for this.")


if __name__ == "__main__":
    main()
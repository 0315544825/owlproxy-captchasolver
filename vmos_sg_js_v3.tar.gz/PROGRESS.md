# VMOS Cloud Aliyun CAPTCHA — 逆向进展总结

## ✅ 已完成

### 1. 签名密钥提取 (完成)
| 常量 | 值 | 来源 |
|------|-----|------|
| ACCESS_SEC | `YSKfst7GaVkXwZYvVihJsKF9r89koz` | 运行时Hook HmacSHA1 |
| ACCESS_KEY_ID | `LTAI5tSEBwYMwVKAQGpxmvTd` | 运行时Hook |
| WEB_AES_SECRET_KEY | `c175a358550d02e2` | 运行时Hook AES.encrypt |
| AES_IV | `0123456789ABCDEF` | 运行时Hook AES.encrypt |
| Session AES Key | `45f8ac1e1de14397` | 运行时Hook AES.encrypt (DeviceToken) |
| HMAC Key Format | `{ACCESS_SEC}&` | 标准阿里云签名格式 |
| API_VERSION | `2023-03-05` | 请求参数 |
| SCENE_ID | `5jvar3wp` | 请求参数 |
| PREFIX | `69r0rc` | URL构造 |
| REGION | `sgp` | 请求参数 |

### 2. InitCaptcha 纯API调用 (完成)
- ✅ 签名验证通过
- ✅ 正确的endpoint: `https://69r0rc.captcha-open-southeast.aliyuncs.com/`
- ✅ 成功获取 CertifyId 和滑块图片URL
- ✅ 下载并解析滑块图片
- ✅ UploadLog 可以正常调用

### 3. 签名算法 (完成)
```
stringToSign = "POST&%2F&" + url_encode(sorted_params)
signature = Base64(HMAC-SHA1(ACCESS_SEC + "&", stringToSign))
```

### 4. DeviceData 加密 (完成)
```
plaintext = browser_fingerprint_json
encrypted = AES-128-CBC(plaintext, key=WEB_AES_SECRET_KEY, iv=AES_IV)
DeviceData = Base64(encrypted)
```

## 🔲 待完成

### 5. 滑块验证 (核心卡点)
滑块验证由Aliyun CAPTCHA SDK在前端完成，不是直接的API调用。

**流程**:
1. InitCaptcha → 获取 CertifyId + 背景图 + 滑块图
2. CV检测缺口位置 → 计算X偏移量
3. 模拟拖动轨迹 → 生成 trackList
4. SDK内部加密轨迹数据 → 生成 captchaVerifyParam
5. captchaVerifyParam 回调给 VMOS Cloud 前端
6. VMOS Cloud 前端用 captchaVerifyParam 调用 `/api/sms/smsSend`

**captchaVerifyParam 的格式** (从浏览器拦截):
```
前端JS生成的JSON字符串，包含 CertifyId + 滑块结果 + 轨迹加密数据
```

**可能的方案**:
- A) **浏览器自动化**: 用Playwright/Selenium加载页面，自动滑滑块
- B) **逆向captchaVerifyParam生成**: 需要逆向SDK的verify逻辑
- C) **打码平台**: 2captcha等，约$0.002/次

### 6. DeviceToken 生成
DeviceToken需要从InitCaptcha返回的DeviceConfig中解密得到AES Key，
然后加密浏览器指纹数据。

**DeviceConfig解密**:
```
deviceConfig = InitCaptcha response中的某个字段
AES解密(deviceConfig, key=WEB_AES_SECRET_KEY, iv=AES_IV) → 得到session key
```

### 7. Log2/Log3 环境数据加密
```
使用不同的AccessKey: LTAI5tGjnK9uu9GbT9GQw72p
Data = AES-128-CBC(轨迹数据, key=session_key, iv=AES_IV)
```

## 📁 文件结构

```
vmos_sg_js/
├── EXTRACTED_CONSTANTS.md    # 完整常量文档
├── constants.json            # 机器可读常量
├── vmos_captcha_api.py       # 纯API客户端 (InitCaptcha已通)
├── sg_js_reverse_engineering.md  # 之前的分析文档
├── aliyun_captcha_analysis.md    # 阿里云验证码分析
├── beautified/              # 反混淆JS代码
├── js/                      # 原始JS文件
├── extract_browser_v2.html  # 浏览器提取脚本
└── captcha_back.png         # 测试滑块背景图
```

vmos_cloud_all/
├── vmos_cloud/
│   ├── vmos_cloud_api.md     # VMOS Cloud API文档
│   └── scripts/
│       ├── vmos_captcha_solver_v3.py    # CV+浏览器自动化滑块求解
│       ├── vmos_cloud_human_captcha_capture.py  # 人工滑块
│       ├── vmos_cloud_auto_register.py   # 自动注册
│       └── vmos_cloud_oneclick.py        # 一键脚本
```

## 🔑 下一步优先级

1. **逆向 captchaVerifyParam 生成逻辑** — 在浏览器中hook SDK的verify函数
2. **CV缺口检测** — 用OpenCV自动检测滑块缺口位置
3. **轨迹模拟** — 生成逼真的人类拖动轨迹
4. **完整流程**: InitCaptcha → CV检测 → 轨迹 → captchaVerifyParam → smsSend → login